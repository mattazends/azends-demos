import { useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Check, X, Home, Building2, HeartHandshake, Users } from "lucide-react";
import { AUDIENCES, HOW, AREAS, AREA_ORDER, SERVICES, SERVICE_ORDER, PHOTOS, px } from "@/lib/content";
import { useAudience, useWords, fill, Arrow } from "./Shell";

/* ---------- live job record ---------- */
export function JobRecord({ loop = true, start = true }) {
  const w = useWords();
  const rows = [
    ["Worker screening checked", "Before entry"],
    [`Entry booked with ${w.contact}`, "Around the morning routine"],
    [`Paused 15 min while the ${w.person} settled`, "Work restarted 10:42"],
    ["Wall patched with impact-rated lining", "Bedroom 2"],
    ["Before and after photos logged", "4 photos added to the record"],
  ];
  const [n, setN] = useState(0);
  useEffect(() => {
    if (!start) return;
    const id = setInterval(() => setN((x) => (x >= rows.length + 2 ? (loop ? 0 : x) : x + 1)), 1100);
    return () => clearInterval(id);
  }, [start, loop, rows.length]);
  return (
    <div className="rec">
      <div className="rec-h">
        <div>
          <b>Job #2041</b>
          <br />
          <small>Bedroom wall · Melbourne</small>
        </div>
        <span className={`pill ${n > rows.length ? "" : "sun"}`}>{n > rows.length ? "Logged" : "In progress"}</span>
      </div>
      {rows.map(([t, s], i) => (
        <div key={t} className={`rec-row ${n > i ? "on" : ""}`}>
          <i>
            <Check />
          </i>
          <div>
            <b>{t}</b>
            <span>{s}</span>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ---------- quick start ---------- */
const QS_ICONS = { sil: Home, sda: Building2, aged: HeartHandshake, family: Users };
export function QuickStart() {
  const { setAud } = useAudience();
  return (
    <div className="qs rv d2">
      <div>
        <h3>Tell us about the house.</h3>
        <p>Pick one to start logging a job. It takes about a minute.</p>
      </div>
      <div className="qs-g">
        {Object.values(AUDIENCES).map((a) => {
          const I = QS_ICONS[a.key];
          return (
            <Link key={a.key} to="/contact" search={{ who: a.key }} className="tile" onClick={() => setAud(a.key)}>
              <span className="tile-i">
                <I />
              </span>
              <span>
                <b>{a.label}</b>
                <small>{a.pains[0]}</small>
              </span>
              <svg className="go" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true">
                <path d="M4 10h12M11 5l5 5-5 5" />
              </svg>
            </Link>
          );
        })}
      </div>
    </div>
  );
}

/* ---------- marquee ---------- */
export function Strip() {
  const items = ["NDIS Worker Screening for everyone on site", "Every job photographed and logged", "Work paused when the person is unsettled", "Records ready for the auditor", "Melbourne, Geelong, Bendigo and regional Victoria"];
  const all = [...items, ...items];
  return (
    <div className="strip" aria-hidden="true">
      <div className="strip-t">
        {all.map((t, i) => (
          <span key={i}>
            <i />
            {t}
          </span>
        ))}
      </div>
    </div>
  );
}

/* ---------- general tradie vs soluna ---------- */
export function Versus() {
  const w = useWords();
  const rows = [
    ["Turns up when it suits the schedule", `Books entry with the ${w.contact}, around the routine`],
    [`Keeps going while the ${w.person} gets distressed`, `Stops work when the ${w.person} is unsettled`],
    ["Patches the hole, and it's back next month", "Fixes it so it's less likely to happen again"],
    ["Leaves an invoice, not a record", "Photos, notes and licences on every job record"],
    ["Finishes that look like a hospital", "Stronger finishes that still look like a home"],
  ];
  return (
    <section className="sec">
      <div className="wrap vsx">
        <div className="vsx-l">
          <span className="eyebrow rv">Why Soluna</span>
          <h2 className="sec-t rv d1">
            We understand construction. <b>And the person in the room.</b>
          </h2>
          <p className="lede rv d2">General trades fix the damage. We fix it in a way that suits the person who lives there, and leave a record you can use.</p>
          <div className="vsx-ph rv d2">
            <img src={px(PHOTOS.plaster, 1000)} alt="A gloved hand smoothing fresh plaster on a wall" loading="lazy" />
            <span>Same wall. Two very different jobs.</span>
          </div>
        </div>
        <div className="vsx-r">
          <div className="vsx-h rv">
            <span>A general tradie</span>
            <span>
              <i /> Soluna
            </span>
          </div>
          {rows.map(([bad, good], i) => (
            <div key={bad} className={`vsx-row rv d${i % 3}`}>
              <p className="bad">
                <X />
                {bad}
              </p>
              <p className="good">
                <i>
                  <Check />
                </i>
                {good}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- audiences ---------- */
const AUD_PHOTO = { sil: "living", sda: "hero", aged: "calm", family: "kitchen" };
export function Audiences() {
  const { aud, setAud } = useAudience();
  const a = AUDIENCES[aud] || AUDIENCES.sil;
  return (
    <section className="sec" style={{ background: "var(--paper2)" }}>
      <div className="wrap">
        <span className="eyebrow rv">Who we work with</span>
        <h2 className="sec-t rv d1">
          Pick the one that sounds like you. <b>We'll talk your language.</b>
        </h2>
        <div className="audx-tabs rv d2" role="tablist">
          {Object.values(AUDIENCES).map((x) => (
            <button key={x.key} type="button" role="tab" className={aud === x.key ? "on" : ""} onClick={() => setAud(x.key)} aria-selected={aud === x.key}>
              {x.label}
            </button>
          ))}
        </div>
        <div className="audx rv d2">
          <div className="audx-ph">
            {Object.values(AUDIENCES).map((x) => (
              <img key={x.key} className={aud === x.key ? "on" : ""} src={px(PHOTOS[AUD_PHOTO[x.key]], 1000)} alt="" loading="lazy" />
            ))}
          </div>
          <div className="audx-t" key={a.key}>
            <span className="n">You're dealing with</span>
            <h3>{a.title}</h3>
            <ul>
              {a.pains.map((p) => (
                <li key={p}>
                  <Check />
                  {p}
                </li>
              ))}
            </ul>
            <p className="say">
              Across this site we'll say <em>{a.person}</em> and <em>{a.contact}</em>.
            </p>
            <Link to="/contact" search={{ who: a.key }} className="btn btn-sun">
              Log a job <Arrow />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- services list ---------- */
export function ServicesList() {
  return (
    <section className="sec svx-sec">
      <div className="wrap">
        <span className="eyebrow rv">Three services</span>
        <h2 className="sec-t rv d1">
          Maintenance, modification and compliance. <b>Run the same careful way.</b>
        </h2>
      </div>
      <div className="svx">
        {SERVICE_ORDER.map((k, i) => {
          const s = SERVICES[k];
          return (
            <Link key={k} to={`/${k}`} className={`svx-c rv d${i}`}>
              <img src={px(s.photo, 900)} alt="" loading="lazy" />
              <span className="n">0{i + 1}</span>
              <span className="t">
                <small>{s.kicker}</small>
                <b>{s.name}</b>
                <em>{s.blurb}</em>
                <span className="go">
                  Learn more <Arrow />
                </span>
              </span>
            </Link>
          );
        })}
      </div>
      <div className="wrap">
        <Link to="/robust-plus" className="rpx rv">
          <img src={px(PHOTOS.bedroom, 1200)} alt="" loading="lazy" />
          <span className="rpx-t">
            <span className="eyebrow lt">Robust Plus</span>
            <b>The room-by-room upgrade.</b>
            <em>Four rooms, two tiers, with a 3D room you can turn and tap through.</em>
            <span className="btn btn-sun">
              Explore Robust Plus <Arrow />
            </span>
          </span>
        </Link>
      </div>
    </section>
  );
}

/* ---------- how a job runs ---------- */
export function HowItRuns() {
  const w = useWords();
  const listRef = useRef(null);
  useEffect(() => {
    const lis = [...(listRef.current?.querySelectorAll("li") || [])];
    const io = new IntersectionObserver((es) => es.forEach((e) => e.isIntersecting && e.target.classList.add("in")), { rootMargin: "0px 0px -35% 0px" });
    lis.forEach((l) => io.observe(l));
    return () => io.disconnect();
  }, []);
  return (
    <section className="sec" style={{ background: "var(--paper2)" }}>
      <div className="wrap how-g">
        <div className="how-l">
          <span className="eyebrow rv">How a job runs</span>
          <h2 className="sec-t rv d1">
            The difference is <b>how the job runs,</b> not the tools.
          </h2>
          <p className="lede rv d2">Every step is on the job record, so you can see exactly what happened in the house.</p>
          <div className="rv d3" style={{ marginTop: 32, maxWidth: 420 }}>
            <JobRecord />
          </div>
        </div>
        <ol className="how-list" ref={listRef}>
          {HOW.map((s) => (
            <li key={s.t}>
              <h4>{s.t}</h4>
              <p>{fill(s.d, w)}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}

/* ---------- areas ---------- */
// Simple projection of the region around Port Phillip
const proj = (lon, lat) => [((lon - 142.4) / 4.4) * 600, ((-36.0 - lat) / 2.9) * 490 + 10];
const CITIES = [
  { k: "melbourne", n: "Melbourne", c: [144.96, -37.81], r: 1 },
  { k: "geelong", n: "Geelong", c: [144.36, -38.15], r: 0.75 },
  { k: "bendigo", n: "Bendigo", c: [144.28, -36.76], r: 0.75 },
];
const REGIONAL = [[143.85, -37.56], [145.4, -36.38], [146.0, -37.4], [145.13, -38.3], [143.3, -37.9], [146.3, -38.2], [144.7, -37.3], [145.7, -36.9]];
export function AreasMap({ focus }) {
  const dots = [];
  for (let x = 12; x < 600; x += 18) for (let y = 12; y < 490; y += 18) dots.push([x, y]);
  return (
    <div className="map rv">
      <svg viewBox="0 0 600 490" preserveAspectRatio="xMidYMid slice" aria-label="Map of the areas Soluna covers in Victoria" role="img">
        {dots.map(([x, y]) => (
          <circle key={`${x}-${y}`} cx={x} cy={y} r="1.3" fill="rgba(246,243,236,.12)" />
        ))}
        <path d="M352 392 C 330 380, 318 352, 330 330 C 345 306, 380 300, 392 322 C 404 345, 396 372, 380 392 Z" fill="rgba(157,184,172,.16)" stroke="rgba(157,184,172,.35)" />
        {REGIONAL.map(([lo, la]) => {
          const [x, y] = proj(lo, la);
          return <circle key={`${lo}`} cx={x} cy={y} r="5" fill="rgba(239,174,46,.45)" />;
        })}
        {CITIES.map((c) => {
          const [x, y] = proj(...c.c);
          const on = !focus || focus === c.k;
          return (
            <g key={c.k} opacity={on ? 1 : 0.45}>
              <circle cx={x} cy={y} r={70 * c.r} fill="rgba(239,174,46,.07)">
                <animate attributeName="r" values={`${50 * c.r};${85 * c.r};${50 * c.r}`} dur="5s" repeatCount="indefinite" />
              </circle>
              <circle cx={x} cy={y} r={36 * c.r} fill="rgba(239,174,46,.14)" />
              <circle cx={x} cy={y} r="8" fill="#EFAE2E" stroke="#1C3A32" strokeWidth="3" />
              <text x={x + 16} y={y + 6} fill="#F6F3EC" fontFamily="Inter Tight, sans-serif" fontSize="20" fontWeight="500">
                {c.n}
              </text>
            </g>
          );
        })}
        <text x="24" y="470" fill="rgba(246,243,236,.45)" fontFamily="Inter Tight, sans-serif" fontSize="14">
          Gold dots: regional homes we schedule visits to
        </text>
      </svg>
    </div>
  );
}
export function Areas() {
  return (
    <section className="sec">
      <div className="wrap areas-g">
        <AreasMap />
        <div>
          <span className="eyebrow rv">Where we work</span>
          <h2 className="sec-t rv d1">
            Melbourne, Geelong, Bendigo <b>and regional Victoria.</b>
          </h2>
          <p className="lede rv d2">Urgent jobs across the cities, and planned visits for homes further out.</p>
          <div className="area-list rv d3">
            {AREA_ORDER.map((k) => (
              <Link key={k} to="/areas/$area" params={{ area: k }}>
                {AREAS[k].name}
                <Arrow />
              </Link>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
