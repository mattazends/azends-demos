import { createContext, useContext, useEffect, useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { ChevronDown } from "lucide-react";
import { AUDIENCES, SERVICES, SERVICE_ORDER, AREAS, AREA_ORDER, SITE, FAQS } from "@/lib/content";

/* ---------- audience language ---------- */
const AudCtx = createContext({ aud: "sil", setAud: () => {} });
export function AudienceProvider({ children }) {
  const [aud, setAudState] = useState("sil");
  useEffect(() => {
    try {
      const s = localStorage.getItem("soluna_aud");
      if (s && AUDIENCES[s]) setAudState(s);
    } catch {
      /* storage unavailable */
    }
  }, []);
  const setAud = (a) => {
    setAudState(a);
    try {
      localStorage.setItem("soluna_aud", a);
    } catch {
      /* storage unavailable */
    }
  };
  return <AudCtx.Provider value={{ aud, setAud }}>{children}</AudCtx.Provider>;
}
export const useAudience = () => useContext(AudCtx);
export function useWords() {
  const { aud } = useAudience();
  return AUDIENCES[aud] || AUDIENCES.sil;
}
// Replace {person} / {contact} tokens with the visitor's own words
export function fill(text, w) {
  return text.replace(/\{(\w+)\}/g, (_, k) => w[k] ?? k);
}

/* ---------- icons ---------- */
export const Arrow = () => (
  <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true">
    <path d="M4 10h12M11 5l5 5-5 5" />
  </svg>
);

export function Logo() {
  return (
    <Link to="/" className="logo" aria-label="Soluna Facilities Management home">
      <svg width="30" height="30" viewBox="0 0 200 200" aria-hidden="true">
        <circle cx="100" cy="100" r="100" fill="#EFAE2E" />
        <path d="M5.62 133.07L100 66.8L194.38 133.07A100 100 0 0 1 5.62 133.07Z" fill="#2C5A4E" />
      </svg>
      <span>
        <b>soluna</b>
      </span>
      <small>Facilities Management</small>
    </Link>
  );
}

/* ---------- reveal on scroll ---------- */
// Watches the DOM so sections from lazily loaded routes still reveal after client navigation.
export function useReveal() {
  useEffect(() => {
    document.documentElement.classList.add("js");
    const seen = new WeakSet();
    const io = new IntersectionObserver(
      (es) =>
        es.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("in");
            io.unobserve(e.target);
          }
        }),
      { rootMargin: "0px 0px -8% 0px", threshold: 0.08 }
    );
    const scan = () => {
      document.querySelectorAll(".rv:not(.in)").forEach((el) => {
        if (seen.has(el)) return;
        seen.add(el);
        io.observe(el);
      });
    };
    let raf = 0;
    const mo = new MutationObserver(() => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(scan);
    });
    scan();
    mo.observe(document.body, { childList: true, subtree: true });
    return () => {
      cancelAnimationFrame(raf);
      mo.disconnect();
      io.disconnect();
    };
  }, []);
}

/* ---------- header ---------- */
export function Header() {
  const [sc, setSc] = useState(false);
  const [op, setOp] = useState(false);
  const path = useRouterState({ select: (s) => s.location.pathname });
  useEffect(() => {
    const f = () => setSc(window.scrollY > 10);
    f();
    window.addEventListener("scroll", f, { passive: true });
    return () => window.removeEventListener("scroll", f);
  }, []);
  useEffect(() => setOp(false), [path]);
  useEffect(() => {
    document.body.style.overflow = op ? "hidden" : "";
  }, [op]);
  const on = (p) => (path === p ? "on" : "");
  return (
    <>
      <header className={`hdr ${sc || op ? "sc" : ""}`}>
        <div className="wrap hdr-in">
          <Logo />
          <nav className="nav" aria-label="Main">
            <Link to="/robust-plus" className={on("/robust-plus")}>Robust Plus</Link>
            <div className="dd">
              <button type="button">
                Services <ChevronDown />
              </button>
              <div className="dd-m">
                {SERVICE_ORDER.map((k) => (
                  <Link key={k} to={`/${k}`}>
                    {SERVICES[k].name}
                    <span>{SERVICES[k].kicker}</span>
                  </Link>
                ))}
                <div className="sep" />
                <Link to="/robust-plus">
                  Robust Plus
                  <span>Room-by-room home upgrades</span>
                </Link>
              </div>
            </div>
            <div className="dd">
              <button type="button">
                Areas <ChevronDown />
              </button>
              <div className="dd-m" style={{ width: 260 }}>
                {AREA_ORDER.map((k) => (
                  <Link key={k} to="/areas/$area" params={{ area: k }}>
                    {AREAS[k].name}
                  </Link>
                ))}
              </div>
            </div>
            <Link to="/our-story" className={on("/our-story")}>Our story</Link>
          </nav>
          <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
            <Link to="/contact" className="btn btn-ink desk">
              Log a job <Arrow />
            </Link>
            <button type="button" className={`burger ${op ? "op" : ""}`} onClick={() => setOp(!op)} aria-label="Menu" aria-expanded={op}>
              <i />
            </button>
          </div>
        </div>
      </header>
      <div className={`mnav ${op ? "op" : ""}`}>
        <Link to="/robust-plus">Robust Plus</Link>
        {SERVICE_ORDER.map((k) => (
          <Link key={k} to={`/${k}`}>{SERVICES[k].name}</Link>
        ))}
        <Link to="/our-story">Our story</Link>
        {AREA_ORDER.map((k) => (
          <Link key={k} className="sub" to="/areas/$area" params={{ area: k }}>
            {AREAS[k].name}
          </Link>
        ))}
        <Link to="/contact" className="btn btn-sun">
          Log a job <Arrow />
        </Link>
      </div>
    </>
  );
}

/* ---------- footer ---------- */
export function Footer() {
  return (
    <footer className="ftr">
      <div className="wrap">
        <div className="ftr-g">
          <div>
            <Logo />
            <p>Repairs, maintenance and Robust Plus upgrades for homes where people with complex needs live. Melbourne, Geelong, Bendigo and regional Victoria.</p>
          </div>
          <div>
            <h5>Services</h5>
            <Link to="/robust-plus">Robust Plus</Link>
            {SERVICE_ORDER.map((k) => (
              <Link key={k} to={`/${k}`}>{SERVICES[k].name}</Link>
            ))}
          </div>
          <div>
            <h5>Areas</h5>
            {AREA_ORDER.map((k) => (
              <Link key={k} to="/areas/$area" params={{ area: k }}>
                {AREAS[k].name}
              </Link>
            ))}
          </div>
          <div>
            <h5>Company</h5>
            <Link to="/our-story">Our story</Link>
            <Link to="/contact">Log a job</Link>
            <Link to="/contact">Contact</Link>
          </div>
        </div>
        <div className="ftr-big">soluna</div>
        <div className="ftr-b">
          <span>© 2026 {SITE.legal}</span>
          <span>{SITE.domain} · Not an NDIS-funded service</span>
        </div>
      </div>
    </footer>
  );
}

/* ---------- mobile bar ---------- */
export function MobileBar() {
  const [show, setShow] = useState(false);
  const path = useRouterState({ select: (s) => s.location.pathname });
  useEffect(() => {
    const f = () => setShow(window.scrollY > 500);
    f();
    window.addEventListener("scroll", f, { passive: true });
    return () => window.removeEventListener("scroll", f);
  }, []);
  if (path === "/contact") return null;
  return (
    <div className={`mbar ${show ? "show" : ""}`}>
      <div>
        <b>Something broken?</b>
        <small>Log it in a minute, with photos</small>
      </div>
      <Link to="/contact" className="btn btn-sun">
        Log a job
      </Link>
    </div>
  );
}

/* ---------- shared sections ---------- */
export function Faq({ items = FAQS, title = "Questions people ask" }) {
  const [op, setOp] = useState(0);
  return (
    <section className="sec">
      <div className="wrap faq-g">
        <div>
          <span className="eyebrow rv">FAQ</span>
          <h2 className="sec-t rv d1">{title}</h2>
          <p className="lede rv d2">Anything else, ask us when you log a job.</p>
        </div>
        <div className="rv d1">
          {items.map(([q, a], i) => (
            <div key={q} className={`fq ${op === i ? "op" : ""}`}>
              <button type="button" onClick={() => setOp(op === i ? -1 : i)} aria-expanded={op === i}>
                {q}
                <i />
              </button>
              <div className="a">
                <div>
                  <p>{a}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function CtaEnd({ title, lede }) {
  return (
    <section className="cta-end">
      <div className="sunglow" />
      <div className="wrap" style={{ position: "relative" }}>
        <span className="eyebrow rv" style={{ color: "#9DB8AC" }}>Get started</span>
        <h2 className="rv d1">{title || <>Start with the room <b>that keeps failing.</b></>}</h2>
        <p className="lede rv d2">{lede || "Log the job in about a minute. Add photos if you have them, and we'll call you back to arrange it."}</p>
        <div className="cta rv d3">
          <Link to="/contact" className="btn btn-sun">
            Log a job <Arrow />
          </Link>
          <Link to="/robust-plus" className="btn btn-ghost">
            Explore Robust Plus
          </Link>
        </div>
      </div>
    </section>
  );
}

export function PageHero({ eyebrow, title, lede, photo, crumbs = [], alt = "" }) {
  return (
    <section className={`phx ${photo ? "has-ph" : ""}`}>
      <div className="phx-card">
        {photo && <img className="hero-bg" src={photo} alt={alt} loading="eager" />}
        <div className="phx-in">
          <span className={`eyebrow rv ${photo ? "lt" : ""}`}>{eyebrow}</span>
          <h1 className="rv d1">{title}</h1>
          <p className="lede rv d2">{lede}</p>
          {crumbs.length > 0 && (
            <div className="crumbs rv d3">
              {crumbs.map((c) => (
                <span key={c}>
                  <i />
                  {c}
                </span>
              ))}
            </div>
          )}
          <div className="cta rv d3">
            <Link to="/contact" className="btn btn-sun">
              Log a job <Arrow />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
