import { createFileRoute, Link } from "@tanstack/react-router";
import { ShieldCheck, Camera, PauseCircle } from "lucide-react";
import { PHOTOS, px } from "@/lib/content";
import { Arrow, Faq } from "@/components/site/Shell";
import { JobRecord, QuickStart, Strip, Versus, Audiences, ServicesList, HowItRuns, Areas } from "@/components/site/Sections";
import HouseWalk from "@/components/site/HouseWalk";
import JobForm from "@/components/site/JobForm";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Soluna Facilities Management | Maintenance for supported homes in Victoria" },
      { name: "description", content: "We repair, reinforce and maintain homes for people with complex needs. Maintenance, modifications, compliance and Robust Plus upgrades across Melbourne, Geelong, Bendigo and regional Victoria." },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  return (
    <>
      <section className="hero">
        <div className="hero-card">
          <picture>
            <source media="(max-width: 700px)" srcSet={px(PHOTOS.livingAlt, 1000)} />
            <img className="hero-bg" src={px(PHOTOS.hero, 2000)} alt="A bright, calm living room in a family home" fetchPriority="high" />
          </picture>
          <div className="hero-in">
            <div className="hero-copy">
              <span className="eyebrow lt rv">Supported homes · Victoria</span>
              <h1 className="rv d1">
                We repair, reinforce and maintain homes for people with{" "}
                <b className="hl">
                  complex needs.
                  <svg viewBox="0 0 300 20" preserveAspectRatio="none" aria-hidden="true">
                    <path d="M3 14 C 70 4, 160 4, 297 12" />
                  </svg>
                </b>
              </h1>
              <p className="lede rv d2">Maintenance, modifications and Robust Plus upgrades for SIL and SDA providers, aged care homes and families. Done by people who understand the person in the room.</p>
              <div className="cta rv d3">
                <Link to="/contact" className="btn btn-sun">
                  Log a job <Arrow />
                </Link>
                <a href="#walk" className="btn btn-glass">
                  See a Robust Plus home
                </a>
              </div>
              <ul className="hero-ticks rv d4">
                <li>
                  <ShieldCheck /> Every worker screened
                </li>
                <li>
                  <Camera /> Every job photographed
                </li>
                <li>
                  <PauseCircle /> We pause when the person is unsettled
                </li>
              </ul>
            </div>
            <div className="hero-rec rv d3">
              <JobRecord />
            </div>
          </div>
        </div>
        <div className="wrap">
          <QuickStart />
        </div>
      </section>
      <Strip />
      <Versus />
      <Audiences />
      <HouseWalk />
      <ServicesList />
      <HowItRuns />
      <Areas />
      <Faq />
      <section className="sec form-sec" id="log">
        <div className="wrap form-g">
          <div>
            <span className="eyebrow rv">Log a job</span>
            <h2 className="sec-t rv d1">
              Something broken? <b>Log it in a minute.</b>
            </h2>
            <p className="lede rv d2">Four quick taps and your details. Add photos if you have them.</p>
            <ol className="next rv d3">
              <li>
                <b>1</b>
                <div>
                  <h4>We call you back</h4>
                  <p>To understand the job and the person living there.</p>
                </div>
              </li>
              <li>
                <b>2</b>
                <div>
                  <h4>We book entry around the routine</h4>
                  <p>At a time that suits the house, not our schedule.</p>
                </div>
              </li>
              <li>
                <b>3</b>
                <div>
                  <h4>You get the job record</h4>
                  <p>Photos, notes and who did the work.</p>
                </div>
              </li>
            </ol>
          </div>
          <div className="rv d1">
            <JobForm compact />
          </div>
        </div>
      </section>
    </>
  );
}
