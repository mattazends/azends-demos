import { Check } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { PageHero, Faq, CtaEnd, Arrow } from "./Shell";
import { HowItRuns, Areas } from "./Sections";

// Shared layout for the SIL Home Set-up and Aged Care Renovations pages.
export default function ExpertisePage({ eyebrow, title, lede, img, tags, listTitle, list, who, faqs, faqTitle }) {
  return (
    <>
      <PageHero eyebrow={eyebrow} title={title} lede={lede} img={img} crumbs={tags} />
      <section className="sec" style={{ paddingTop: 40 }}>
        <div className="wrap grid2">
          <div>
            <span className="eyebrow rv">How we can work with you</span>
            <h2 className="sec-t rv d1">{listTitle}</h2>
            <Link to="/contact" search={{ who }} className="btn btn-sun rv d2" style={{ marginTop: 12 }}>
              Request a Quote <Arrow />
            </Link>
          </div>
          <ul className="xlist">
            {list.map((t, i) => (
              <li key={t} className={`rv d${i % 3}`}>
                <i>
                  <Check />
                </i>
                {t}
              </li>
            ))}
          </ul>
        </div>
      </section>
      <HowItRuns />
      <Areas />
      <Faq items={faqs} title={faqTitle} />
      <CtaEnd />
    </>
  );
}
