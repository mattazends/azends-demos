import { createFileRoute } from "@tanstack/react-router";
import { AUDIENCES, FAQS, SERVICES } from "@/lib/content";
import ExpertisePage from "@/components/site/ExpertisePage";

const DESC = "From minor accessibility improvements to complete aged care facility renovations, delivered in collaboration with licensed builders and specialist trade partners.";

export const Route = createFileRoute("/aged-care-renovations")({
  head: () => ({
    meta: [
      { title: "Aged Care Renovations in Melbourne and Regional Victoria | Soluna FM" },
      { name: "description", content: DESC },
      { property: "og:title", content: "Aged Care Renovations | Soluna Facilities Management" },
      { property: "og:description", content: DESC },
    ],
  }),
  component: () => (
    <ExpertisePage
      eyebrow="Our Expertise"
      title={
        <>
          Aged Care <b>Renovations</b>
        </>
      }
      lede={DESC}
      img="bath-a"
      tags={["Facility Renovations", "Room & Bathroom Upgrades", "Dementia-Friendly Modifications", "Accessibility Improvements"]}
      listTitle={
        <>
          For <b>Aged Care Providers</b>
        </>
      }
      list={AUDIENCES.aged.ways}
      who="aged"
      faqs={[FAQS[2], SERVICES.renovations.faqs[1], SERVICES.renovations.faqs[2], FAQS[6], FAQS[7]]}
      faqTitle="Aged care renovation questions"
    />
  ),
});
