import { createFileRoute } from "@tanstack/react-router";
import { AUDIENCES, FAQS } from "@/lib/content";
import ExpertisePage from "@/components/site/ExpertisePage";

const DESC = "Complete SIL home set-ups, from furniture and appliances to household essentials, installation and standardised documentation, preparing homes for safe, consistent operation.";

export const Route = createFileRoute("/sil-home-set-up")({
  head: () => ({
    meta: [
      { title: "SIL Home Set-up in Melbourne and Regional Victoria | Soluna FM" },
      { name: "description", content: DESC },
      { property: "og:title", content: "SIL Home Set-up | Soluna Facilities Management" },
      { property: "og:description", content: DESC },
    ],
  }),
  component: () => (
    <ExpertisePage
      eyebrow="Our Expertise"
      title={
        <>
          SIL Home <b>Set-up</b>
        </>
      }
      lede={DESC}
      img="living-a"
      tags={["Furniture & Appliances", "Household Essentials", "Installation", "Standardised Documentation"]}
      listTitle={
        <>
          For <b>SIL Providers</b>
        </>
      }
      list={AUDIENCES.sil.ways}
      who="sil"
      faqs={[FAQS[1], FAQS[4], FAQS[6], FAQS[7]]}
      faqTitle="SIL home set-up questions"
    />
  ),
});
