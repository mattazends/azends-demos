import { useEffect, useRef, useState } from "react";
import { useRouterState } from "@tanstack/react-router";
import { Home, Building2, HeartHandshake, Users, Wrench, ClipboardCheck, Ruler, ShieldCheck, MessageSquare, Zap, CalendarDays, CalendarClock, Camera, Check, ArrowLeft, Sofa, PaintRoller, Bath, Signpost, Accessibility, Hammer } from "lucide-react";
import { AUDIENCES, ENQUIRY } from "@/lib/content";
import { submitJobRequest } from "@/lib/jobs";
import { base44 } from "@/api/base44Client";
import { useAudience, Arrow } from "./Shell";

const WHO_ICONS = { sil: Home, sda: Building2, aged: HeartHandshake, family: Users };
const ICONS = { sofa: Sofa, wrench: Wrench, ruler: Ruler, shield: ShieldCheck, clipboard: ClipboardCheck, message: MessageSquare, paint: PaintRoller, building: Building2, bath: Bath, signpost: Signpost, accessibility: Accessibility, hammer: Hammer, zap: Zap, days: CalendarDays, clock: CalendarClock };

function Tile({ on, icon: Icon, label, sub, onClick }) {
  return (
    <button type="button" className={`tile ${on ? "on" : ""}`} onClick={onClick} aria-pressed={on}>
      <span className="tile-i">
        <Icon />
      </span>
      <span>
        <b>{label}</b>
        {sub && <small>{sub}</small>}
      </span>
    </button>
  );
}

export default function JobForm({ compact = false }) {
  const { aud, setAud } = useAudience();
  const search = useRouterState({ select: (s) => s.location.search });
  const path = useRouterState({ select: (s) => s.location.pathname });
  const [step, setStep] = useState(0);
  const [f, setF] = useState({ who: "", need: "", urgency: "", name: "", organisation: "", phone: "", email: "", suburb: "", details: "" });
  const [photos, setPhotos] = useState([]); // {file, url}
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [done, setDone] = useState(false);
  const fileRef = useRef(null);
  const topRef = useRef(null);

  // prefill from ?who=&need=
  useEffect(() => {
    const s = search || {};
    const okNeed = AUDIENCES[s.who] && ENQUIRY[s.who].needs.some((n) => n.key === s.need);
    setF((p) => ({
      ...p,
      who: AUDIENCES[s.who] ? s.who : p.who,
      need: okNeed ? s.need : p.need,
    }));
    if (AUDIENCES[s.who]) setStep(okNeed ? 2 : 1);
  }, [search]);

  const set = (k, v) => setF((p) => ({ ...p, [k]: v }));
  const go = (n) => {
    setStep(n);
    const el = topRef.current;
    if (el) {
      const top = el.getBoundingClientRect().top;
      if (top < 60) window.scrollTo({ top: top + window.scrollY - 100, behavior: "smooth" });
    }
  };
  const pick = (k, v, next) => {
    if (k === "who" && v !== f.who) {
      setF((p) => ({ ...p, who: v, need: ENQUIRY[v].needs.some((n) => n.key === p.need) ? p.need : "" }));
    } else set(k, v);
    if (k === "who" && AUDIENCES[v]) setAud(v);
    setTimeout(() => go(next), 220);
  };

  const addPhotos = (list) => {
    const arr = [...list].slice(0, 6 - photos.length).map((file) => ({ file, url: URL.createObjectURL(file) }));
    setPhotos((p) => [...p, ...arr]);
  };

  const submit = async (e) => {
    e.preventDefault();
    setErr("");
    if (!f.name.trim() || f.phone.replace(/\D/g, "").length < 8) {
      setErr("Please add your name and a phone number we can contact you on.");
      return;
    }
    if (!f.suburb.trim()) {
      setErr("Please add the suburb of the property.");
      return;
    }
    setBusy(true);
    try {
      const urls = [];
      for (const p of photos) {
        try {
          const r = await base44.integrations.Core.UploadFile({ file: p.file });
          if (r?.file_url) urls.push(r.file_url);
        } catch {
          /* photo upload is optional */
        }
      }
      await submitJobRequest({
        data: {
          ...f,
          who: f.who || "other",
          need: f.need || "other",
          urgency: f.urgency || "soon",
          service: q.needs.find((n) => n.key === f.need)?.label || "Other / not sure",
          timeframe: q.when.find((n) => n.key === f.urgency)?.label || "",
          photo_urls: urls,
          source_page: path,
        },
      });
      setDone(true);
    } catch {
      setErr("That didn't send. Please check your details and try again.");
    } finally {
      setBusy(false);
    }
  };

  const total = 4;
  const q = ENQUIRY[f.who] || ENQUIRY[aud] || ENQUIRY.sil;

  if (done) {
    return (
      <div className="jf" ref={topRef}>
        <div className="jf-done">
          <div className="ok">
            <Check />
          </div>
          <h3>Thank you, {f.name.split(" ")[0]}.</h3>
          <p className="mute" style={{ maxWidth: 440, margin: "0 auto" }}>
            Thank you for contacting Soluna Facilities Management. We've received your enquiry and will be in touch to discuss your requirements.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="jf" ref={topRef} id="enquiry">
      <div className="jf-top">
        <span>{`Step ${step + 1} of ${total}`}</span>
        <span>About a minute</span>
      </div>
      <div className="jf-bar">
        <b style={{ width: `${((step + 1) / total) * 100}%` }} />
      </div>

      {step === 0 && (
        <div className="jf-step" key="s0">
          <h3>Who looks after the house?</h3>
          <div className="jf-g">
            {Object.values(AUDIENCES).map((a) => (
              <Tile key={a.key} on={f.who === a.key} icon={WHO_ICONS[a.key]} label={a.label} sub={a.sub} onClick={() => pick("who", a.key, 1)} />
            ))}
          </div>
        </div>
      )}

      {step === 1 && (
        <div className="jf-step" key="s1">
          <h3>{q.needQ}</h3>
          <div className={`jf-g ${compact ? "" : "c3"}`}>
            {q.needs.map((n) => (
              <Tile key={n.key} on={f.need === n.key} icon={ICONS[n.icon]} label={n.label} sub={n.sub} onClick={() => pick("need", n.key, 2)} />
            ))}
          </div>
        </div>
      )}

      {step === 2 && (
        <div className="jf-step" key="s2">
          <h3>{q.whenQ}</h3>
          <div className="jf-g c3">
            {q.when.map((u) => (
              <Tile key={u.key} on={f.urgency === u.key} icon={ICONS[u.icon]} label={u.label} sub={u.sub} onClick={() => pick("urgency", u.key, 3)} />
            ))}
          </div>
        </div>
      )}

      {step === 3 && (
        <form className="jf-step" key="s3" onSubmit={submit}>
          <h3>Where should we contact you?</h3>
          <div className="fgrid">
            <div className="fld">
              <label htmlFor="jf-name">Your name</label>
              <input id="jf-name" autoComplete="name" value={f.name} onChange={(e) => set("name", e.target.value)} required />
            </div>
            <div className="fld">
              <label htmlFor="jf-phone">Phone number</label>
              <input id="jf-phone" type="tel" autoComplete="tel" value={f.phone} onChange={(e) => set("phone", e.target.value)} required />
            </div>
            <div className="fld">
              <label htmlFor="jf-org">{f.who === "family" ? "Organisation (optional)" : "Organisation"}</label>
              <input id="jf-org" autoComplete="organization" value={f.organisation} onChange={(e) => set("organisation", e.target.value)} required={f.who !== "family"} />
            </div>
            <div className="fld">
              <label htmlFor="jf-sub">Suburb of the property</label>
              <input id="jf-sub" value={f.suburb} onChange={(e) => set("suburb", e.target.value)} required />
            </div>
            <div className="fld full">
              <label htmlFor="jf-email">Email address (optional)</label>
              <input id="jf-email" type="email" autoComplete="email" value={f.email} onChange={(e) => set("email", e.target.value)} />
            </div>
            <div className="fld full">
              <label htmlFor="jf-det">Tell us about the work you need</label>
              <textarea id="jf-det" value={f.details} onChange={(e) => set("details", e.target.value)} placeholder="Briefly describe what you need, including any important property requirements or considerations." />
            </div>
            <div className="full">
              <input ref={fileRef} type="file" accept="image/*" multiple hidden onChange={(e) => addPhotos(e.target.files)} />
              <button type="button" className="drop" onClick={() => fileRef.current?.click()}>
                <i>
                  <Camera />
                </i>
                <span>
                  <b>Add photos</b>
                  <small>Add photos if helpful, up to 6. Please avoid including identifiable people or personal information.</small>
                </span>
              </button>
              {photos.length > 0 && (
                <div className="thumbs">
                  {photos.map((p) => (
                    <img key={p.url} src={p.url} alt="" />
                  ))}
                </div>
              )}
            </div>
          </div>
          {err && <p className="jf-err">{err}</p>}
          <div className="jf-nav">
            <button type="button" className="jf-back" onClick={() => go(2)}>
              <ArrowLeft /> Back
            </button>
            <button type="submit" className="btn btn-sun" disabled={busy}>
              {busy ? "Sending…" : "Submit Enquiry"} {!busy && <Arrow />}
            </button>
          </div>
        </form>
      )}

      {step > 0 && step < 3 && (
        <div className="jf-nav">
          <button type="button" className="jf-back" onClick={() => go(step - 1)}>
            <ArrowLeft /> Back
          </button>
        </div>
      )}
    </div>
  );
}
