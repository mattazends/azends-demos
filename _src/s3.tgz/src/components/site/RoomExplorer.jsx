import { useEffect, useRef, useState } from "react";
import { ROOMS, ROOM_ORDER } from "@/lib/content";

// Interactive room viewer for the Robust Plus page: drag to turn, tier switch, click an upgrade.
export default function RoomExplorer() {
  const stageRef = useRef(null);
  const hsRef = useRef(null);
  const api = useRef(null);
  const [room, setRoom] = useState("bedroom");
  const [tier, setTier] = useState(1);
  const [sel, setSel] = useState(null);

  useEffect(() => {
    let disposed = false;
    let cleanup = () => {};
    (async () => {
      const THREE = await import("three");
      const { buildHouse, setupStage, highlight, ROOM_CENTERS } = await import("./three/house.js");
      if (disposed) return;
      const host = stageRef.current;
      const mobile = window.innerWidth < 900;
      const renderer = new THREE.WebGLRenderer({ antialias: true });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      host.appendChild(renderer.domElement);
      const scene = new THREE.Scene();
      const house = buildHouse(THREE, { mobile });
      house.roof.visible = false;
      setupStage(THREE, renderer, scene, house.shadowSize);
      scene.add(house.root);
      const camera = new THREE.PerspectiveCamera(mobile ? 50 : 40, 1, 0.1, 200);

      const state = { room: "bedroom", tier: 1, sel: null, az: 0.35, azWant: 0.35, dragging: false, idle: 0 };
      const center = new THREE.Vector3();
      const centerWant = new THREE.Vector3(ROOM_CENTERS.bedroom[0], 0.2, ROOM_CENTERS.bedroom[1]);
      center.copy(centerWant);

      const dots = {};
      const buildDots = () => {
        hsRef.current.innerHTML = "";
        Object.keys(dots).forEach((k) => delete dots[k]);
        ROOMS[state.room].items.forEach((it, n) => {
          const el = document.createElement("button");
          el.type = "button";
          el.className = `hs-dot ${it.tier === 2 ? "t2" : ""}`;
          el.innerHTML = `<b>${n + 1}</b><span>${it.title}</span>`;
          el.onclick = () => api.current?.onPick(it.id);
          hsRef.current.appendChild(el);
          dots[it.id] = { el, tier: it.tier };
        });
      };
      buildDots();

      const apply = () => {
        Object.values(house.items).forEach((it) => {
          const meta = ROOMS[it.room]?.items.find((x) => x.id === it.id);
          let lvl = 0;
          if (it.room === state.room && meta && meta.tier <= state.tier) lvl = state.sel === it.id ? 2 : 1;
          if (state.sel === it.id) lvl = 2;
          highlight(THREE, it, lvl);
        });
      };
      apply();

      let w = 0, h = 0;
      const resize = () => {
        w = host.clientWidth;
        h = host.clientHeight;
        renderer.setSize(w, h, false);
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
      };
      resize();
      const ro = new ResizeObserver(resize);
      ro.observe(host);

      // drag to turn
      let lastX = 0;
      const down = (e) => {
        state.dragging = true;
        lastX = e.clientX;
      };
      const move = (e) => {
        if (!state.dragging) return;
        state.azWant = Math.max(-1.2, Math.min(1.2, state.azWant + (e.clientX - lastX) * -0.006));
        lastX = e.clientX;
        state.idle = 0;
      };
      const up = () => (state.dragging = false);
      host.addEventListener("pointerdown", down);
      window.addEventListener("pointermove", move);
      window.addEventListener("pointerup", up);

      const v = new THREE.Vector3();
      let visible = true;
      const io = new IntersectionObserver(([e]) => (visible = e.isIntersecting));
      io.observe(host);
      let t0 = performance.now();
      const tick = (now) => {
        if (!visible) return;
        const dt = Math.min(0.05, (now - t0) / 1000);
        t0 = now;
        state.idle += dt;
        if (!state.dragging && state.idle > 3) state.azWant += Math.sin(now / 2600) * 0.0012;
        const k = 1 - Math.exp(-dt * 5);
        state.az += (state.azWant - state.az) * k;
        center.lerp(centerWant, k);
        const dist = mobile ? 4.6 : 4.1;
        const a = state.az;
        camera.position.set(center.x + Math.sin(a) * dist, mobile ? 9.6 : 8.2, center.z + Math.cos(a) * dist);
        camera.lookAt(center);
        Object.entries(dots).forEach(([id, d]) => {
          const show = d.tier <= state.tier || state.sel === id;
          v.copy(house.items[id].anchor).project(camera);
          const x = (v.x * 0.5 + 0.5) * w;
          d.el.classList.toggle("flip", x > w - 200);
          d.el.style.left = `${x}px`;
          d.el.style.top = `${(-v.y * 0.5 + 0.5) * h}px`;
          d.el.classList.toggle("on", show);
        });
        renderer.render(scene, camera);
      };
      renderer.setAnimationLoop(tick);

      api.current = {
        setRoom(r) {
          state.room = r;
          state.sel = null;
          state.azWant = 0.35;
          const c = ROOM_CENTERS[r];
          centerWant.set(c[0], 0.2, c[1]);
          buildDots();
          apply();
        },
        setTier(t) {
          state.tier = t;
          apply();
        },
        setSel(id) {
          state.sel = id;
          apply();
        },
        onPick: () => {},
      };

      cleanup = () => {
        renderer.setAnimationLoop(null);
        ro.disconnect();
        io.disconnect();
        host.removeEventListener("pointerdown", down);
        window.removeEventListener("pointermove", move);
        window.removeEventListener("pointerup", up);
        renderer.dispose();
        scene.traverse((o) => {
          o.geometry?.dispose();
          if (o.material) (Array.isArray(o.material) ? o.material : [o.material]).forEach((m) => m.dispose());
        });
        renderer.domElement.remove();
      };
    })();
    return () => {
      disposed = true;
      cleanup();
    };
  }, []);

  useEffect(() => {
    if (api.current) api.current.onPick = (id) => setSel((s) => (s === id ? null : id));
  });
  useEffect(() => {
    api.current?.setRoom(room);
    setSel(null);
  }, [room]);
  useEffect(() => {
    api.current?.setTier(tier);
  }, [tier]);
  useEffect(() => {
    api.current?.setSel(sel);
  }, [sel]);

  const R = ROOMS[room];
  return (
    <div className="rx rv">
      <div className="rx-tabs" role="tablist">
        {ROOM_ORDER.map((k, i) => (
          <button key={k} type="button" role="tab" aria-selected={room === k} className={room === k ? "on" : ""} onClick={() => setRoom(k)}>
            <small>0{i + 1}</small>
            {ROOMS[k].name}
          </button>
        ))}
      </div>
      <div className="rx-g">
        <div className="rx-stage" ref={stageRef}>
          <div className="hs" ref={hsRef} />
          <div className="rx-ctl">
            <div className="seg" role="group" aria-label="Tier">
              <button type="button" className={tier === 1 ? "on" : ""} onClick={() => setTier(1)}>Tier 1</button>
              <button type="button" className={tier === 2 ? "on" : ""} onClick={() => setTier(2)}>Tier 1 + 2</button>
            </div>
            <span className="rx-hint">
              <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true">
                <path d="M3 10h14M6 7l-3 3 3 3M14 7l3 3-3 3" />
              </svg>
              Drag to turn the room
            </span>
          </div>
        </div>
        <div className="rx-side">
          <h3>{R.name}</h3>
          <p>{R.intro}</p>
          <ul className="ups">
            {R.items.map((it, n) => {
              const off = it.tier > tier;
              return (
                <li key={it.id}>
                  <button
                    type="button"
                    className={`${sel === it.id ? "on" : ""} ${off ? "off" : ""} ${it.tier === 2 ? "t2" : ""}`}
                    onClick={() => {
                      if (off) setTier(2);
                      setSel(sel === it.id ? null : it.id);
                    }}
                  >
                    <b>{n + 1}</b>
                    <span>
                      <strong>{it.title}</strong>
                      <small>{it.desc}</small>
                    </span>
                    <em>Tier {it.tier}</em>
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      </div>
    </div>
  );
}
