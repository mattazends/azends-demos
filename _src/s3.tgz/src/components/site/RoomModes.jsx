import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { HeartHandshake, Home, BadgeCheck, MoveHorizontal } from "lucide-react";
import { RENDERS as ROOMS, R, rset } from "@/lib/content";
import { Arrow } from "@/components/site/Shell";

const AR = 2688 / 1520;
// The phone hero uses a 4:5 crop of the living room render, centred on the TV.
const MOB = { ar: 1080 / 1350, x0: 0.3337, w: 0.4524 };

const useIso = typeof window === "undefined" ? useEffect : useLayoutEffect;

// Where a point of the render lands inside an object-fit: cover box.
function useCover(ref, ar) {
  const [m, setM] = useState(null);
  useIso(() => {
    const el = ref.current;
    if (!el) return;
    const calc = () => {
      const w = el.clientWidth;
      const h = el.clientHeight;
      if (!w || !h) return;
      const s = Math.max(w / ar, h);
      const dw = s * ar;
      const dh = s;
      setM({ w, h, dw, dh, ox: (w - dw) / 2, oy: (h - dh) / 2 });
    };
    calc();
    const ro = new ResizeObserver(calc);
    ro.observe(el);
    return () => ro.disconnect();
  }, [ar]);
  return m;
}

function useMedia(q) {
  const [v, setV] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia(q);
    const f = () => setV(mq.matches);
    f();
    mq.addEventListener("change", f);
    return () => mq.removeEventListener("change", f);
  }, [q]);
  return v;
}

function useInView(ref, threshold = 0.35) {
  const [v, setV] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => setV(e.isIntersecting), { threshold });
    io.observe(el);
    return () => io.disconnect();
  }, [threshold]);
  return v;
}

/* ---------------- home hero: one room, two modes ---------------- */
export function HeroRoom({ children }) {
  const room = ROOMS[0];
  const [mode, setMode] = useState(0);
  const [auto, setAuto] = useState(true);
  const media = useRef(null);
  const card = useRef(null);
  const mob = useMedia("(max-width: 700px)");
  const cover = useCover(media, mob ? MOB.ar : AR);
  const seen = useInView(card, 0.2);

  useEffect(() => {
    if (!auto || !seen) return;
    const t = setTimeout(() => setMode((m) => 1 - m), mode ? 5200 : 3600);
    return () => clearTimeout(t);
  }, [auto, seen, mode]);

  const pick = (m) => {
    setAuto(false);
    setMode(m);
  };

  const at = (p) => {
    if (!cover) return null;
    const fx = mob ? (p.x - MOB.x0) / MOB.w : p.x;
    const x = cover.ox + fx * cover.dw;
    const y = cover.oy + p.y * cover.dh;
    const pad = 18;
    if (x < pad || x > cover.w - pad || y < 70 || y > cover.h - pad) return null;
    // keep pins off the headline: phones lose the bottom half, desktop the lower left
    if (mob && y > cover.h * 0.46) return null;
    if (!mob && ((x < cover.w * 0.56 && y > cover.h * 0.24) || y > cover.h * 0.84)) return null;
    return { x, y, flip: x > cover.w * 0.62 };
  };
  const origin = at(room.pins[0]) || { x: cover ? cover.w * 0.6 : 0, y: cover ? cover.h * 0.4 : 0 };

  const pic = (key, cls) => (
    <picture>
      <source media="(max-width: 700px)" srcSet={R(`${key}-m.webp`)} />
      <img className={cls} src={R(`${key}-1200.webp`)} srcSet={rset(key)} sizes="100vw" alt="" fetchPriority={cls.includes("hx-b") ? "low" : "high"} />
    </picture>
  );

  return (
    <section className="hero hx">
      <div className={`hero-card hx-card ${mode ? "m1" : "m0"}`} ref={card}>
        <div className="hx-media" ref={media} style={{ "--ox": `${origin.x}px`, "--oy": `${origin.y}px` }}>
          {pic("living-a", "hx-img")}
          {pic("living-b", "hx-img hx-b")}
          <div className="hx-pins" aria-hidden={!mode}>
            {room.pins.map((p, i) => {
              const q = at(p);
              if (!q) return null;
              return (
                <div key={p.t} className={`hx-pin ${q.flip ? "flip" : ""}`} style={{ left: q.x, top: q.y, transitionDelay: mode ? `${0.55 + i * 0.12}s` : "0s" }}>
                  <b>{i + 1}</b>
                  <span>{p.t}</span>
                </div>
              );
            })}
          </div>
        </div>

        <div className="hx-top">
          <div className="hx-switch" role="group" aria-label="Show the room in">
            <i className="hx-thumb" />
            <button type="button" className={mode === 0 ? "on" : ""} aria-pressed={mode === 0} onClick={() => pick(0)}>
              Everyday
            </button>
            <button type="button" className={mode === 1 ? "on" : ""} aria-pressed={mode === 1} onClick={() => pick(1)}>
              Protection mode
            </button>
            {auto && seen && <em key={mode} className="hx-tick" style={{ animationDuration: mode ? "5.2s" : "3.6s" }} />}
          </div>
          <small className="hx-cap">Same room. {mode ? "Built for the hard days." : "Just a home."}</small>
        </div>

        <div className="hero-in hx-in">
          <div className="hero-copy">
            <span className="eyebrow lt rv">Disability and aged care homes · Victoria</span>
            <h1 className="rv d1">
              Maintenance, Modifications and Renovations <b>for Disability and Aged Care Homes.</b>
            </h1>
            <p className="lede rv d2">From everyday repairs and compliance services to complete SIL home set-ups, Robust Plus upgrades and aged care renovations, Soluna Facilities Management delivers specialist property solutions across metropolitan Melbourne and regional Victoria.</p>
            <div className="cta rv d3">
              <Link to="/contact" className="btn btn-sun">
                Request a Quote <Arrow />
              </Link>
              <a href="#services" className="btn btn-glass">
                Explore Our Services
              </a>
            </div>
            <ul className="hero-ticks rv d4">
              <li>
                <HeartHandshake /> A team that understands disability and aged care support
              </li>
              <li>
                <Home /> Hands-on SIL and SDA experience
              </li>
              <li>
                <BadgeCheck /> Licensed trades and building partners
              </li>
            </ul>
          </div>
        </div>
      </div>
      {children}
    </section>
  );
}

/* ---------------- room by room: drag to compare ---------------- */
export function RoomCompare() {
  const [ri, setRi] = useState(0);
  const [pos, setPos] = useState(50);
  const [act, setAct] = useState(-1);
  const [glide, setGlide] = useState(false);
  const stage = useRef(null);
  const sec = useRef(null);
  const cover = useCover(stage, AR);
  const inView = useInView(sec, 0.3);
  const swept = useRef(false);
  const room = ROOMS[ri];
  const gt = useRef(0);

  const goTo = (p, ms = 900) => {
    setGlide(ms);
    setPos(p);
    clearTimeout(gt.current);
    gt.current = setTimeout(() => setGlide(false), ms);
  };

  // first time it's seen: a slow sweep so people know it moves
  useEffect(() => {
    if (!inView || swept.current) return;
    swept.current = true;
    const seq = [
      [78, 0],
      [24, 1100],
      [50, 2300],
    ];
    const ts = seq.map(([p, d]) => setTimeout(() => goTo(p, 1100), d + 300));
    return () => ts.forEach(clearTimeout);
  }, [inView]);

  const fromX = (clientX) => {
    const r = stage.current.getBoundingClientRect();
    return Math.min(98, Math.max(2, ((clientX - r.left) / r.width) * 100));
  };
  const down = (e) => {
    if (e.button !== undefined && e.button !== 0) return;
    setGlide(false);
    setPos(fromX(e.clientX));
    const mv = (ev) => setPos(fromX(ev.clientX));
    const up = () => {
      window.removeEventListener("pointermove", mv);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
    };
    window.addEventListener("pointermove", mv, { passive: true });
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
  };
  const key = (e) => {
    if (e.key === "ArrowLeft") goTo(Math.max(2, pos - 6), 300);
    if (e.key === "ArrowRight") goTo(Math.min(98, pos + 6), 300);
  };

  const at = (p) => {
    if (!cover) return null;
    const x = cover.ox + p.x * cover.dw;
    const y = cover.oy + p.y * cover.dh;
    if (x < 14 || x > cover.w - 14 || y < 14 || y > cover.h - 14) return null;
    return { x, y, xp: (x / cover.w) * 100, flip: x > cover.w * 0.6 };
  };

  const pickRoom = (i) => {
    setRi(i);
    setAct(-1);
    goTo(50, 700);
  };
  const focus = (i) => {
    setAct(i);
    const q = at(room.pins[i]);
    if (q) goTo(Math.max(3, Math.min(q.xp - 16, 60)), 800);
  };

  return (
    <section className="sec rc" id="rooms" ref={sec}>
      <div className="wrap">
        <div className="rc-head">
          <div>
            <span className="eyebrow rv">Room by room</span>
            <h2 className="sec-t rv d1">
              When Robust <b>isn't robust enough.</b>
            </h2>
          </div>
          <p className="lede rv d2">Drag across each room to see how Robust Plus adds protection while keeping the comfort and character of home.</p>
        </div>

        <div className="rc-tabs rv d2" role="tablist">
          {ROOMS.map((r, i) => (
            <button key={r.key} type="button" role="tab" aria-selected={ri === i} className={ri === i ? "on" : ""} onClick={() => pickRoom(i)}>
              {r.label}
            </button>
          ))}
        </div>

        <div className="rc-stage rv d3" ref={stage} onPointerDown={down} style={{ "--p": `${pos}%`, "--g": glide ? `${glide}ms` : "0ms" }}>
          <img className="rc-img" src={R(`${room.key}-a-1200.webp`)} srcSet={rset(`${room.key}-a`)} sizes="(max-width: 900px) 100vw, 1280px" alt={`${room.title}, everyday`} loading="lazy" draggable="false" />
          <img className="rc-img rc-b" src={R(`${room.key}-b-1200.webp`)} srcSet={rset(`${room.key}-b`)} sizes="(max-width: 900px) 100vw, 1280px" alt={`${room.title}, with the Robust Plus upgrade`} loading="lazy" draggable="false" />
          <span className="rc-lab l">Everyday</span>
          <span className="rc-lab r">Protection mode</span>
          {room.pins.map((p, i) => {
            const q = at(p);
            if (!q) return null;
            const shown = q.xp > pos + 1.5;
            return (
              <button
                key={`${room.key}${i}`}
                type="button"
                className={`rc-pin ${shown ? "on" : ""} ${act === i ? "act" : ""} ${q.flip ? "flip" : ""}`}
                style={{ left: q.x, top: q.y }}
                onPointerDown={(e) => e.stopPropagation()}
                onClick={() => setAct(act === i ? -1 : i)}
                aria-label={p.t}
              >
                <b>{i + 1}</b>
                <span>{p.t}</span>
              </button>
            );
          })}
          <div className="rc-line" />
          <button type="button" className="rc-handle lq" aria-label="Drag to compare" onKeyDown={key}>
            <MoveHorizontal />
          </button>
        </div>

        <div className="rc-foot">
          <div className="rc-intro">
            <h3>{room.title}</h3>
            <p>{room.intro}</p>
          </div>
          <ol className="rc-list" key={room.key}>
            {room.pins.map((p, i) => (
              <li key={p.t} className={act === i ? "act" : ""} style={{ animationDelay: `${i * 60}ms` }}>
                <button type="button" onClick={() => focus(i)}>
                  <b>{i + 1}</b>
                  <span>
                    <strong>{p.t}</strong>
                    <small>{p.d}</small>
                  </span>
                </button>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}
