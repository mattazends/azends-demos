import { Link } from "@tanstack/react-router";
import { SERVICES, SERVICE_ORDER, SCHEDULE, px } from "@/lib/content";
import { PageHero, Faq, CtaEnd, Arrow } from "./Shell";
import { FeatureList, Areas } from "./Sections";

export function serviceHead(slug) {
  const s = SERVICES[slug];
  return () => ({
    meta: [
      { title: `${s.h1.join(" ")} | Soluna FM` },
      { name: "description", content: s.lede },
      { property: "og:title", content: `${s.name} | Soluna Facilities Management` },
      { property: "og:description", content: s.lede },
    ],
  });
}

export default function ServicePage({ slug }) {
  const s = SERVICES[slug];
  const others = SERVICE_ORDER.filter((k) => k !== slug);
  return (
    <>
      <PageHero
        eyebrow={s.kicker}
        title={
          <>
            {s.h1[0]} <b>{s.h1[1]}</b>
          </>
        }
        lede={s.lede}
        photo={px(s.photo, 1200)}
        crumbs={s.tags}
      />
      <section className="sec" style={{ paddingTop: 40 }}>
        <div className="wrap">
          <span className="eyebrow rv">What's included</span>
          <h2 className="sec-t rv d1">
            {s.incTitle[0]} <b>{s.incTitle[1]}</b>
          </h2>
          {s.incLede && <p className="lede rv d2">{s.incLede}</p>}
          <div className="inc">
            {s.includes.map(([t, d], i) => (
              <div key={t} className={`rv d${i % 2}`}>
                <span className="k">0{i + 1}</span>
                <b>{t}</b>
                <p>{d}</p>
              </div>
            ))}
          </div>
          {slug === "renovations" && (
            <Link to="/expertise/aged-care-renovations" className="xlink rv">
              <span>
                <b>Renovating an aged care facility?</b>
                See our specialist Aged Care Renovations page for resident rooms, accessible bathrooms, dementia-friendly modifications and facility upgrades.
              </span>
              <Arrow />
            </Link>
          )}
          {slug === "compliance" && (
            <>
              <h3 className="rv" style={{ fontSize: 30, marginTop: 72 }}>
                Yearly compliance calendar
              </h3>
              <div className="sched">
                {SCHEDULE.map((x, i) => (
                  <div key={x.m} className={`rv d${i % 4}`}>
                    <b>{x.m}</b>
                    <span>{x.c}</span>
                    <small>{x.d}</small>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </section>
      <FeatureList
        eyebrow={s.featEyebrow}
        title={
          <>
            {s.featTitle[0]} <b>{s.featTitle[1]}</b>
          </>
        }
        lede={s.featLede}
        items={s.feats}
      />
      <section className="sec">
        <div className="wrap">
          <span className="eyebrow rv">Also from Soluna</span>
          <div className="inc c3" style={{ marginTop: 24 }}>
            {others.map((k, i) => (
              <Link key={k} to={`/${k}`} className={`rv d${i}`} style={{ display: "block" }}>
                <div>
                  <span className="k">0{i + 1}</span>
                  <b>{SERVICES[k].name}</b>
                  <p>{SERVICES[k].also}</p>
                  <span className="tlink" style={{ marginTop: 18 }}>
                    Learn More <Arrow />
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
      <Areas />
      <Faq items={s.faqs} title={`${s.name} questions`} />
      <CtaEnd />
    </>
  );
}
