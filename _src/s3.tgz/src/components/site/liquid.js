// Liquid glass for every .btn and .lq element.
// 1. A specular highlight that follows the pointer (all browsers).
// 2. Real edge refraction on Chromium: a displacement map shaped to the element's
//    rounded rectangle, applied with backdrop-filter. Other browsers keep the frosted glass.
import { useEffect } from "react";

const SEL = ".btn, .lq";
let svgRoot = null;
const maps = new Map();

function supportsRefraction() {
  if (typeof navigator === "undefined") return false;
  const brands = navigator.userAgentData?.brands || [];
  const chromium = brands.some((b) => /Chromium|Google Chrome|Microsoft Edge/.test(b.brand));
  return chromium && !/iPhone|iPad/.test(navigator.userAgent);
}

function ensureSvg() {
  if (svgRoot) return svgRoot;
  svgRoot = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svgRoot.setAttribute("aria-hidden", "true");
  svgRoot.setAttribute("width", "0");
  svgRoot.setAttribute("height", "0");
  svgRoot.style.cssText = "position:absolute;width:0;height:0;overflow:hidden;pointer-events:none";
  svgRoot.appendChild(document.createElementNS("http://www.w3.org/2000/svg", "defs"));
  document.body.appendChild(svgRoot);
  return svgRoot;
}

// Encodes a lens: pixels near the rim are pushed inward, strongest right at the edge.
function makeMap(w, h, r) {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const ctx = c.getContext("2d");
  const img = ctx.createImageData(w, h);
  const band = Math.min(h * 0.42, 22);
  const hw = w / 2;
  const hh = h / 2;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const px = x + 0.5 - hw;
      const py = y + 0.5 - hh;
      const qx = Math.abs(px) - (hw - r);
      const qy = Math.abs(py) - (hh - r);
      const ox = Math.max(qx, 0);
      const oy = Math.max(qy, 0);
      const sdf = Math.hypot(ox, oy) + Math.min(Math.max(qx, qy), 0) - r;
      const d = -sdf;
      let nx = 0;
      let ny = 0;
      if (ox > 0 || oy > 0) {
        const l = Math.hypot(ox, oy) || 1;
        nx = (Math.sign(px) * ox) / l;
        ny = (Math.sign(py) * oy) / l;
      } else if (qx > qy) nx = Math.sign(px);
      else ny = Math.sign(py);
      let m = 0;
      if (d > 0 && d < band) {
        const t = 1 - d / band;
        m = t * t * (3 - 2 * t);
      }
      const i = (y * w + x) * 4;
      img.data[i] = 128 - nx * m * 127;
      img.data[i + 1] = 128 - ny * m * 127;
      img.data[i + 2] = 128;
      img.data[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  return c.toDataURL();
}

function filterFor(w, h, r) {
  const key = `${w}x${h}x${r}`;
  if (maps.has(key)) return maps.get(key);
  const id = `lq-${key}`;
  const NS = "http://www.w3.org/2000/svg";
  const defs = ensureSvg().firstChild;
  const f = document.createElementNS(NS, "filter");
  f.setAttribute("id", id);
  f.setAttribute("x", "0");
  f.setAttribute("y", "0");
  f.setAttribute("width", "100%");
  f.setAttribute("height", "100%");
  f.setAttribute("color-interpolation-filters", "sRGB");
  const im = document.createElementNS(NS, "feImage");
  im.setAttribute("href", makeMap(w, h, r));
  im.setAttribute("x", "0");
  im.setAttribute("y", "0");
  im.setAttribute("width", String(w));
  im.setAttribute("height", String(h));
  im.setAttribute("preserveAspectRatio", "none");
  im.setAttribute("result", "map");
  const dm = document.createElementNS(NS, "feDisplacementMap");
  dm.setAttribute("in", "SourceGraphic");
  dm.setAttribute("in2", "map");
  dm.setAttribute("scale", String(Math.round(Math.min(46, h * 0.8))));
  dm.setAttribute("xChannelSelector", "R");
  dm.setAttribute("yChannelSelector", "G");
  f.appendChild(im);
  f.appendChild(dm);
  defs.appendChild(f);
  maps.set(key, id);
  return id;
}

export function useLiquidGlass() {
  useEffect(() => {
    const refract = supportsRefraction();
    if (refract) document.documentElement.classList.add("lq-refract");
    const seen = new WeakSet();

    const size = (el) => {
      const w = Math.round(el.offsetWidth);
      const h = Math.round(el.offsetHeight);
      if (w < 8 || h < 8) return;
      const br = parseFloat(getComputedStyle(el).borderTopLeftRadius) || 0;
      const r = Math.round(Math.min(br, h / 2, w / 2));
      el.style.setProperty("--lq", `url(#${filterFor(w, h, r)})`);
    };
    const ro = refract && typeof ResizeObserver !== "undefined" ? new ResizeObserver((es) => es.forEach((e) => size(e.target))) : null;

    const move = (e) => {
      const el = e.currentTarget;
      const r = el.getBoundingClientRect();
      el.style.setProperty("--mx", `${(((e.clientX - r.left) / r.width) * 100).toFixed(1)}%`);
      el.style.setProperty("--my", `${(((e.clientY - r.top) / r.height) * 100).toFixed(1)}%`);
    };
    const leave = (e) => {
      e.currentTarget.style.removeProperty("--mx");
      e.currentTarget.style.removeProperty("--my");
    };

    const scan = () => {
      document.querySelectorAll(SEL).forEach((el) => {
        if (seen.has(el)) return;
        seen.add(el);
        el.addEventListener("pointermove", move, { passive: true });
        el.addEventListener("pointerleave", leave, { passive: true });
        if (ro) ro.observe(el);
      });
    };
    let raf = 0;
    const mo = new MutationObserver(() => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(scan);
    });
    scan();
    mo.observe(document.body, { childList: true, subtree: true });
    return () => {
      cancelAnimationFrame(raf);
      mo.disconnect();
      ro?.disconnect();
    };
  }, []);
}
