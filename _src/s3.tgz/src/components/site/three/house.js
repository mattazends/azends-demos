// Procedural Robust Plus house. Pure three.js, no assets.
// House is 11m x 9m, centred on the origin. Back rooms sit at z < 0, front rooms at z > 0.
import { RoundedBoxGeometry } from "three/examples/jsm/geometries/RoundedBoxGeometry.js";

export const W = 11;
export const D = 9;
export const H = 2.7;
const T = 0.14;
const X0 = -W / 2, X1 = W / 2, Z0 = -D / 2, Z1 = D / 2;
const XM = 0.7; // wall between bedroom and bathroom

export const ROOM_CENTERS = {
  bedroom: [-2.4, -2.3],
  bathroom: [3.1, -2.3],
  kitchen: [3.1, 2.3],
  living: [-2.4, 2.3],
};

const C = {
  wall: "#F4F0E8",
  cap: "#26302D",
  slab: "#CFC6B6",
  ground: "#EDE7DA",
  lawn: "#C7D1B6",
  path: "#E2DACB",
  timber: "#CDAF88",
  timberLight: "#DCC7A4",
  tile: "#DCDDD6",
  tileWet: "#C6CCC6",
  roof: "#3B4542",
  fascia: "#2D3633",
  glass: "#BFD8DD",
  euc: "#5F8174",
  eucSoft: "#8DAA9D",
  sand: "#BFA588",
  linen: "#F7F4EE",
  greige: "#A9A291",
  dark: "#1B201F",
  steel: "#B9C2C3",
  sun: "#EFAE2E",
};

export function buildHouse(THREE, { mobile = false } = {}) {
  const root = new THREE.Group();
  const matCache = {};
  const shared = (color, o = {}) => {
    const k = color + JSON.stringify(o);
    if (!matCache[k]) {
      matCache[k] = new THREE.MeshStandardMaterial({
        color,
        roughness: o.r ?? 0.86,
        metalness: o.m ?? 0,
        transparent: !!o.t,
        opacity: o.o ?? 1,
        depthWrite: o.t ? false : true,
      });
    }
    return matCache[k];
  };

  const items = {}; // id -> { id, room, meshes, anchor }
  let current = null; // item id collecting meshes

  function add(mesh, { cast = true, receive = true, parent = root } = {}) {
    mesh.castShadow = cast;
    mesh.receiveShadow = receive;
    if (current) {
      mesh.material = mesh.material.clone();
      mesh.userData.base = {
        color: mesh.material.color.clone(),
        opacity: mesh.material.opacity,
      };
      items[current].meshes.push(mesh);
    }
    parent.add(mesh);
    return mesh;
  }

  // box by centre x/z and bottom y
  function box(w, h, d, x, y, z, color, o = {}) {
    const r = o.round ?? 0;
    const g = r > 0 ? new RoundedBoxGeometry(w, h, d, 2, Math.min(r, w / 2, h / 2, d / 2)) : new THREE.BoxGeometry(w, h, d);
    const m = new THREE.Mesh(g, o.mat || shared(color, o));
    m.position.set(x, y + h / 2, z);
    if (o.ry) m.rotation.y = o.ry;
    return add(m, o);
  }
  function cyl(rt, rb, h, x, y, z, color, o = {}) {
    const g = new THREE.CylinderGeometry(rt, rb, h, o.seg ?? 24);
    const m = new THREE.Mesh(g, shared(color, o));
    m.position.set(x, y + h / 2, z);
    if (o.rz) m.rotation.z = o.rz;
    if (o.rx) m.rotation.x = o.rx;
    return add(m, o);
  }

  function item(id, room, anchor, fn) {
    items[id] = { id, room, meshes: [], anchor: new THREE.Vector3(...anchor) };
    current = id;
    fn();
    current = null;
  }

  // ---------- ground ----------
  const ground = new THREE.Mesh(new THREE.CircleGeometry(40, 64), shared(C.ground, { r: 1 }));
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = -0.06;
  add(ground, { cast: false });
  const lawn = new THREE.Mesh(new THREE.PlaneGeometry(W + 7, D + 8), shared(C.lawn, { r: 1 }));
  lawn.rotation.x = -Math.PI / 2;
  lawn.position.set(0, -0.05, 0.6);
  add(lawn, { cast: false });
  box(1.2, 0.02, 4.2, 1.4, -0.05, Z1 + 2.2, C.path, { cast: false });
  box(W + 0.3, 0.12, D + 0.3, 0, -0.12, 0, C.slab, { cast: false });

  // trees
  const tree = (x, z, s = 1) => {
    cyl(0.07 * s, 0.1 * s, 1.1 * s, x, 0, z, "#7A6A58");
    const f = new THREE.Mesh(new THREE.IcosahedronGeometry(0.9 * s, 0), shared("#7E9C80"));
    f.position.set(x, 1.55 * s, z);
    add(f);
    const f2 = new THREE.Mesh(new THREE.IcosahedronGeometry(0.6 * s, 0), shared("#6F8F73"));
    f2.position.set(x + 0.35 * s, 2.05 * s, z - 0.2 * s);
    add(f2);
  };
  tree(-7.4, 3.6, 1.2);
  tree(7.3, -2.5, 1);
  tree(6.6, 4.8, 0.8);

  // ---------- floors ----------
  const floor = (x0, x1, z0, z1, color) => box(x1 - x0, 0.02, z1 - z0, (x0 + x1) / 2, 0, (z0 + z1) / 2, color, { cast: false, r: 0.7 });
  floor(X0, XM, Z0, 0, C.timber);
  floor(X0, XM, 0, Z1, C.timber);
  floor(XM, X1, 0, Z1, C.timberLight);

  // ---------- walls ----------
  const wallMat = shared(C.wall, { r: 0.92 });
  const capMat = shared(C.cap, { r: 0.7 });
  const glassMat = shared(C.glass, { t: true, o: 0.38, r: 0.1, m: 0.1 });
  const frontWall = [];

  // axis 'x': runs along x at fixed z. axis 'z': runs along z at fixed x.
  function wall(axis, fixed, s0, s1, gaps = [], tag) {
    const seg = (a, b, y0, y1) => {
      if (b - a < 0.01 || y1 - y0 < 0.01) return;
      const len = b - a, mid = (a + b) / 2, h = y1 - y0;
      const m = axis === "x"
        ? box(len, h, T, mid, y0, fixed, null, { mat: wallMat })
        : box(T, h, len, fixed, y0, mid, null, { mat: wallMat });
      if (tag) tag.push(m);
      if (Math.abs(y1 - H) < 0.001) {
        const c = axis === "x"
          ? box(len, 0.025, T + 0.004, mid, H, fixed, null, { mat: capMat, cast: false })
          : box(T + 0.004, 0.025, len, fixed, H, mid, null, { mat: capMat, cast: false });
        if (tag) tag.push(c);
      }
    };
    const gs = [...gaps].sort((a, b) => a[0] - b[0]);
    let cur = s0;
    for (const [a, b, lo, hi, kind] of gs) {
      seg(cur, a, 0, H);
      seg(a, b, 0, lo);
      seg(a, b, hi, H);
      if (kind === "win") {
        const len = b - a, mid = (a + b) / 2, h = hi - lo;
        const g = axis === "x" ? box(len, h, 0.03, mid, lo, fixed, null, { mat: glassMat, cast: false }) : box(0.03, h, len, fixed, lo, mid, null, { mat: glassMat, cast: false });
        g.userData.glass = true;
        if (tag) tag.push(g);
      }
      cur = b;
    }
    seg(cur, s1, 0, H);
  }

  // back wall (bedroom window handled as an item below)
  wall("x", Z0, X0 - T / 2, X1 + T / 2, [[-3.7, -1.5, 0.9, 2.15], [2.7, 3.9, 1.55, 2.15, "win"]]);
  // front wall
  wall("x", Z1, X0 - T / 2, X1 + T / 2, [[-4.4, -1.2, 0.55, 2.2], [0.9, 1.9, 0, 2.2], [3.2, 4.8, 1.0, 2.1, "win"]], frontWall);
  // side walls
  wall("z", X0, Z0, Z1, [[1.4, 3.0, 0.9, 2.1, "win"]]);
  wall("z", X1, Z0, Z1, []);
  // interior
  wall("x", 0, X0, X1, [[-1.0, -0.1, 0, 2.1], [1.3, 2.3, 0, 2.1]]);
  wall("z", XM, Z0, 0, []);

  // front door slab (open)
  box(0.9, 2.12, 0.05, 1.4, 0, Z1 - 0.48, "#55706A", { ry: Math.PI / 2.4 });

  // ---------- BEDROOM ----------
  item("b2", "bedroom", [-2.6, 1.6, Z0 + 0.05], () => {
    box(2.2, 1.25, 0.03, -2.6, 0.9, Z0, null, { mat: glassMat, cast: false });
  });
  box(2.3, 0.06, 0.2, -2.6, 0.84, Z0 + 0.1, C.wall); // sill
  item("b1", "bedroom", [XM - 0.1, 1.5, -2.2], () => {
    box(0.03, 2.5, 4.1, XM - T / 2 - 0.02, 0.05, -2.25, C.wall, { cast: false });
  });
  item("b4", "bedroom", [-2.9, 0.55, -2.7], () => {
    box(1.62, 0.3, 2.1, -2.9, 0, -3.37, "#8F7A64", { round: 0.03 });
  });
  box(1.56, 0.22, 2.02, -2.9, 0.3, -3.37, C.linen, { round: 0.08 });
  box(1.64, 0.07, 1.35, -2.9, 0.5, -3.0, C.eucSoft, { round: 0.03 });
  box(0.58, 0.12, 0.34, -3.25, 0.52, -4.1, "#FFFFFF", { round: 0.05 });
  box(0.58, 0.12, 0.34, -2.55, 0.52, -4.1, "#FFFFFF", { round: 0.05 });
  box(1.72, 1.0, 0.08, -2.9, 0, Z0 + T / 2 + 0.04, "#CBB89C", { round: 0.03 });
  box(0.46, 0.5, 0.42, -1.75, 0, -4.15, C.sand, { round: 0.03 });
  cyl(0.09, 0.12, 0.28, -1.75, 0.5, -4.15, "#E9E2D3");
  box(2.1, 0.012, 1.5, -2.9, 0.01, -1.55, "#DCCFB9", { cast: false, round: 0.005 });
  item("b5", "bedroom", [X0 + 0.4, 1.4, -2.6], () => {
    box(0.6, 2.25, 2.0, X0 + T / 2 + 0.3, 0, -2.6, "#E3DACA", { round: 0.02 });
    box(0.01, 2.0, 0.006, X0 + T / 2 + 0.605, 0.12, -2.6, "#9C8F7C");
  });
  item("b3", "bedroom", [-0.6, 1.15, -0.1], () => {
    box(0.09, 0.13, 0.025, -0.6, 1.05, -T / 2 - 0.012, "#FFFFFF");
  });
  // chair
  box(0.5, 0.45, 0.5, -0.4, 0, -3.6, C.eucSoft, { round: 0.08 });

  // ---------- BATHROOM ----------
  box(X1 - XM, 0.02, -Z0, (XM + X1) / 2, 0.005, Z0 / 2, C.tile, { cast: false });
  item("w4", "bathroom", [4.4, 0.2, -1.8], () => {
    box(X1 - XM - 0.2, 0.012, -Z0 - 0.2, (XM + X1) / 2, 0.026, Z0 / 2, C.tile, { cast: false });
  });
  item("w3", "bathroom", [4.5, 0.3, -3.5], () => {
    box(1.8, 0.014, 1.9, 4.5, 0.04, -3.5, C.tileWet, { cast: false });
    cyl(0.1, 0.1, 0.02, 4.5, 0.055, -3.5, C.steel, { m: 0.6, r: 0.3 });
  });
  cyl(0.02, 0.02, 0.9, X1 - 0.12, 1.2, -3.5, C.steel, { m: 0.7, r: 0.3 });
  cyl(0.11, 0.11, 0.03, X1 - 0.2, 2.05, -3.5, C.steel, { m: 0.7, r: 0.3, rz: Math.PI / 2 });
  item("w5", "bathroom", [X1 - 0.1, 0.95, -1.9], () => {
    cyl(0.025, 0.025, 1.3, X1 - T / 2 - 0.09, 0.9, -1.9, C.steel, { m: 0.8, r: 0.25, rx: Math.PI / 2 });
  });
  item("w1", "bathroom", [1.7, 1.2, Z0 + 0.3], () => {
    box(0.95, 1.15, 0.16, 1.7, 0, Z0 + T / 2 + 0.08, "#ECE8E0", { round: 0.02 });
    box(0.22, 0.15, 0.015, 1.7, 0.95, Z0 + T / 2 + 0.165, C.steel, { m: 0.6, r: 0.3 });
    box(0.4, 0.38, 0.56, 1.7, 0.02, Z0 + T / 2 + 0.44, "#FFFFFF", { round: 0.14, r: 0.35 });
  });
  item("w2", "bathroom", [XM + 0.35, 1.0, -1.9], () => {
    box(0.5, 0.75, 1.0, XM + T / 2 + 0.25, 0.08, -1.9, "#D7CCBA", { round: 0.03 });
    box(0.54, 0.06, 1.04, XM + T / 2 + 0.27, 0.83, -1.9, "#F2F0EB", { round: 0.02 });
    cyl(0.025, 0.025, 0.18, XM + T / 2 + 0.08, 0.89, -1.9, C.steel, { m: 0.7, r: 0.3 });
  });
  box(0.02, 0.75, 0.7, XM + T / 2 + 0.01, 1.2, -1.9, "#C9D2D3", { m: 0.6, r: 0.15 });

  // ---------- KITCHEN ----------
  item("k3", "kitchen", [X1 - 0.35, 0.5, 2.0], () => {
    box(0.62, 0.86, 3.0, X1 - T / 2 - 0.31, 0.02, 1.9, C.euc, { round: 0.02 });
    box(0.62, 0.86, 2.3, 3.75, 0.02, T / 2 + 0.31, C.euc, { round: 0.02 });
  });
  item("k4", "kitchen", [3.4, 1.0, 3.0], () => {
    box(0.66, 0.05, 3.05, X1 - T / 2 - 0.33, 0.88, 1.9, "#EEEBE4", { round: 0.02, r: 0.4 });
    box(2.34, 0.05, 0.66, 3.75, 0.88, T / 2 + 0.33, "#EEEBE4", { round: 0.02, r: 0.4 });
    box(1.7, 0.06, 0.95, 3.25, 0.88, 3.0, "#EEEBE4", { round: 0.03, r: 0.4 });
  });
  box(1.6, 0.86, 0.85, 3.25, 0.02, 3.0, "#E3DACA", { round: 0.02 });
  box(0.7, 0.012, 0.5, 3.75, 0.93, 0.36, C.dark, { r: 0.3 }); // cooktop
  item("k1", "kitchen", [4.95, 1.6, 4.0], () => {
    box(0.68, 1.9, 0.82, X1 - T / 2 - 0.36, 0, 4.0, "#D5D9D8", { round: 0.03, r: 0.4, m: 0.15 });
    box(0.66, 0.5, 0.02, 3.75, 0.18, T / 2 + 0.63, "#4C6A60", { round: 0.005 });
  });
  item("k2", "kitchen", [4.7, 1.25, 0.1], () => {
    box(0.12, 0.12, 0.03, 4.75, 1.15, T / 2 + 0.015, C.sun);
  });
  [2.75, 3.75].forEach((x) => {
    cyl(0.17, 0.17, 0.05, x, 0.62, 3.75, C.sand);
    cyl(0.02, 0.02, 0.62, x, 0, 3.75, C.dark, { seg: 8 });
  });

  // ---------- LIVING ----------
  item("l1", "living", [-2.6, 1.55, 0.15], () => {
    box(1.5, 0.86, 0.04, -2.6, 1.1, T / 2 + 0.02, C.dark, { r: 0.3 });
    box(1.66, 1.0, 0.03, -2.6, 1.03, T / 2 + 0.07, "#D8EAEE", { t: true, o: 0.35, r: 0.05, cast: false });
  });
  box(1.9, 0.42, 0.42, -2.6, 0, T / 2 + 0.21, "#D6C9B3", { round: 0.03 });
  item("l2", "living", [X0 + 0.1, 1.6, 0.9], () => {
    box(0.03, 2.5, 1.2, X0 + T / 2 + 0.02, 0.05, 0.75, C.wall, { cast: false });
    box(0.03, 2.5, 1.3, X0 + T / 2 + 0.02, 0.05, 3.75, C.wall, { cast: false });
  });
  item("l3", "living", [-2.8, 1.5, Z1 - 0.05], () => {
    box(3.2, 1.65, 0.03, -2.8, 0.55, Z1, null, { mat: glassMat, cast: false });
  });
  // sofa facing the TV
  box(2.3, 0.4, 0.95, -2.6, 0.02, 3.2, C.greige, { round: 0.1 });
  box(2.3, 0.5, 0.25, -2.6, 0.35, 3.55, C.greige, { round: 0.1 });
  box(0.24, 0.55, 0.95, -3.7, 0.02, 3.2, C.greige, { round: 0.1 });
  box(0.24, 0.55, 0.95, -1.5, 0.02, 3.2, C.greige, { round: 0.1 });
  box(0.5, 0.36, 0.14, -3.2, 0.42, 3.38, C.eucSoft, { round: 0.06 });
  box(1.1, 0.36, 0.6, -2.6, 0, 1.9, C.sand, { round: 0.06 });
  box(3.0, 0.012, 2.1, -2.6, 0.01, 2.4, "#E6DCC9", { cast: false });
  item("l4", "living", [X0 + 0.4, 1.0, 2.25], () => {
    box(0.38, 1.55, 1.3, X0 + T / 2 + 0.2, 0, 2.25, "#CDB79A", { round: 0.02 });
  });
  // plant
  cyl(0.18, 0.14, 0.4, -0.2, 0, 3.9, "#D9CDB8");
  const leaf = new THREE.Mesh(new THREE.IcosahedronGeometry(0.42, 0), shared("#6F8F73"));
  leaf.position.set(-0.2, 0.85, 3.9);
  add(leaf);
  // dining table between living and kitchen
  box(1.2, 0.05, 0.8, 0.3, 0.72, 1.6, C.sand, { round: 0.02 });
  cyl(0.04, 0.04, 0.72, 0.3, 0, 1.6, C.dark, { seg: 8 });

  // ---------- ROOF ----------
  const roof = new THREE.Group();
  const eave = new THREE.Mesh(new THREE.BoxGeometry(W + 0.9, 0.16, D + 0.9), shared(C.fascia, { r: 0.6 }));
  eave.position.set(0, H + 0.08, 0);
  eave.castShadow = true;
  roof.add(eave);
  const cone = new THREE.Mesh(new THREE.ConeGeometry(1, 1, 4, 1), shared(C.roof, { r: 0.55, m: 0.25 }));
  cone.rotation.y = Math.PI / 4;
  cone.scale.set((W + 0.9) / Math.SQRT2, 2.3, (D + 0.9) / Math.SQRT2);
  cone.position.set(0, H + 0.16 + 1.15, 0);
  cone.castShadow = true;
  roof.add(cone);
  root.add(roof);
  roof.traverse((o) => {
    if (o.material) {
      o.material = o.material.clone();
      o.material.transparent = true;
    }
  });

  return { root, items, roof, frontWall, shadowSize: mobile ? 1024 : 2048 };
}

// Lights + renderer helpers shared by both 3D modules
export function setupStage(THREE, renderer, scene, shadowSize) {
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  scene.background = new THREE.Color("#F2EEE5");
  const hemi = new THREE.HemisphereLight("#FFF7EA", "#CBC3B2", 1.25);
  scene.add(hemi);
  const sun = new THREE.DirectionalLight("#FFE7C4", 2.3);
  sun.position.set(9, 15, 7);
  sun.castShadow = true;
  sun.shadow.mapSize.set(shadowSize, shadowSize);
  const s = sun.shadow.camera;
  s.left = -11; s.right = 11; s.top = 11; s.bottom = -11; s.near = 1; s.far = 45;
  sun.shadow.bias = -0.0004;
  sun.shadow.normalBias = 0.02;
  sun.shadow.radius = 4;
  scene.add(sun);
  const fill = new THREE.DirectionalLight("#DCE8F2", 0.45);
  fill.position.set(-8, 6, -6);
  scene.add(fill);
}

// level: 0 off, 1 tint, 2 active
export function highlight(THREE, item, level) {
  const tint = new THREE.Color(level === 2 ? "#EFAE2E" : "#F2C77E");
  for (const m of item.meshes) {
    const base = m.userData.base;
    if (!base) continue;
    if (level === 0) {
      m.material.color.copy(base.color);
      m.material.emissive?.setRGB(0, 0, 0);
      m.material.opacity = base.opacity;
    } else {
      m.material.color.copy(base.color).lerp(tint, level === 2 ? 0.75 : 0.45);
      m.material.emissive?.copy(tint).multiplyScalar(level === 2 ? 0.28 : 0.1);
      if (base.opacity < 1) m.material.opacity = Math.min(1, base.opacity + 0.25);
    }
  }
}
