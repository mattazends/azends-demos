import { HeadContent, Outlet, Scripts, createRootRoute } from "@tanstack/react-router";
import { DefaultCatchBoundary } from "@/components/DefaultCatchBoundary";
import { NotFound } from "@/components/NotFound";
import { Toaster } from "@/components/ui/sonner";
import { AuthProvider } from "@/lib/AuthContext";
import { Base44Scripts } from "base44:document";
import appCss from "@/index.css?url";
import siteCss from "@/styles/site.css?url";
import { AudienceProvider, Header, Footer, MobileBar, useReveal } from "@/components/site/Shell";
import { useLiquidGlass } from "@/components/site/liquid";

const LD = {
  "@context": "https://schema.org",
  "@type": "HomeAndConstructionBusiness",
  name: "Soluna Facilities Management",
  alternateName: "Soluna FM",
  url: "https://solunafm.com.au",
  description: "Maintenance, modifications, renovations and compliance for disability and aged care homes, plus SIL home set-ups, Robust Plus upgrades and aged care renovations.",
  areaServed: ["Melbourne", "Geelong", "Bendigo", "Regional Victoria"].map((n) => ({ "@type": "Place", name: `${n}, VIC, Australia` })),
  knowsAbout: ["SDA maintenance", "SIL home maintenance", "SIL home set-up", "Robust SDA upgrades", "Home modifications", "Aged care renovations", "Aged care facility maintenance", "Fire equipment servicing", "SIL compliance"],
};

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { title: "Soluna Facilities Management | Maintenance, Modifications and Renovations for Disability and Aged Care Homes" },
      { name: "description", content: "Maintenance, modifications, renovations and compliance for disability and aged care homes across metropolitan Melbourne and regional Victoria." },
      { name: "theme-color", content: "#F6F3EC" },
      { property: "og:site_name", content: "Soluna Facilities Management" },
      { property: "og:type", content: "website" },
      { property: "og:locale", content: "en_AU" },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Inter+Tight:wght@300;400;500;600&family=Inter:wght@400;500;600&display=swap" },
      { rel: "preconnect", href: "https://images.pexels.com" },
      { rel: "stylesheet", href: appCss },
      { rel: "stylesheet", href: siteCss },
    ],
    scripts: [{ type: "application/ld+json", children: JSON.stringify(LD) }],
  }),
  errorComponent: DefaultCatchBoundary,
  notFoundComponent: () => <NotFound />,
  shellComponent: RootDocument,
  component: RootComponent,
});

function Site() {
  useReveal();
  useLiquidGlass();
  return (
    <>
      <Header />
      <main>
        <Outlet />
      </main>
      <Footer />
      <MobileBar />
    </>
  );
}

function RootComponent() {
  return (
    <AuthProvider>
      <AudienceProvider>
        <Site />
      </AudienceProvider>
      <Toaster />
    </AuthProvider>
  );
}

function RootDocument({ children }) {
  return (
    <html lang="en-AU">
      <head>
        <HeadContent />
      </head>
      <body data-react-root="true">
        {children}
        <Base44Scripts />
        <Scripts />
      </body>
    </html>
  );
}
