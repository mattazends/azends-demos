import { createFileRoute, notFound, Link } from "@tanstack/react-router";
import { AREAS, AREA_ORDER, SERVICES, SERVICE_ORDER } from "@/lib/content";
import { Faq, CtaEnd, Arrow } from "@/components/site/Shell";
import { AreasMap, HowItRuns, Versus } from "@/components/site/Sections";

export const Route = createFileRoute("/areas/$area")({
  loader: ({ params }) => {
    const a = AREAS[params.area];
    if (!a) throw notFound();
    return a;
  },
  head: ({ loaderData: a }) => ({
    meta: a
      ? [
          { title: `Supported home maintenance in ${a.name} | Soluna FM` },
          { name: "description", content: a.lede },
          { property: "og:title", content: `${a.name} | Soluna Facilities Management` },
        ]
      : [],
  }),
  component: AreaPage,
});

function AreaPage() {
  const a = Route.useLoaderData();
  const faqs = [
    [`Do you cover all of ${a.name}?`, a.note],
    ["What can you help with?", "Property maintenance, modifications, renovations and compliance services, plus SIL home set-ups, aged care renovations and Robust Plus upgrades."],
    ["Do you provide urgent repairs?", "Yes. We respond to urgent maintenance requests, subject to location and team availability. Tell us it's urgent when you request a quote and we'll contact you to arrange the appropriate response."],
    ["Who do you work with?", `SIL providers, SDA providers and owners, aged care providers and families in ${a.name}.`],
  ];
  return (
    <>
      <section className="phero">
        <div className="wrap phero-g" style={{ alignItems: "center" }}>
          <div>
            <span className="eyebrow rv">{a.name}</span>
            <h1 className="rv d1">{a.h1}</h1>
            <p className="lede rv d2">{a.lede}</p>
            <div className="rv d3">
              <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginTop: 30 }}>
                <Link to="/contact" className="btn btn-sun">
                  Request a Quote in {a.name} <Arrow />
                </Link>
                <Link to="/robust-plus" className="btn btn-line">
                  Robust Plus
                </Link>
              </div>
            </div>
          </div>
          <AreasMap focus={a.slug} />
        </div>
      </section>
      <section className="sec" style={{ paddingTop: 40 }}>
        <div className="wrap">
          <span className="eyebrow rv">What we do in {a.name}</span>
          <div className="inc">
            {SERVICE_ORDER.map((k, i) => (
              <Link key={k} to={`/${k}`} className={`rv d${i}`} style={{ display: "block" }}>
                <div>
                  <span className="k">0{i + 1}</span>
                  <b>{SERVICES[k].name}</b>
                  <p>{SERVICES[k].blurb}</p>
                </div>
              </Link>
            ))}
            <Link to="/robust-plus" className="rv d3" style={{ display: "block" }}>
              <div>
                <span className="k">Our Expertise</span>
                <b>Robust Plus</b>
                <p>Specialist reinforcement and protective upgrades tailored to individual support needs, creating more durable living environments without compromising the comfort of home.</p>
              </div>
            </Link>
          </div>
        </div>
      </section>
      <Versus />
      <HowItRuns />
      <section className="sec">
        <div className="wrap">
          <span className="eyebrow rv">Other areas</span>
          <div className="area-list rv d1">
            {AREA_ORDER.filter((k) => k !== a.slug).map((k) => (
              <Link key={k} to="/areas/$area" params={{ area: k }}>
                {AREAS[k].name}
                <Arrow />
              </Link>
            ))}
          </div>
        </div>
      </section>
      <Faq items={faqs} title={`${a.name} questions`} />
      <CtaEnd />
    </>
  );
}
