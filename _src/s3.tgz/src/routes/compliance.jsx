import { createFileRoute } from "@tanstack/react-router";
import ServicePage, { serviceHead } from "@/components/site/ServicePage";

export const Route = createFileRoute("/compliance")({
  head: serviceHead("compliance"),
  component: () => <ServicePage slug="compliance" />,
});
