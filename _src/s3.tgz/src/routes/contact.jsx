import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import JobForm from "@/components/site/JobForm";
import { Faq } from "@/components/site/Shell";

export const Route = createFileRoute("/contact")({
  validateSearch: z.object({ who: z.string().optional(), need: z.string().optional() }),
  head: () => ({
    meta: [
      { title: "Request a Quote | Soluna Facilities Management" },
      { name: "description", content: "Request a quote for maintenance, modifications, renovations, compliance, SIL home set-ups or Robust Plus upgrades. Metropolitan Melbourne and regional Victoria." },
    ],
  }),
  component: Contact,
});

function Contact() {
  return (
    <>
      <section className="phero" style={{ paddingBottom: "clamp(72px,9vw,120px)" }}>
        <div className="wrap form-g">
          <div>
            <span className="eyebrow rv">Request a quote</span>
            <h1 className="rv d1" style={{ fontSize: "clamp(44px,5.6vw,80px)" }}>
              Tell us what <b>the property needs.</b>
            </h1>
            <p className="lede rv d2">Four quick steps and your contact details. Add photos if helpful. Our team will contact you to discuss the requirements and next steps.</p>
            <ol className="next rv d3">
              <li>
                <b>1</b>
                <div>
                  <h4>Tell us what you need</h4>
                  <p>Select the service and timeframe, and describe the work.</p>
                </div>
              </li>
              <li>
                <b>2</b>
                <div>
                  <h4>We contact you</h4>
                  <p>Our team will discuss the requirements and next steps.</p>
                </div>
              </li>
              <li>
                <b>3</b>
                <div>
                  <h4>Assessment and quotation</h4>
                  <p>Scoped to the property and the people living in it.</p>
                </div>
              </li>
            </ol>
            <p className="note rv d4">We service metropolitan Melbourne and regional Victoria.</p>
          </div>
          <div className="rv d1">
            <JobForm />
          </div>
        </div>
      </section>
      <Faq />
    </>
  );
}
