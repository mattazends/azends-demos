import { createFileRoute } from "@tanstack/react-router";
import { AGED_PAGE } from "@/lib/expertise";
import ExpertisePage, { expertiseHead } from "@/components/site/ExpertisePage";

export const Route = createFileRoute("/expertise/aged-care-renovations")({
  head: expertiseHead(AGED_PAGE),
  component: () => <ExpertisePage page={AGED_PAGE} />,
});
