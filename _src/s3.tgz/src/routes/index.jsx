import { createFileRoute } from "@tanstack/react-router";
import { Faq } from "@/components/site/Shell";
import { HeroRoom, RoomCompare } from "@/components/site/RoomModes";
import { QuickStart, Strip, Versus, Audiences, ServicesList, HowItRuns, Areas } from "@/components/site/Sections";
import HouseWalk from "@/components/site/HouseWalk";
import JobForm from "@/components/site/JobForm";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Soluna Facilities Management | Maintenance, Modifications and Renovations for Disability and Aged Care Homes" },
      { name: "description", content: "Maintenance, modifications, renovations and compliance for disability and aged care homes, plus SIL home set-ups, Robust Plus upgrades and aged care renovations across metropolitan Melbourne and regional Victoria." },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  return (
    <>
      <HeroRoom>
        <div className="wrap">
          <QuickStart />
        </div>
      </HeroRoom>
      <Strip />
      <RoomCompare />
      <Versus />
      <Audiences />
      <HouseWalk />
      <ServicesList />
      <HowItRuns />
      <Areas />
      <Faq />
      <section className="sec form-sec" id="log">
        <div className="wrap form-g">
          <div>
            <span className="eyebrow rv">Request a quote</span>
            <h2 className="sec-t rv d1">
              Tell us what you need. <b>We'll be in touch.</b>
            </h2>
            <p className="lede rv d2">Four quick steps and your contact details. Add photos if helpful.</p>
            <ol className="next rv d3">
              <li>
                <b>1</b>
                <div>
                  <h4>Tell us what you need</h4>
                  <p>Select the service and timeframe, and describe the work.</p>
                </div>
              </li>
              <li>
                <b>2</b>
                <div>
                  <h4>We contact you</h4>
                  <p>Our team will discuss the requirements and next steps.</p>
                </div>
              </li>
              <li>
                <b>3</b>
                <div>
                  <h4>Assessment and quotation</h4>
                  <p>Scoped to the property and the people living in it.</p>
                </div>
              </li>
            </ol>
          </div>
          <div className="rv d1">
            <JobForm compact />
          </div>
        </div>
      </section>
    </>
  );
}
