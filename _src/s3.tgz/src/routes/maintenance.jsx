import { createFileRoute } from "@tanstack/react-router";
import ServicePage, { serviceHead } from "@/components/site/ServicePage";

export const Route = createFileRoute("/maintenance")({
  head: serviceHead("maintenance"),
  component: () => <ServicePage slug="maintenance" />,
});
