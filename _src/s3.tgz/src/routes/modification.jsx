import { createFileRoute } from "@tanstack/react-router";
import ServicePage, { serviceHead } from "@/components/site/ServicePage";

export const Route = createFileRoute("/modification")({
  head: serviceHead("modification"),
  component: () => <ServicePage slug="modification" />,
});
