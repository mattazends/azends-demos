import { createFileRoute } from "@tanstack/react-router";
import { PHOTOS, px } from "@/lib/content";
import { PageHero, CtaEnd } from "@/components/site/Shell";
import { Audiences, HowItRuns } from "@/components/site/Sections";

export const Route = createFileRoute("/our-story")({
  head: () => ({
    meta: [
      { title: "Our story | Soluna Facilities Management" },
      { name: "description", content: "Soluna grew out of facilities work inside supported homes. We understand construction, and we understand the person in the room." },
    ],
  }),
  component: Story,
});

function Story() {
  return (
    <>
      <PageHero
        eyebrow="Our story"
        title={
          <>
            We started inside supported homes. <b>That's still where we work.</b>
          </>
        }
        lede="Soluna grew out of facilities work in homes where people with complex needs live. Providers who saw how our team worked kept asking us to look after their houses too. So we made it its own company."
        photo={px(PHOTOS.calm, 1200)}
        alt="A comfortable living room with a sofa and armchair"
      />
      <section className="sec">
        <div className="wrap">
          <p className="quote rv">
            Most trades understand buildings. Fewer understand the people living in them. <b>We built Soluna to do both.</b>
          </p>
          <div className="values">
            <div className="rv">
              <b>The person comes first</b>
              <p>We plan the job around the person's routine, and we stop when they need us to.</p>
            </div>
            <div className="rv d1">
              <b>Fix it properly</b>
              <p>We don't just patch the damage. We fix it so it's less likely to come back.</p>
            </div>
            <div className="rv d2">
              <b>Show the work</b>
              <p>Every job is photographed and logged, so you always know what happened in the house.</p>
            </div>
          </div>
        </div>
      </section>
      <Audiences />
      <HowItRuns />
      <CtaEnd />
    </>
  );
}
