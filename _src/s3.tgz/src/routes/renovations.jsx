import { createFileRoute } from "@tanstack/react-router";
import ServicePage, { serviceHead } from "@/components/site/ServicePage";

export const Route = createFileRoute("/renovations")({
  head: serviceHead("renovations"),
  component: () => <ServicePage slug="renovations" />,
});
