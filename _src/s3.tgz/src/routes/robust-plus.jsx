import { createFileRoute } from "@tanstack/react-router";
import { ROOMS, ROOM_ORDER, PHOTOS, RP_FAQS, RP_FEATS, px } from "@/lib/content";
import { PageHero, Faq, CtaEnd } from "@/components/site/Shell";
import { FeatureList } from "@/components/site/Sections";
import RoomExplorer from "@/components/site/RoomExplorer";

const DESC = "Robust Plus strengthens existing homes, including SDA Robust properties, with tailored wall reinforcement, protected fixtures and secured furniture, while preserving the comfort and character of home.";

export const Route = createFileRoute("/robust-plus")({
  head: () => ({
    meta: [
      { title: "Robust Plus: room-by-room upgrades for SDA and SIL homes | Soluna FM" },
      { name: "description", content: DESC },
      { property: "og:title", content: "Robust Plus | Soluna Facilities Management" },
      { property: "og:description", content: DESC },
    ],
  }),
  component: RobustPlus,
});

function RobustPlus() {
  return (
    <>
      <PageHero
        eyebrow="Robust Plus"
        title={
          <>
            Built for the hard days. <b>Still looks like a home.</b>
          </>
        }
        lede={DESC}
        photo={px(PHOTOS.livingAlt, 1200)}
        alt="Light living room with a sofa and a glass door to the garden"
        crumbs={["Four Rooms", "Two Tiers", "Non-Structural Upgrades"]}
        cta2={{ href: "#explore", label: "Explore Each Room" }}
      />
      <section id="explore" style={{ paddingBottom: "clamp(72px,9vw,120px)", scrollMarginTop: 90 }}>
        <div className="wrap">
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "end", gap: 20, flexWrap: "wrap", marginBottom: 24 }}>
            <div>
              <span className="eyebrow rv">Explore each room</span>
              <h2 className="sec-t rv d1" style={{ marginBottom: 0 }}>
                Turn the room. <b>Tap an upgrade.</b>
              </h2>
            </div>
            <p className="mute rv d2" style={{ maxWidth: 380 }}>Switch between Tier 1 and Tier 1 + 2 to see what changes. Each number lights up the part of the room it covers.</p>
          </div>
          <RoomExplorer />
          <p className="note">Example scope for illustration. Every upgrade is specified for the home and the person after a site visit.</p>
        </div>
      </section>
      <section className="sec" style={{ background: "var(--paper2)" }}>
        <div className="wrap">
          <span className="eyebrow rv">Two tiers</span>
          <h2 className="sec-t rv d1">
            Start with what keeps failing. <b>Go further where it's needed.</b>
          </h2>
          <div className="tiers">
            <div className="tier-c rv">
              <span className="pill sun">Tier 1</span>
              <h3>The essentials</h3>
              <p>Stops the repairs that keep coming back.</p>
              <ul>
                {ROOM_ORDER.flatMap((r) => ROOMS[r].items.filter((i) => i.tier === 1).slice(0, 2).map((i) => <li key={i.id}>{ROOMS[r].name}: {i.title.toLowerCase()}</li>))}
              </ul>
            </div>
            <div className="tier-c dark rv d1">
              <span className="pill sun">Tier 1 + 2</span>
              <h3>For higher needs</h3>
              <p>Everything in Tier 1, plus fixed furniture and stronger finishes.</p>
              <ul>
                {ROOM_ORDER.flatMap((r) => ROOMS[r].items.filter((i) => i.tier === 2).map((i) => <li key={i.id}>{ROOMS[r].name}: {i.title.toLowerCase()}</li>))}
              </ul>
            </div>
          </div>
        </div>
      </section>
      <FeatureList
        eyebrow="Our approach"
        title={
          <>
            Protection Designed <b>Around Individual Needs</b>
          </>
        }
        lede="Robust Plus combines specialist property reinforcement with an understanding of individual support needs, creating stronger living environments without compromising comfort."
        items={RP_FEATS}
        bg="transparent"
      />
      <Faq items={RP_FAQS} title="Robust Plus questions" />
      <CtaEnd />
    </>
  );
}
