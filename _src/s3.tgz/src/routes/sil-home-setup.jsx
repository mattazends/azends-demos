import { createFileRoute } from "@tanstack/react-router";
import { SIL_PAGE } from "@/lib/expertise";
import ExpertisePage, { expertiseHead } from "@/components/site/ExpertisePage";

export const Route = createFileRoute("/sil-home-setup")({
  head: expertiseHead(SIL_PAGE),
  component: () => <ExpertisePage page={SIL_PAGE} />,
});
