import { createFileRoute } from "@tanstack/react-router";

const BASE = "https://solunafm.com.au";
const PATHS = ["/", "/robust-plus", "/maintenance", "/modification", "/renovations", "/compliance", "/sil-home-setup", "/expertise/aged-care-renovations", "/our-story", "/contact", "/areas/melbourne", "/areas/geelong", "/areas/bendigo", "/areas/regional-victoria"];

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async () => {
        const body = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${PATHS.map((p) => `  <url><loc>${BASE}${p}</loc></url>`).join("\n")}\n</urlset>\n`;
        return new Response(body, { headers: { "content-type": "application/xml; charset=utf-8", "cache-control": "public, max-age=3600" } });
      },
    },
  },
});
