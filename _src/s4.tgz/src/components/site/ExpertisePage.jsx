import { Check, Signpost, Lamp, ShieldCheck, Accessibility, FolderOpen } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { IMG } from "@/lib/content";
import { PageHero, Faq, CtaEnd, Arrow, rich } from "./Shell";
import { FeatureList, Areas } from "./Sections";

const ICONS = { signpost: Signpost, lamp: Lamp, shield: ShieldCheck, accessibility: Accessibility };
const T = ({ t }) => (
  <>
    {t[0]} <b>{t[1]}</b>
  </>
);

export function expertiseHead(p) {
  return () => ({
    meta: [
      { title: p.seoTitle },
      { name: "description", content: p.seoDesc },
      { property: "og:title", content: p.seoTitle },
      { property: "og:description", content: p.seoDesc },
    ],
  });
}

function Duo({ b }) {
  return (
    <section className="sec">
      <div className="wrap">
        <span className="eyebrow rv">{b.eyebrow}</span>
        <h2 className="sec-t rv d1">
          <T t={b.title} />
        </h2>
        <p className="lede rv d2">{b.lede}</p>
        <div className="duo">
          {b.cards.map((c, i) => (
            <div key={c.name} className={`duo-c rv d${i}`}>
              <span className="duo-ph">
                <img src={IMG(c.img)} alt="" loading="lazy" />
              </span>
              <div className="duo-t">
                <h3>{c.name}</h3>
                <p>{c.d}</p>
                <span className="k">{c.k}</span>
                <ul>
                  {c.list.map((x) => (
                    <li key={x}>
                      <Check />
                      {x}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
        {b.note && <p className="xnote rv">{b.note}</p>}
        {b.close && <p className="xclose rv">{b.close}</p>}
      </div>
    </section>
  );
}

function Band({ b }) {
  return (
    <section className="sec">
      <div className="wrap">
        <div className="band rv">
          <div className="band-l">
            <span className="eyebrow lt">{b.eyebrow}</span>
            <h2>
              <T t={b.title} />
            </h2>
            {b.paras.map((p) => (
              <p key={p}>{p}</p>
            ))}
            <div className="band-res">
              <span>{b.resultK}</span>
              <p>{b.result}</p>
            </div>
          </div>
          <div className="band-r">
            <span className="k">{b.k}</span>
            <ul>
              {b.list.map((x, i) => (
                <li key={x}>
                  <i>{String(i + 1).padStart(2, "0")}</i>
                  {x}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}

function FileBlock({ b }) {
  return (
    <section className="sec">
      <div className="wrap grid2 filex">
        <div>
          <span className="eyebrow rv">{b.eyebrow}</span>
          <h2 className="sec-t rv d1">
            <T t={b.title} />
          </h2>
          {b.paras.map((p) => (
            <p key={p} className="lede rv d2" style={{ marginBottom: 14 }}>
              {p}
            </p>
          ))}
          {b.note && <p className="xnote rv d3">{b.note}</p>}
          {b.close && <p className="xclose rv d3">{b.close}</p>}
        </div>
        <div className="rec filecard rv d1">
          <div className="rec-h">
            <div>
              <b>{b.fileTitle}</b>
              <br />
              <small>{b.fileSub}</small>
            </div>
            <span className="pill">
              <FolderOpen style={{ width: 13, height: 13 }} /> {b.list.length} items
            </span>
          </div>
          {b.list.map((x) => (
            <div key={x} className="rec-row on">
              <i>
                <Check />
              </i>
              <div>
                <b>{x}</b>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Quad({ b }) {
  return (
    <section className="sec">
      <div className="wrap">
        <div className="band quad rv">
          {b.img && (
            <div className="band-img">
              <img src={IMG(b.img)} alt={b.imgAlt || ""} loading="lazy" />
            </div>
          )}
          <div className="band-l">
            <span className="eyebrow lt">{b.eyebrow}</span>
            <h2>
              <T t={b.title} />
            </h2>
            {b.paras.map((p) => (
              <p key={p}>{p}</p>
            ))}
            <div className="band-res">
              <p>{b.close}</p>
            </div>
          </div>
          <div className="quad-g">
            {b.items.map(([ic, t, d]) => {
              const I = ICONS[ic];
              return (
                <div key={t}>
                  <i>
                    <I />
                  </i>
                  <b>{t}</b>
                  <p>{d}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}

// Shared layout for the SIL Home Set-up and Aged Care Renovations pages.
export default function ExpertisePage({ page: p }) {
  return (
    <>
      <PageHero eyebrow={p.eyebrow} title={<T t={p.h1} />} lede={p.lede} photo={IMG(p.img)} crumbs={p.tags} cta2={p.cta2} />
      <section className="sec" style={{ paddingTop: 40 }}>
        <div className="wrap grid2 introx">
          <h2 className="sec-t rv">
            <T t={p.intro.title} />
          </h2>
          <div>
            {p.intro.paras.map((t, i) => (
              <p key={t} className={`rv d${i % 3}`}>
                {rich(t)}
              </p>
            ))}
          </div>
        </div>
      </section>
      <section className="sec" id="included" style={{ background: "var(--paper2)", scrollMarginTop: 70 }}>
        <div className="wrap">
          <span className="eyebrow rv">What's included</span>
          <h2 className="sec-t rv d1">
            <T t={p.inc.title} />
          </h2>
          <p className="lede rv d2">{p.inc.lede}</p>
          <div className="inc">
            {p.inc.items.map(([t, d], i) => (
              <div key={t} className={`rv d${i % 2}`}>
                <span className="k">0{i + 1}</span>
                <b>{t}</b>
                <p>{d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      {p.blocks.map((b) =>
        b.type === "duo" ? (
          <Duo key={b.eyebrow} b={b} />
        ) : b.type === "band" ? (
          <Band key={b.eyebrow} b={b} />
        ) : b.type === "file" ? (
          <FileBlock key={b.eyebrow} b={b} />
        ) : b.type === "quad" ? (
          <Quad key={b.eyebrow} b={b} />
        ) : (
          <FeatureList key="feats" eyebrow={p.feats.eyebrow} title={<T t={p.feats.title} />} lede={p.feats.lede} items={p.feats.items} />
        ),
      )}
      <section className="sec" style={{ background: "var(--paper2)" }}>
        <div className="wrap">
          <span className="eyebrow rv">Also from Soluna</span>
          <h2 className="sec-t rv d1">
            <T t={p.also.title} />
          </h2>
          <div className="inc c3" style={{ marginTop: 24 }}>
            {p.also.items.map(([slug, name, d], i) => (
              <Link key={slug} to={`/${slug}`} className={`rv d${i}`} style={{ display: "block" }}>
                <div>
                  <span className="k">0{i + 1}</span>
                  <b>{name}</b>
                  <p>{d}</p>
                  <span className="tlink" style={{ marginTop: 18 }}>
                    Learn More <Arrow />
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
      <Areas lede={p.areasLede} cta />
      <Faq items={p.faqs} title={p.faqTitle} />
      <CtaEnd title={<T t={p.cta.title} />} lede={p.cta.lede} cta2={{ to: "/contact", label: "Contact Us" }} who={p.who} need={p.need} />
    </>
  );
}
