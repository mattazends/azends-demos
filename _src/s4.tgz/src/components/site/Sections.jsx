import { useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Check, X, Home, Building2, HeartHandshake, Users } from "lucide-react";
import { AUDIENCES, HOW, AREAS, AREA_ORDER, SERVICES, SERVICE_ORDER, EXPERTISE, STRIP, VERSUS, IMG } from "@/lib/content";
import { useAudience, useWords, Arrow } from "./Shell";

/* ---------- live job record ---------- */
export function JobRecord({ loop = true, start = true }) {
  const w = useWords();
  const rows = [
    ["Requirements assessed", "Property, scope and individual needs"],
    ["Trades and materials arranged", "Scheduled with the " + w.contact],
    ["Work coordinated around the household", "Daily routines kept in place"],
    ["Repair completed to the agreed scope", "Bedroom 2"],
    ["Photos and completion details recorded", "4 photos added to the record"],
  ];
  const [n, setN] = useState(0);
  useEffect(() => {
    if (!start) return;
    const id = setInterval(() => setN((x) => (x >= rows.length + 2 ? (loop ? 0 : x) : x + 1)), 1100);
    return () => clearInterval(id);
  }, [start, loop, rows.length]);
  return (
    <div className="rec">
      <div className="rec-h">
        <div>
          <b>Job #2041</b>
          <br />
          <small>Bedroom wall · Melbourne</small>
        </div>
        <span className={`pill ${n > rows.length ? "" : "sun"}`}>{n > rows.length ? "Complete" : "In progress"}</span>
      </div>
      {rows.map(([t, s], i) => (
        <div key={t} className={`rec-row ${n > i ? "on" : ""}`}>
          <i>
            <Check />
          </i>
          <div>
            <b>{t}</b>
            <span>{s}</span>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ---------- quick start ---------- */
const QS_ICONS = { sil: Home, sda: Building2, aged: HeartHandshake, family: Users };
export function QuickStart() {
  const { setAud } = useAudience();
  return (
    <div className="qs rv d2">
      <div>
        <h3>Who looks after the house?</h3>
        <p>Pick one to start your enquiry. It takes about a minute.</p>
      </div>
      <div className="qs-g">
        {Object.values(AUDIENCES).map((a) => {
          const I = QS_ICONS[a.key];
          return (
            <Link key={a.key} to="/contact" search={{ who: a.key }} className="tile" onClick={() => setAud(a.key)}>
              <span className="tile-i">
                <I />
              </span>
              <span>
                <b>{a.label}</b>
                <small>{a.sub}</small>
              </span>
              <svg className="go" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true">
                <path d="M4 10h12M11 5l5 5-5 5" />
              </svg>
            </Link>
          );
        })}
      </div>
    </div>
  );
}

/* ---------- marquee ---------- */
export function Strip() {
  const all = [...STRIP, ...STRIP];
  return (
    <div className="strip" aria-hidden="true">
      <div className="strip-t">
        {all.map((t, i) => (
          <span key={i}>
            <i />
            {t}
          </span>
        ))}
      </div>
    </div>
  );
}

/* ---------- general tradie vs soluna ---------- */
export function Versus() {
  const rows = VERSUS;
  return (
    <section className="sec">
      <div className="wrap vsx">
        <div className="vsx-l">
          <span className="eyebrow rv">Why Soluna</span>
          <h2 className="sec-t rv d1">
            We understand construction. <b>And the person in the room.</b>
          </h2>
          <p className="lede rv d2">From everyday repairs to major renovations, we combine building expertise with an understanding of disability and aged care environments.</p>
          <div className="vsx-ph rv d2">
            <img src={IMG("x-maintenance")} alt="A freshly patched wall being repainted in a home hallway" loading="lazy" />
            <span>Same wall. Two very different jobs.</span>
          </div>
        </div>
        <div className="vsx-r">
          <div className="vsx-h rv">
            <span>General trades</span>
            <span>
              <i /> Soluna
            </span>
          </div>
          {rows.map(([bad, good], i) => (
            <div key={bad} className={`vsx-row rv d${i % 3}`}>
              <p className="bad">
                <X />
                {bad}
              </p>
              <p className="good">
                <i>
                  <Check />
                </i>
                {good}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- audiences ---------- */
const AUD_PHOTO = { sil: "x-sil-home", sda: "street", aged: "x-aged-lounge", family: "x-renovations" };
export function Audiences() {
  const { aud, setAud } = useAudience();
  const a = AUDIENCES[aud] || AUDIENCES.sil;
  return (
    <section className="sec" style={{ background: "var(--paper2)" }}>
      <div className="wrap">
        <span className="eyebrow rv">Who we work with</span>
        <h2 className="sec-t rv d1">
          Different properties. Different needs. <b>Tailored solutions.</b>
        </h2>
        <div className="audx-tabs rv d2" role="tablist">
          {Object.values(AUDIENCES).map((x) => (
            <button key={x.key} type="button" role="tab" className={aud === x.key ? "on" : ""} onClick={() => setAud(x.key)} aria-selected={aud === x.key}>
              {x.title}
            </button>
          ))}
        </div>
        <div className="audx rv d2">
          <div className="audx-ph">
            {Object.values(AUDIENCES).map((x) => (
              <img key={x.key} className={aud === x.key ? "on" : ""} src={IMG(AUD_PHOTO[x.key])} alt="" loading="lazy" />
            ))}
          </div>
          <div className="audx-t" key={a.key}>
            <span className="n">How we can work with you</span>
            <h3>{a.title}</h3>
            <ul>
              {a.ways.map((p) => (
                <li key={p}>
                  <Check />
                  {p}
                </li>
              ))}
            </ul>
            <Link to="/contact" search={{ who: a.key }} className="btn btn-sun" style={{ marginTop: 28 }}>
              Request a Quote <Arrow />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- services list ---------- */
export function ServicesList() {
  return (
    <>
      <section className="sec svx-sec" id="services">
        <div className="wrap">
          <span className="eyebrow rv">Services</span>
          <h2 className="sec-t rv d1">
            Maintenance, modifications, renovations <b>and compliance.</b>
          </h2>
        </div>
        <div className="svx c4">
          {SERVICE_ORDER.map((k, i) => {
            const s = SERVICES[k];
            return (
              <Link key={k} to={`/${k}`} className={`svx-c rv d${i}`}>
                <img src={IMG(s.img)} alt="" loading="lazy" />
                <span className="n">0{i + 1}</span>
                <span className="t">
                  <b>{s.name}</b>
                  <em>{s.blurb}</em>
                  <span className="go">
                    Learn more <Arrow />
                  </span>
                </span>
              </Link>
            );
          })}
        </div>
      </section>
      <Expertise />
    </>
  );
}

/* ---------- our expertise ---------- */
export function Expertise() {
  return (
    <section className="sec exx-sec">
      <div className="wrap">
        <span className="eyebrow rv">Our Expertise</span>
        <h2 className="sec-t rv d1">
          SIL home set-ups, aged care renovations <b>and Robust Plus.</b>
        </h2>
        <div className="exx">
          {EXPERTISE.map((x, i) => (
            <Link key={x.key} to={x.to} className={`exx-c rv d${i}`}>
              <span className="exx-ph">
                <img src={IMG(x.img)} alt="" loading="lazy" />
              </span>
              <span className="exx-t">
                <b>{x.name}</b>
                <em>{x.blurb}</em>
                <span className="go">
                  Learn more <Arrow />
                </span>
              </span>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- numbered feature list (shared by service pages) ---------- */
export function FeatureList({ eyebrow, title, lede, items, children, bg = "var(--paper2)" }) {
  const listRef = useRef(null);
  useEffect(() => {
    const lis = [...(listRef.current?.querySelectorAll("li") || [])];
    const io = new IntersectionObserver((es) => es.forEach((e) => e.isIntersecting && e.target.classList.add("in")), { rootMargin: "0px 0px -35% 0px" });
    lis.forEach((l) => io.observe(l));
    return () => io.disconnect();
  }, []);
  return (
    <section className="sec" style={{ background: bg }}>
      <div className="wrap how-g">
        <div className="how-l">
          <span className="eyebrow rv">{eyebrow}</span>
          <h2 className="sec-t rv d1">{title}</h2>
          {lede && <p className="lede rv d2">{lede}</p>}
          {children}
        </div>
        <ol className="how-list" ref={listRef}>
          {items.map(([t, d]) => (
            <li key={t}>
              <h4>{t}</h4>
              <p>{d}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}

/* ---------- how a job runs ---------- */
export function HowItRuns() {
  return (
    <FeatureList
      eyebrow="How a job runs"
      title={
        <>
          Every project managed with care, <b>from start to finish.</b>
        </>
      }
      lede="Whether it's a small repair or a complete renovation, we plan, coordinate and document every stage, with consideration for the people living in the property."
      items={HOW.map((s) => [s.t, s.d])}
    >
      <div className="rv d3" style={{ marginTop: 32, maxWidth: 420 }}>
        <JobRecord />
      </div>
    </FeatureList>
  );
}

/* ---------- areas ---------- */
// Simple projection of the region around Port Phillip
const proj = (lon, lat) => [((lon - 142.4) / 4.4) * 600, ((-36.0 - lat) / 2.9) * 490 + 10];
const CITIES = [
  { k: "melbourne", n: "Melbourne", c: [144.96, -37.81], r: 1 },
  { k: "geelong", n: "Geelong", c: [144.36, -38.15], r: 0.75 },
  { k: "bendigo", n: "Bendigo", c: [144.28, -36.76], r: 0.75 },
];
const REGIONAL = [[143.85, -37.56], [145.4, -36.38], [146.0, -37.4], [145.13, -38.3], [143.3, -37.9], [146.3, -38.2], [144.7, -37.3], [145.7, -36.9]];
export function AreasMap({ focus }) {
  const dots = [];
  for (let x = 12; x < 600; x += 18) for (let y = 12; y < 490; y += 18) dots.push([x, y]);
  return (
    <div className="map rv">
      <svg viewBox="0 0 600 490" preserveAspectRatio="xMidYMid slice" aria-label="Map of the areas Soluna covers in Victoria" role="img">
        {dots.map(([x, y]) => (
          <circle key={`${x}-${y}`} cx={x} cy={y} r="1.3" fill="rgba(246,243,236,.12)" />
        ))}
        <path d="M352 392 C 330 380, 318 352, 330 330 C 345 306, 380 300, 392 322 C 404 345, 396 372, 380 392 Z" fill="rgba(157,184,172,.16)" stroke="rgba(157,184,172,.35)" />
        {REGIONAL.map(([lo, la]) => {
          const [x, y] = proj(lo, la);
          return <circle key={`${lo}`} cx={x} cy={y} r="5" fill="rgba(239,174,46,.45)" />;
        })}
        {CITIES.map((c) => {
          const [x, y] = proj(...c.c);
          const on = !focus || focus === c.k;
          return (
            <g key={c.k} opacity={on ? 1 : 0.45}>
              <circle cx={x} cy={y} r={70 * c.r} fill="rgba(239,174,46,.07)">
                <animate attributeName="r" values={`${50 * c.r};${85 * c.r};${50 * c.r}`} dur="5s" repeatCount="indefinite" />
              </circle>
              <circle cx={x} cy={y} r={36 * c.r} fill="rgba(239,174,46,.14)" />
              <circle cx={x} cy={y} r="8" fill="#EFAE2E" stroke="#1C3A32" strokeWidth="3" />
              <text x={x + 16} y={y + 6} fill="#F6F3EC" fontFamily="Inter Tight, sans-serif" fontSize="20" fontWeight="500">
                {c.n}
              </text>
            </g>
          );
        })}
        <text x="24" y="470" fill="rgba(246,243,236,.45)" fontFamily="Inter Tight, sans-serif" fontSize="14">
          Gold dots: regional Victoria
        </text>
      </svg>
    </div>
  );
}
export function Areas({ lede, cta }) {
  return (
    <section className="sec">
      <div className="wrap areas-g">
        <AreasMap />
        <div>
          <span className="eyebrow rv">Where we work</span>
          <h2 className="sec-t rv d1">
            Serving Metropolitan Melbourne <b>and Regional Victoria.</b>
          </h2>
          <p className="lede rv d2">{lede || "Project scheduling and availability depend on the location and scope of work."}</p>
          {cta && (
            <Link to="/contact" className="btn btn-sun rv d2" style={{ marginTop: 22 }}>
              Request a Quote <Arrow />
            </Link>
          )}
          <div className="area-list rv d3">
            {AREA_ORDER.map((k) => (
              <Link key={k} to="/areas/$area" params={{ area: k }}>
                {AREAS[k].name}
                <Arrow />
              </Link>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
