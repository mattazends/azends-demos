import { useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { ROOMS, ROOM_ORDER } from "@/lib/content";
import { Arrow } from "./Shell";

// Scroll-driven 3D walkthrough: roof lifts, camera visits each room.
const STEPS = [
  { k: null, rn: "A house we've upgraded", h: <>Looks like <b>any other home</b> from the street.</>, p: "That's the point. Robust Plus happens inside, room by room, and nobody walking past would know." },
  { k: null, rn: "Lift the roof", h: <>Four rooms. <b>Two tiers.</b> Nothing structural.</>, p: "We walk through the house, read the plan and work out which rooms need Tier 1 and which need Tier 2." },
  { k: "bedroom" },
  { k: "bathroom" },
  { k: "kitchen" },
  { k: "living" },
  { k: "end", rn: "The whole house", h: <>Stronger where it needs to be. <b>Ordinary everywhere else.</b></>, p: "Reinforced linings get painted like any other wall. Fittings sit flush. The furniture looks like furniture." },
];

const CAMS = [
  { p: [16.5, 11, 19], t: [0, 0.6, 0], roof: 0 },
  { p: [0.4, 19.5, 9.8], t: [0, 0, 0.4], roof: 1 },
  { p: [-1.6, 8.8, 0.9], t: [-2.5, 0, -2.4], roof: 1 },
  { p: [2.4, 8.6, 0.9], t: [3.2, 0, -2.4], roof: 1 },
  { p: [2.4, 8.6, 5.2], t: [3.2, 0, 1.9], roof: 1 },
  { p: [-1.6, 8.6, 5.3], t: [-2.5, 0, 1.9], roof: 1 },
  { p: [12.5, 15, 14.5], t: [0, 0, 0], roof: 1 },
];

const ease = (x) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2);

export default function HouseWalk() {
  const scrollRef = useRef(null);
  const stageRef = useRef(null);
  const hsRef = useRef(null);
  const progRef = useRef(null);
  const [step, setStep] = useState(0);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    // The walkthrough is hidden on phones (the room slider covers it), so skip loading 3D there.
    if (window.matchMedia("(max-width: 700px)").matches) return;
    let disposed = false;
    let cleanup = () => {};
    (async () => {
      const THREE = await import("three");
      const { buildHouse, setupStage, highlight } = await import("./three/house.js");
      if (disposed) return;
      const host = stageRef.current;
      const mobile = window.innerWidth < 900;
      const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, mobile ? 1.75 : 2));
      host.appendChild(renderer.domElement);
      const scene = new THREE.Scene();
      const house = buildHouse(THREE, { mobile });
      setupStage(THREE, renderer, scene, house.shadowSize);
      scene.add(house.root);
      const camera = new THREE.PerspectiveCamera(mobile ? 46 : 36, 1, 0.1, 200);
      const camPos = new THREE.Vector3(...CAMS[0].p);
      const camTgt = new THREE.Vector3(...CAMS[0].t);
      const wantPos = camPos.clone();
      const wantTgt = camTgt.clone();
      let roofLift = 0;

      // hotspot DOM
      const dots = {};
      ROOM_ORDER.forEach((rk) => {
        let n = 0;
        ROOMS[rk].items.forEach((it) => {
          n++;
          const el = document.createElement("div");
          el.className = `hs-dot ${it.tier === 2 ? "t2" : ""}`;
          el.innerHTML = `<b>${n}</b><span>${it.title}</span>`;
          hsRef.current.appendChild(el);
          dots[it.id] = { el, room: rk, tier: it.tier };
        });
      });

      let w = 0, h = 0;
      const resize = () => {
        w = host.clientWidth;
        h = host.clientHeight;
        renderer.setSize(w, h, false);
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
      };
      resize();
      const ro = new ResizeObserver(resize);
      ro.observe(host);

      let prog = 0;
      let lastStep = -1;
      const lit = {};
      const setLit = (id, lvl) => {
        if (lit[id] === lvl) return;
        lit[id] = lvl;
        highlight(THREE, house.items[id], lvl);
      };
      const readScroll = () => {
        const r = scrollRef.current.getBoundingClientRect();
        const total = r.height - window.innerHeight;
        const f = Math.min(1, Math.max(0, -r.top / total));
        prog = f * (CAMS.length - 1);
      };
      window.addEventListener("scroll", readScroll, { passive: true });
      readScroll();

      const v = new THREE.Vector3();
      let visible = true;
      const io = new IntersectionObserver(
        ([e]) => {
          visible = e.isIntersecting;
          document.body.classList.toggle("in-walk", e.isIntersecting);
        },
        { rootMargin: "200px" }
      );
      io.observe(scrollRef.current);

      let tPrev = performance.now();
      const tick = (now) => {
        if (!visible) return;
        const dt = Math.min(0.1, (now - tPrev) / 1000);
        tPrev = now;
        const k = 1 - Math.exp(-dt * 5.5);
        const i = Math.min(CAMS.length - 2, Math.floor(prog));
        const f = ease(Math.min(1, Math.max(0, prog - i)));
        const a = CAMS[i], b = CAMS[i + 1];
        wantPos.set(...a.p).lerp(v.set(...b.p), f);
        wantTgt.set(...a.t).lerp(v.set(...b.t), f);
        const roofWant = a.roof + (b.roof - a.roof) * f;
        camPos.lerp(wantPos, k);
        camTgt.lerp(wantTgt, k);
        roofLift += (roofWant - roofLift) * k;
        camera.position.copy(camPos);
        camera.lookAt(camTgt);
        house.roof.position.y = roofLift * 7;
        house.roof.traverse((o) => {
          if (o.material) o.material.opacity = 1 - Math.min(1, roofLift * 1.4);
        });
        house.roof.visible = roofLift < 0.98;

        const s = Math.round(prog);
        if (s !== lastStep) {
          lastStep = s;
          setStep(s);
        }
        const roomKey = STEPS[s]?.k;
        // highlight + hotspots
        Object.entries(dots).forEach(([id, d]) => {
          const active = roomKey === d.room && Math.abs(prog - s) < 0.32;
          const all = roomKey === "end";
          setLit(id, active ? (d.tier === 1 ? 2 : 1) : all ? 1 : 0);
          if (active) {
            v.copy(house.items[id].anchor).project(camera);
            const x = (v.x * 0.5 + 0.5) * w;
            const y = (-v.y * 0.5 + 0.5) * h;
            d.el.style.left = `${x}px`;
            d.el.style.top = `${y}px`;
            d.el.classList.toggle("flip", x > w - 200);
            d.el.classList.add("on");
          } else d.el.classList.remove("on");
        });
        if (progRef.current) {
          [...progRef.current.children].forEach((c, k) => {
            const fill = Math.min(1, Math.max(0, prog - k + 0.5));
            c.firstChild.style.transform = `scaleX(${fill})`;
          });
        }
        renderer.render(scene, camera);
      };
      renderer.setAnimationLoop(tick);
      setReady(true);

      cleanup = () => {
        renderer.setAnimationLoop(null);
        document.body.classList.remove("in-walk");
        window.removeEventListener("scroll", readScroll);
        ro.disconnect();
        io.disconnect();
        renderer.dispose();
        scene.traverse((o) => {
          o.geometry?.dispose();
          if (o.material) (Array.isArray(o.material) ? o.material : [o.material]).forEach((m) => m.dispose());
        });
        renderer.domElement.remove();
        if (hsRef.current) hsRef.current.innerHTML = "";
      };
    })();
    return () => {
      disposed = true;
      cleanup();
    };
  }, []);

  return (
    <section className="walk" id="walk">
      <div className="walk-head">
        <div className="wrap">
          <span className="eyebrow rv">Robust Plus</span>
          <h2 className="sec-t rv d1">
            Walk through a Robust Plus home, <b>room by room.</b>
          </h2>
          <p className="lede rv d2">Robust Plus is our upgrade to an existing home, so it holds up to the person's support needs and still feels like home. Keep scrolling.</p>
        </div>
      </div>
      <div className="walk-scroll" ref={scrollRef}>
        <div className="walk-pin">
          <div className="walk-txt">
            {STEPS.map((s, i) => {
              if (s.k && s.k !== "end") {
                const R = ROOMS[s.k];
                return (
                  <div key={i} className={`wstep ${step === i ? "on" : ""}`}>
                    <span className="rn">Room {ROOM_ORDER.indexOf(s.k) + 1} of 4</span>
                    <h3>{R.name}</h3>
                    <p>{R.intro}</p>
                    <ol>
                      {R.items.map((it, n) => (
                        <li key={it.id}>
                          <b>{n + 1}</b>
                          {it.title}
                          <em>Tier {it.tier}</em>
                        </li>
                      ))}
                    </ol>
                  </div>
                );
              }
              return (
                <div key={i} className={`wstep ${step === i ? "on" : ""}`}>
                  <span className="rn">{s.rn}</span>
                  <h3>{s.h}</h3>
                  <p>{s.p}</p>
                  {s.k === "end" && (
                    <div className="wend">
                      <Link to="/robust-plus" className="btn btn-sun">
                        Explore each room <Arrow />
                      </Link>
                      <Link to="/contact" className="btn btn-ghost">
                        Book a walk-through
                      </Link>
                    </div>
                  )}
                </div>
              );
            })}
            <div className="wprog" ref={progRef}>
              {STEPS.map((_, i) => (
                <i key={i}>
                  <b />
                </i>
              ))}
            </div>
          </div>
          <div className="walk-stage" ref={stageRef}>
            {!ready && <div className="walk-load">Building the house…</div>}
            <div className="hs" ref={hsRef} />
          </div>
        </div>
        <div style={{ height: `${(STEPS.length - 1) * 85}vh` }} />
      </div>
    </section>
  );
}
