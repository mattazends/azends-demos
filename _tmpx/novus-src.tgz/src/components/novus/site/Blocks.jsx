import { IMG, LOGOS, OFFICES, QUOTES, SERVICES, BOROUGHS, INDUSTRIES, SITE } from "@/content/site";
import { rich, Words, Eyebrow, SnowCanvas, Crumbs, Tick, Arrow } from "./Shell";
import { QuoteForm, DeadlineCard, Checklist } from "./Widgets";

const img = (k) => (k && IMG[k]) || k;

/* ---------------- hero ---------------- */
export function Hero({ b, crumbs }) {
  const v = b.v || "full";
  const ctas = (
    <div className="hero-ctas rv d3">
      <a className="btn btn-white" href="#quote">Get your snow plan <Arrow /></a>
      <a className="btn btn-glass" href={"tel:" + SITE.tel}><span>Call 24/7<span className="hide-s"> · {SITE.phone}</span></span></a>
    </div>
  );
  const head = (
    <>
      {crumbs && <Crumbs items={crumbs} />}
      <h1>
        {b.kw && <span className="kw rv">{b.kw}</span>}
        <Words as="span" className="big" text={b.title} />
      </h1>
      {b.sub && <p className="sub rv d2">{b.sub}</p>}
      {ctas}
      {b.chips && <div className="ph-chips rv d3">{b.chips.map((c) => <span key={c}><Tick />{c}</span>)}</div>}
    </>
  );
  if (v === "split") {
    return (
      <section className="ph ph-split">
        <SnowCanvas density={16} />
        <div className="wrap ph-split-in">
          <div className="ph-text">{head}</div>
          <div className="ph-media rv d2">
            <img src={img(b.img)} alt={b.alt || b.eyebrow || ""} fetchPriority="high" />
            {b.badge && <div className="ph-badge"><div className="n">{b.badge.n}</div><div className="t">{b.badge.t}</div></div>}
          </div>
        </div>
      </section>
    );
  }
  return (
    <section className={"ph ph-" + v}>
      <div className="ph-bg"><img src={img(b.img)} alt={b.alt || b.eyebrow || ""} fetchPriority="high" /></div>
      <SnowCanvas density={12} />
      <div className="wrap ph-in">{head}</div>
    </section>
  );
}

/* ---------------- sections ---------------- */
function Statement({ b }) {
  return (
    <section className="sec st-sec">
      <div className="wrap"><p className="why-big st-big rv">{rich(b.text)}</p></div>
    </section>
  );
}

function SecHead({ b, light, children }) {
  return (
    <div className="sec-head">
      <div>
        {b.eyebrow && <Eyebrow light={light}>{b.eyebrow}</Eyebrow>}
        <Words text={b.title} />
      </div>
      {b.lead && <p className="lead rv d1">{b.lead}</p>}
      {children}
    </div>
  );
}

function Timeline({ b }) {
  return (
    <section className="sec storm tl">
      <SnowCanvas density={22} />
      <div className="wrap">
        <SecHead b={b} light />
        <ol className="tl-list">
          {b.steps.map((s, i) => (
            <li className="tl-i rv" key={i}>
              <span className="tl-n">{String(i + 1).padStart(2, "0")}</span>
              <div className="when">{s.when}</div>
              <h3>{rich(s.title)}</h3>
              <p>{s.text}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}

function Compare({ b }) {
  return (
    <section className="sec cmp-sec">
      <div className="wrap">
        <SecHead b={b} />
        <div className="cmp rv">
          <div className="cmp-h"><span /><span className="l">{b.left}</span><span className="r"><Tick />{b.right}</span></div>
          {b.rows.map((r) => (
            <div className="cmp-r" key={r[0]}>
              <span className="k">{r[0]}</span>
              <span className="l">{r[1]}</span>
              <span className="r">{r[2]}</span>
            </div>
          ))}
        </div>
        {b.note && <p className="fine-note rv">{b.note}</p>}
      </div>
    </section>
  );
}

function Included({ b }) {
  return (
    <section className="sec inc-sec">
      <div className="wrap">
        <SecHead b={b} />
        <div className="inc">
          {b.items.map((it, i) => (
            <div className="inc-i rv" key={it.t}>
              <span className="no">{String(i + 1).padStart(2, "0")}</span>
              <h3>{it.t}</h3>
              <p>{it.d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Facts({ b }) {
  return (
    <section className="facts-sec">
      <div className="wrap facts big-facts">
        {b.items.map((f, i) => (
          <div className={"fact rv d" + (i + 1)} key={i}><div className="n">{rich(f.n)}</div><div className="t">{f.t}</div></div>
        ))}
      </div>
    </section>
  );
}

function Pains({ b }) {
  return (
    <section className="sec pains-sec">
      <div className="wrap">
        <SecHead b={b} />
        <div className="why-grid c3">
          {b.items.map((p, i) => (
            <div className={"wcard rv d" + i} key={p.t}>
              <div className="pn">{String(i + 1).padStart(2, "0")}</div>
              <h4>{p.t}</h4>
              <p>{p.d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Split({ b }) {
  return (
    <section className={"sec split-sec" + (b.rev ? " rev" : "")}>
      <div className="wrap split">
        <div className="split-media rv"><img src={img(b.img)} alt={b.alt || b.eyebrow || ""} loading="lazy" /></div>
        <div className="split-text">
          {b.eyebrow && <Eyebrow>{b.eyebrow}</Eyebrow>}
          <Words text={b.title} style={{ marginTop: 18 }} />
          <p className="lead rv d1" style={{ marginTop: 22 }}>{b.text}</p>
          {b.bullets && <ul className="ticks">{b.bullets.map((x, i) => <li className={"rv d" + Math.min(4, i + 1)} key={x}><span className="b"><Tick /></span>{x}</li>)}</ul>}
        </div>
      </div>
    </section>
  );
}

function Row({ b }) {
  return (
    <section className="sec row-sec">
      <div className="wrap">
        <SecHead b={b} />
        <ol className="srow">
          {b.steps.map((s, i) => (
            <li className={"rv d" + i} key={s.t}>
              <span className="dot" />
              <span className="k">Step {i + 1}</span>
              <h3>{s.t}</h3>
              <p>{s.d}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}

function Phases({ b }) {
  return (
    <section className="sec phases-sec">
      <div className="wrap">
        <SecHead b={b} />
        <div className="phases">
          {b.items.map((p, i) => (
            <div className={"phase rv d" + i} key={p.k}>
              <div className="pk">{p.k}</div>
              <h3>{p.t}</h3>
              <p>{p.d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Signs({ b }) {
  return (
    <section className="sec signs-sec">
      <div className="wrap">
        <SecHead b={b} />
        <div className="signs">
          {b.items.map((s, i) => (
            <div className="sign rv" key={s.t}>
              <span className="sn">{i + 1}</span>
              <h3>{s.t}</h3>
              <p>{s.d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Quote({ b }) {
  const q = QUOTES[b.q] || b;
  return (
    <section className="sec tq-sec">
      <div className="wrap tq rv">
        <span className="mark">“</span>
        <blockquote>{rich(q.q)}</blockquote>
        <div className="who"><strong>{q.who}</strong><small>{q.role}</small></div>
      </div>
    </section>
  );
}

export function Logos({ only }) {
  const list = only ? LOGOS.filter((l) => only.includes(l.n)) : LOGOS;
  const row = (k) => list.map((l) => <img key={k + l.n} className="lgi" src={l.src} alt={l.n} width={l.w} height={l.h} loading="lazy" />);
  if (only) {
    return (
      <div className="logos static">
        <p>Trusted through New York winters by teams at</p>
        <div className="lg-row">{row("a")}</div>
      </div>
    );
  }
  return (
    <div className="logos">
      <p>Trusted through New York winters by teams at</p>
      <div className="mask"><div className="marq">{row("a")}{row("b")}</div></div>
    </div>
  );
}

function Deadline({ b }) {
  return (
    <section className="sec" id="deadline">
      <div className="wrap clock-grid">
        <div>
          <Eyebrow>{b.eyebrow}</Eyebrow>
          <Words text={b.title} style={{ marginTop: 18 }} />
          <p className="lead rv d1" style={{ marginTop: 22 }}>{b.lead}</p>
        </div>
        <DeadlineCard />
      </div>
    </section>
  );
}

function ChecklistBlock({ b }) {
  return (
    <section className="sec chk-sec">
      <div className="wrap">
        <SecHead b={b} />
        <Checklist groups={b.groups || [{ items: b.items }]} />
      </div>
    </section>
  );
}

export function Faq({ b }) {
  return (
    <section className="sec" style={{ background: "#fff" }}>
      <div className="wrap faq-grid">
        <div>
          <Eyebrow>FAQ</Eyebrow>
          <Words text={b.title || "Questions *we get asked.*"} style={{ marginTop: 18 }} />
          <p className="lead rv d1" style={{ marginTop: 22 }}>Anything else, call the team on {SITE.phone}. Someone picks up 24/7.</p>
        </div>
        <div className="faq rv d1">
          {b.items.map(([q, a], i) => (
            <details key={q} open={i === 0}>
              <summary>{q}<span className="pl"><svg viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M6 1v10M1 6h10" /></svg></span></summary>
              <div className="ans">{a}</div>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}

export function LinkCards({ title, eyebrow, items, base, light }) {
  return (
    <section className={"sec lc-sec" + (light ? " lt" : "")}>
      <div className="wrap">
        <div className="sec-head"><div>{eyebrow && <Eyebrow>{eyebrow}</Eyebrow>}<Words text={title} /></div></div>
        <div className="lc">
          {items.map((it, i) => (
            <a className={"lc-i rv d" + (i % 3)} href={base + it.slug} key={it.slug}>
              <div className="lc-img"><img src={it.img} alt="" loading="lazy" /></div>
              <div className="lc-t"><h3>{it.name}</h3>{it.short && <p>{it.short}</p>}</div>
              <span className="go">→</span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

function Related({ b }) {
  const items = b.slugs.map((s) => SERVICES.find((x) => x.slug === s)).filter(Boolean);
  return <LinkCards eyebrow="Works best with" title={b.title || "Pair it with *the rest of the plan.*"} items={items} base="/services/" />;
}

export function FormSec({ b, preset }) {
  return (
    <section className="sec quote" id="quote">
      <div className="wrap q-grid">
        <div className="q-side">
          <Eyebrow>Get a quote</Eyebrow>
          <Words text={b.title || "Get your snow plan *before the first storm.*"} style={{ marginTop: 18 }} />
          <p className="lead">{b.lead || "Tell us about your site in under a minute. A Novus manager comes back with a plan and a price for the season."}</p>
          <div className="q-contact">
            <a href={"tel:" + SITE.tel}><span className="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2" /></svg></span><span><small>Call or text, 24/7</small><strong>{SITE.phone}</strong></span></a>
            <a href={"mailto:" + SITE.email}><span className="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><rect x="3" y="5" width="18" height="14" rx="2" /><path d="m3 7 9 6 9-6" /></svg></span><span><small>Email the sales team</small><strong>{SITE.email}</strong></span></a>
          </div>
        </div>
        <div className="rv d1"><QuoteForm preset={preset} /></div>
      </div>
    </section>
  );
}

export function Cta({ b }) {
  return (
    <section className="cta">
      <SnowCanvas density={14} />
      <img src={IMG.night} alt="" loading="lazy" />
      <div className="wrap">
        <Words as="h2" className="" text={b.title} />
        <p className="rv d1">{b.text}</p>
        <div className="hero-ctas rv d2">
          <a className="btn btn-white" href="#quote">Get your snow plan <Arrow /></a>
          <a className="btn btn-glass" href={"tel:" + SITE.tel}><span>Call 24/7<span className="hide-s"> · {SITE.phone}</span></span></a>
        </div>
      </div>
    </section>
  );
}

function Hoods({ b }) {
  return (
    <section className="sec hoods-sec">
      <div className="wrap cov-top">
        <div>
          <Eyebrow>Coverage</Eyebrow>
          <Words text={b.title} style={{ marginTop: 18 }} />
          <p className="lead rv d1" style={{ marginTop: 22 }}>{b.lead}</p>
          <div className="boros rv d2">{b.hoods.map((h) => <span className="boro" key={h}><i />{h}</span>)}</div>
        </div>
        <div className="cov-img rv d1">
          <img src={img(b.img)} alt="" loading="lazy" />
          <div className="cov-badge">
            <div><div className="n"><b>24/7</b></div><div className="t">storm watch</div></div>
            <div><div className="n"><b>{b.offices.length}</b></div><div className="t">{b.offices.length === 1 ? "base nearby" : "bases nearby"}</div></div>
            <div><div className="n"><b>100%</b></div><div className="t">commercial</div></div>
          </div>
        </div>
      </div>
      <div className="wrap">
        <div className="locs">
          {b.offices.map((k) => {
            const o = OFFICES[k];
            return (
              <a className="loc rv" key={k} href={"https://www.google.com/maps/search/?api=1&query=" + o.q} target="_blank" rel="noopener noreferrer">
                <span className="k">{o.k}</span><span className="nm">{o.nm}</span><span className="ad">{o.ad}</span><span className="go">→</span>
              </a>
            );
          })}
        </div>
      </div>
    </section>
  );
}

const MAP = {
  statement: Statement, timeline: Timeline, compare: Compare, included: Included, facts: Facts, pains: Pains,
  split: Split, row: Row, phases: Phases, signs: Signs, quote: Quote, deadline: Deadline, checklist: ChecklistBlock,
  faq: Faq, related: Related, cta: Cta, hoods: Hoods, logos: () => <Logos />,
};

export function Blocks({ blocks, crumbs, preset }) {
  return blocks.map((b, i) => {
    if (b.t === "hero") return <Hero b={b} crumbs={crumbs} key={i} />;
    if (b.t === "form") return <FormSec b={b} preset={preset} key={i} />;
    if (b.t === "logosOnly") return <Logos only={b.only} key={i} />;
    const C = MAP[b.t];
    return C ? <C b={b} key={i} /> : null;
  });
}

/* ---------------- block lists for areas and industries ---------------- */
export function boroughBlocks(bo) {
  const svc = bo.services.map((s) => SERVICES.find((x) => x.slug === s));
  return [
    { t: "hero", v: "full", img: bo.img, eyebrow: "Snow removal " + bo.name, kw: "Commercial snow removal in " + bo.name, title: bo.hero.title, sub: bo.hero.sub, chips: ["Pre-treated before the storm", "Commercial only", "24/7 dispatch"] },
    { t: "statement", text: bo.intro },
    { t: "pains", eyebrow: bo.name + " sites", title: "What makes " + bo.name + " *different.*", items: bo.challenges },
    { t: "hoods", title: "Crews across *" + bo.name + ".*", lead: "Local teams mean shorter routes and crews staged before the forecast turns. Including, but not limited to:", hoods: bo.hoods, offices: bo.offices, img: bo.img },
    { t: "row", eyebrow: "Storm day in " + bo.name, title: "Before, during *and after.*", steps: [
      { t: "Staged", d: "Your borough crew and material ready 24 to 48 hours out." },
      { t: "Pre-treated", d: "Entrances, sidewalks and lanes treated before the first flake." },
      { t: "Cleared", d: "Plowed and shoveled during the storm, not after it." },
      { t: "Re-treated", d: "Refreeze handled before your doors open." },
    ] },
    { t: "_cards", items: svc },
    { t: "quote", q: bo.slug === "manhattan" ? "yasin" : bo.slug === "queens" ? "kevin" : "cristina" },
    { t: "faq", title: bo.name + " *questions.*", items: bo.faq },
    { t: "form", title: "Get your " + bo.name + " site *planned before it snows.*" },
    { t: "cta", title: "Ready before *it snows in " + bo.name + ".*", text: "Pre-treated, cleared and re-treated by a crew that's already nearby." },
  ];
}

export function industryBlocks(ind) {
  return [
    { t: "hero", v: "split", img: ind.img, eyebrow: ind.name, kw: "Commercial snow & ice management for " + ind.name.toLowerCase(), title: ind.hero.title, sub: ind.hero.sub, badge: { n: "24/7", t: "storm watch and dispatch" } },
    { t: "logosOnly", only: ind.logos },
    { t: "pains", eyebrow: "What's at stake", title: "What a bad storm *costs you.*", items: ind.stakes },
    { t: "plan", items: ind.plan, name: ind.name },
    { t: "quote", q: ind.quote },
    { t: "_cards", items: ind.services.map((s) => SERVICES.find((x) => x.slug === s)) },
    { t: "faq", title: "Your *questions.*", items: ind.faq },
    { t: "form", title: "Get your site *planned before it snows.*" },
    { t: "cta", title: "Ready *before it snows.*", text: "Treated before, cleared during, re-treated after." },
  ];
}

export function PlanList({ b }) {
  return (
    <section className="sec storm plan-sec">
      <SnowCanvas density={22} />
      <div className="wrap plan-grid">
        <div>
          <Eyebrow light>How we plan it</Eyebrow>
          <Words text={"How we plan *your site.*"} style={{ marginTop: 18 }} />
          <p className="lead rv d1" style={{ marginTop: 22 }}>Every site gets written priorities before the season, so crews know what matters first when the storm hits.</p>
        </div>
        <ol className="plan-list">
          {b.items.map((x, i) => (
            <li className="rv" key={x}><span className="pn">{i + 1}</span>{x}</li>
          ))}
        </ol>
      </div>
    </section>
  );
}

export function PageBlocks({ blocks, crumbs, preset }) {
  return blocks.map((b, i) => {
    if (b.t === "_cards") return <LinkCards key={i} eyebrow="Services" title="What we *do here.*" items={b.items} base="/services/" />;
    if (b.t === "plan") return <PlanList key={i} b={b} />;
    return <Blocks key={i} blocks={[b]} crumbs={crumbs} preset={preset} />;
  });
}

export { BOROUGHS, INDUSTRIES };
