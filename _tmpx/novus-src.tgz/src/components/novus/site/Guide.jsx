import { Hero, Faq, FormSec, Cta } from "./Blocks";
import { DeadlineCard, Checklist } from "./Widgets";
import { Eyebrow, Words } from "./Shell";

const id = (s) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

export function GuideBody({ g }) {
  return (
    <>
      <Hero b={{ v: "center", img: g.img, eyebrow: g.hero.eyebrow, kw: g.hero.eyebrow + " · Updated November 2026", title: g.hero.title, sub: g.hero.sub }} crumbs={[{ label: "Guides", href: "/guides" }, { label: g.name }]} />

      {g.calculator && (
        <section className="sec">
          <div className="wrap clock-grid">
            <div>
              <Eyebrow>Try it</Eyebrow>
              <Words text="Find your *exact deadline.*" style={{ marginTop: 18 }} />
              <p className="lead rv d1" style={{ marginTop: 22 }}>Slide to the time the snow stopped. The calculator follows the current DSNY rules.</p>
            </div>
            <DeadlineCard />
          </div>
        </section>
      )}

      {g.checklist && (
        <section className="sec chk-sec">
          <div className="wrap">
            <div className="sec-head"><div><Eyebrow>The checklist</Eyebrow><Words text="Tick what's *already in place.*" /></div><p className="lead rv d1">Nothing is saved or sent. It's just for you.</p></div>
            <Checklist groups={g.checklist} />
          </div>
        </section>
      )}

      <section className="sec art-sec">
        <div className="wrap art">
          <aside className="toc">
            <div className="toc-in">
              <span className="toc-h">On this page</span>
              {g.sections.map((s) => <a key={s.h} href={"#" + id(s.h)}>{s.h}</a>)}
            </div>
          </aside>
          <article className="prose">
            {g.sections.map((s) => (
              <section key={s.h} id={id(s.h)} className="rv">
                <h2>{s.h}</h2>
                {s.p && s.p.map((p, i) => <p key={i}>{p}</p>)}
                {s.list && <ul>{s.list.map((x) => <li key={x}>{x}</li>)}</ul>}
                {s.table && (
                  <div className="tbl-wrap">
                    <table className="tbl">
                      <thead><tr>{s.table.head.map((h, i) => <th key={i}>{h}</th>)}</tr></thead>
                      <tbody>{s.table.rows.map((r, i) => <tr key={i}>{r.map((c, j) => <td key={j}>{c}</td>)}</tr>)}</tbody>
                    </table>
                  </div>
                )}
                {s.note && <p className="fine-note">{s.note}</p>}
                {s.link && <p><a className="prose-link" href={s.link.href}>{s.link.label} →</a></p>}
              </section>
            ))}
            {g.sources && (
              <div className="sources">
                <span>Sources</span>
                {g.sources.map(([t, u]) => <a key={u} href={u} target="_blank" rel="noopener noreferrer">{t}</a>)}
              </div>
            )}
          </article>
        </div>
      </section>

      <Faq b={{ title: "Quick *answers.*", items: g.faq }} />
      <FormSec b={{ title: "Let us worry about *the first storm.*", lead: "Tell us about your site. A Novus manager comes back with a plan and a price for the season." }} />
      <Cta b={{ title: "Ready *before it snows.*", text: "Treated before, cleared during, re-treated after." }} />
    </>
  );
}
