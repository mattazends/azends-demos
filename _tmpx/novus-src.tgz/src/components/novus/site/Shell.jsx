import { useEffect, useRef, useState } from "react";
import { SITE, SERVICES, BOROUGHS, INDUSTRIES, GUIDES } from "@/content/site";

/* ---------- text helpers ---------- */
// "*word*" marks bold. Returns React nodes.
export function rich(str) {
  if (!str) return null;
  return String(str).split("*").map((part, i) => (i % 2 ? <b key={i}>{part}</b> : part));
}

// Title split into words for the rise-in animation (same look as the homepage).
export function Words({ text, as: Tag = "h2", className = "h2", style }) {
  let n = 0;
  const parts = String(text).split("*");
  return (
    <Tag className={className + " words"} style={style}>
      {parts.map((part, pi) =>
        part.split(/(\s+)/).filter(Boolean).map((w, wi) => {
          if (/^\s+$/.test(w)) return " ";
          const delay = { transitionDelay: n++ * 0.05 + "s" };
          return (
            <span className="w" key={pi + "-" + wi}>
              <span style={delay}>{pi % 2 ? <b>{w}</b> : w}</span>
            </span>
          );
        })
      )}
    </Tag>
  );
}

export function Eyebrow({ children, light }) {
  return <span className={"eyebrow rv" + (light ? " lt" : "")}><span className="dot" />{children}</span>;
}

/* ---------- snow ---------- */
export function SnowCanvas({ density = 12, className = "snowc" }) {
  const ref = useRef(null);
  useEffect(() => {
    const c = ref.current;
    if (!c || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    let dead = false, vis = false, W = 0, H = 0;
    const ctx = c.getContext("2d"), dpr = Math.min(window.devicePixelRatio || 1, 2), fl = [];
    const size = () => { W = c.offsetWidth; H = c.offsetHeight; c.width = W * dpr; c.height = H * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0); };
    size();
    window.addEventListener("resize", size, { passive: true });
    const N = Math.min(140, Math.round(window.innerWidth / density));
    for (let k = 0; k < N; k++) fl.push({ x: Math.random() * W, y: Math.random() * H, r: Math.random() * 2 + 0.4, s: Math.random() * 0.6 + 0.2, d: Math.random() * 6.28, o: Math.random() * 0.5 + 0.25 });
    const io = new IntersectionObserver((e) => { vis = e[0].isIntersecting; });
    io.observe(c);
    const draw = () => {
      if (dead) return;
      if (vis) {
        ctx.clearRect(0, 0, W, H);
        for (const f of fl) {
          f.d += 0.01; f.y += f.s * (1 + f.r * 0.35); f.x += Math.sin(f.d) * 0.3 + 0.12;
          if (f.y > H + 5) { f.y = -5; f.x = Math.random() * W; }
          if (f.x > W + 5) f.x = -5;
          ctx.beginPath(); ctx.arc(f.x, f.y, f.r, 0, 6.283); ctx.fillStyle = "rgba(255,255,255," + f.o + ")"; ctx.fill();
        }
      }
      requestAnimationFrame(draw);
    };
    draw();
    return () => { dead = true; io.disconnect(); window.removeEventListener("resize", size); };
  }, [density]);
  return <canvas ref={ref} className={className} aria-hidden="true" />;
}

/* ---------- icons ---------- */
export const Flake = ({ size = 26 }) => (
  <svg viewBox="0 0 32 32" width={size} height={size} fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round"><path d="M16 3v26M4.7 9.5l22.6 13M4.7 22.5l22.6-13" /><path d="M12.5 5.5 16 9l3.5-3.5M12.5 26.5 16 23l3.5 3.5" strokeWidth="1.8" /></svg>
);
const Chev = () => <svg className="chev" viewBox="0 0 10 6" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="m1 1 4 4 4-4" /></svg>;
export const Tick = () => <svg viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="2"><path d="m2 6 3 3 5-6" /></svg>;
export const Arrow = () => <span className="arr">→</span>;

/* ---------- navigation ---------- */
export const NAV = [
  { label: "Services", href: "/services", wide: true, items: SERVICES.map((s) => ({ href: "/services/" + s.slug, t: s.name, d: s.short })) },
  { label: "Areas", href: "/areas", items: BOROUGHS.map((b) => ({ href: "/areas/" + b.slug, t: b.name })) },
  { label: "Industries", href: "/industries", items: INDUSTRIES.map((i) => ({ href: "/industries/" + i.slug, t: i.name })) },
  { label: "How it works", href: "/how-it-works" },
  { label: "Guides", href: "/guides", items: GUIDES.map((g) => ({ href: "/guides/" + g.slug, t: g.name, d: g.short })) },
];

export function SiteNav({ solidAt = 0.5, home = false }) {
  const [solid, setSolid] = useState(false);
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const on = () => setSolid(window.scrollY > window.innerHeight * solidAt);
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, [solidAt]);
  useEffect(() => {
    document.documentElement.style.overflow = open ? "hidden" : "";
    return () => { document.documentElement.style.overflow = ""; };
  }, [open]);
  const quoteHref = home ? "#quote" : "/quote";
  return (
    <>
      <header className={"nav" + (solid ? " solid" : "") + (open ? " menu-open" : "")} id="nav">
        <div className="nav-in">
          <a href="/" className="logo" aria-label="Novus Maintenance home">
            <Flake />
            <span className="lt">Novus<small>Commercial snow &amp; ice</small></span>
          </a>
          <nav className="nav-links" aria-label="Main">
            {NAV.map((n) =>
              n.items ? (
                <div className="dd" key={n.label}>
                  <a className="dd-t" href={n.href}>{n.label}<Chev /></a>
                  <div className={"dd-panel" + (n.wide ? " wide" : "")}>
                    <div className="dd-card">
                      {n.items.map((it) => (
                        <a className="dd-i" href={it.href} key={it.href}>
                          <span className="t">{it.t}</span>
                          {it.d && <span className="d">{it.d}</span>}
                        </a>
                      ))}
                      <a className="dd-all" href={n.href}>All {n.label.toLowerCase()} <Arrow /></a>
                    </div>
                  </div>
                </div>
              ) : (
                <a href={n.href} key={n.label}>{n.label}</a>
              )
            )}
          </nav>
          <div className="nav-r">
            <a className="nav-tel" href={"tel:" + SITE.tel}><span className="pulse" />{SITE.phone}</a>
            <a className="btn btn-ice" href={quoteHref}>Get a quote</a>
            <button className="burger" type="button" aria-label={open ? "Close menu" : "Open menu"} aria-expanded={open} onClick={() => setOpen((o) => !o)}><span /></button>
          </div>
        </div>
      </header>
      <div className={"mmenu" + (open ? " open" : "")} aria-hidden={!open}>
        <div className="mm-scroll">
          {NAV.map((n) =>
            n.items ? (
              <details key={n.label}>
                <summary>{n.label}<Chev /></summary>
                <div className="mm-sub">
                  {n.items.map((it) => <a href={it.href} key={it.href} onClick={() => setOpen(false)}>{it.t}</a>)}
                  <a href={n.href} className="mm-all" onClick={() => setOpen(false)}>All {n.label.toLowerCase()} →</a>
                </div>
              </details>
            ) : (
              <a className="mm-top" href={n.href} key={n.label} onClick={() => setOpen(false)}>{n.label}</a>
            )
          )}
          <a className="btn btn-ice" href={quoteHref} onClick={() => setOpen(false)}>Get your snow plan</a>
          <a className="mm-tel" href={"tel:" + SITE.tel}>Call 24/7 · {SITE.phone}</a>
        </div>
      </div>
    </>
  );
}

/* ---------- footer ---------- */
export function SiteFooter({ home = false }) {
  return (
    <footer className="site-foot">
      <div className="wrap">
        <div className="sf-top">
          <div className="sf-brand">
            <a href="/" className="logo"><Flake /><span className="lt">Novus<small>Commercial snow &amp; ice</small></span></a>
            <p>New York's commercial-only snow and ice team. We treat your site before the storm, clear it during and re-treat it after. All five boroughs, 24/7.</p>
            <a className="sf-tel" href={"tel:" + SITE.tel}>{SITE.phone}</a>
            <a className="sf-mail" href={"mailto:" + SITE.email}>{SITE.email}</a>
          </div>
          <div className="sf-cols">
            <div><h5>Services</h5><ul>{SERVICES.map((s) => <li key={s.slug}><a href={"/services/" + s.slug}>{s.name}</a></li>)}</ul></div>
            <div><h5>Areas</h5><ul>{BOROUGHS.map((b) => <li key={b.slug}><a href={"/areas/" + b.slug}>Snow removal {b.name}</a></li>)}</ul></div>
            <div><h5>Industries</h5><ul>{INDUSTRIES.map((i) => <li key={i.slug}><a href={"/industries/" + i.slug}>{i.name}</a></li>)}</ul></div>
            <div><h5>Company</h5><ul>
              <li><a href="/how-it-works">How it works</a></li>
              {GUIDES.map((g) => <li key={g.slug}><a href={"/guides/" + g.slug}>{g.name}</a></li>)}
              <li><a href={home ? "#quote" : "/quote"}>Get a quote</a></li>
              <li><a href="https://www.instagram.com/novussnow/" target="_blank" rel="noopener noreferrer">Instagram</a> · <a href="https://www.facebook.com/novusmaintenance/" target="_blank" rel="noopener noreferrer">Facebook</a></li>
            </ul></div>
          </div>
        </div>
        <div className="sf-offices">
          <span>434 W 33rd St, NY 10001</span><span>405 Lexington Ave, NY 10174</span><span>222 Broadway, NY 10038</span><span>869 St. Marks Ave, Brooklyn</span><span>52-10 35th St, Long Island City</span><span>708 Hartle St, Sayreville, NJ</span>
        </div>
        <div className="f-bot"><span>© {new Date().getFullYear()} {SITE.legal}. All rights reserved.</span><span>Commercial snow removal · New York City · Open 24/7</span></div>
      </div>
    </footer>
  );
}

export function MobileBar({ home = false }) {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const on = () => setShow(window.scrollY > window.innerHeight * 0.5);
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);
  return (
    <div className={"mbar" + (show ? " show" : "")}>
      <a className="btn btn-glass" href={"tel:" + SITE.tel}>Call 24/7</a>
      <a className="btn btn-ice" href={home ? "#quote" : "/quote"}>Get a quote</a>
    </div>
  );
}

/* ---------- reveal animations for sub pages ---------- */
export function useReveal(deps = []) {
  useEffect(() => {
    const els = document.querySelectorAll(".sub .rv:not(.in), .sub .words:not(.in)");
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) { els.forEach((e) => e.classList.add("in")); return; }
    const io = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } }), { threshold: 0.12, rootMargin: "0px 0px -5% 0px" });
    els.forEach((e) => io.observe(e));
    return () => io.disconnect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
}

export function Page({ children, path }) {
  useReveal([path]);
  return (
    <div className="novus-root sub">
      <SiteNav />
      <main>{children}</main>
      <SiteFooter />
      <MobileBar />
    </div>
  );
}

export function Crumbs({ items }) {
  return (
    <nav className="crumbs rv" aria-label="Breadcrumb">
      <a href="/">Home</a>
      {items.map((c, i) => (
        <span key={i}><i>/</i>{c.href ? <a href={c.href}>{c.label}</a> : <span aria-current="page">{c.label}</span>}</span>
      ))}
    </nav>
  );
}
