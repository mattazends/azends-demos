import { useMemo, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { submitQuoteRequest } from "@/lib/server-fns";
import { SITE } from "@/content/site";
import { Tick, Arrow } from "./Shell";

/* ---------------- Quote form (same steps as the homepage, React version) ---------------- */
const STEPS = [
  { key: "type", mode: "single", h: ["What kind of ", "property", " is it?"], hint: "Pick the closest match.", opts: ["Retail / storefront", "Office", "Parking lot", "Construction site", "Multi-site portfolio", "Something else"] },
  { key: "locs", mode: "single", h: ["How many ", "locations?", ""], hint: "Multi-site contracts are welcome.", opts: ["1 location", "2–5 locations", "6–20 locations", "20+ locations"] },
  { key: "where", mode: "multi", cols: 3, h: ["Where are your ", "sites?", ""], hint: "Select all that apply.", opts: ["Manhattan", "Brooklyn", "Queens", "The Bronx", "Staten Island", "Outside NYC"] },
  { key: "needs", mode: "multi", h: ["What do you ", "need covered?", ""], hint: "Not sure? Pick what you know and we'll fill the gaps.", opts: ["Pre-storm anti-icing", "Snow plowing", "De-icing", "Sidewalk clearing", "Shoveling", "Snow hauling", "Full season cover"] },
  { key: "contact", mode: "form", h: ["Where should we ", "send your plan?", ""], hint: "A manager will call to confirm the details." },
];

export function QuoteForm({ preset = {} }) {
  const submit = useServerFn(submitQuoteRequest);
  const [i, setI] = useState(0);
  const [data, setData] = useState({ type: [], locs: [], where: preset.where || [], needs: preset.needs || [] });
  const [f, setF] = useState({ name: "", company: "", email: "", phone: "", notes: "", hp: "" });
  const [err, setErr] = useState({});
  const [state, setState] = useState("idle"); // idle | sending | done | failed
  const [shake, setShake] = useState({ n: 0, at: -1 });
  const step = STEPS[i];

  const pick = (key, mode, v) => {
    setData((d) => {
      const cur = d[key];
      if (mode === "single") return { ...d, [key]: [v] };
      return { ...d, [key]: cur.includes(v) ? cur.filter((x) => x !== v) : [...cur, v] };
    });
    if (mode === "single" && i < 4) setTimeout(() => setI((x) => (x === i ? i + 1 : x)), 260);
  };

  const valid = () => {
    if (step.key !== "contact") return data[step.key].length > 0;
    const e = {
      name: f.name.trim().length < 2,
      email: !/.+@.+\..+/.test(f.email.trim()),
      phone: f.phone.replace(/\D/g, "").length < 7,
    };
    setErr(e);
    return !e.name && !e.email && !e.phone;
  };

  const send = async () => {
    if (f.hp) return;
    setState("sending");
    try {
      await submit({ data: {
        name: f.name.trim(), company: f.company.trim(), email: f.email.trim(), phone: f.phone.trim(), notes: f.notes.trim(),
        property_type: data.type[0] || "", locations: data.locs[0] || "", boroughs: data.where, services: data.needs,
        source_page: typeof window !== "undefined" ? window.location.pathname : "/",
      } });
      setState("done");
    } catch {
      setState("failed");
    }
  };

  const next = () => {
    if (!valid()) { setShake((s) => ({ n: s.n + 1, at: i })); return; }
    setShake({ n: 0, at: -1 });
    if (i === 4) { send(); return; }
    setI(i + 1);
  };

  if (state === "done") {
    const first = f.name.trim().split(" ")[0];
    return (
      <div className="form">
        <div className="f-done">
          <div className="ok"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4"><path d="m5 12 5 5 9-10" /></svg></div>
          <h3 className="h2" style={{ fontSize: "clamp(28px,3vw,40px)" }}>Thanks{first ? ", " + first : ""}. <b>You're on our list.</b></h3>
          <p className="lead" style={{ margin: "14px auto 0" }}>A Novus manager will be in touch shortly. Need us now? Call {SITE.phone}, any time.</p>
          <div className="f-sum">{[...data.type, ...data.locs, ...data.where, ...data.needs].map((v) => <span key={v}>{v}</span>)}</div>
        </div>
      </div>
    );
  }

  return (
    <div className="form">
      <div className="f-prog"><span>Step {i + 1} of 5</span><span>Commercial properties only</span></div>
      <div className="f-bar"><i style={{ width: ((i + 1) / 5) * 100 + "%" }} /></div>
      <div className="fs on" key={i + "-" + (shake.at === i ? shake.n : 0)} style={shake.at === i ? { animation: "fsShake .35s" } : undefined}>
        <h3>{step.h[0]}<b>{step.h[1]}</b>{step.h[2]}</h3>
        <p className="hint" style={state === "failed" && i === 4 ? { color: "#E11D48" } : undefined}>
          {state === "failed" && i === 4 ? "That didn't send. Please try again, or call " + SITE.phone + "." : step.hint}
        </p>
        {step.mode !== "form" ? (
          <div className={"cards" + (step.cols === 3 ? " c3" : "")}>
            {step.opts.map((o) => (
              <button type="button" key={o} className={"cardopt" + (data[step.key].includes(o) ? " on" : "")} onClick={() => pick(step.key, step.mode, o)}>
                {o}<span className="tick"><Tick /></span>
              </button>
            ))}
          </div>
        ) : (
          <div className="fields">
            <div className={"fld" + (err.name ? " err" : "")}><label htmlFor="qName">Your name</label><input id="qName" autoComplete="name" placeholder="Jane Smith" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
            <div className="fld"><label htmlFor="qCo">Company</label><input id="qCo" autoComplete="organization" placeholder="Company name" value={f.company} onChange={(e) => setF({ ...f, company: e.target.value })} /></div>
            <div className={"fld" + (err.email ? " err" : "")}><label htmlFor="qEmail">Work email</label><input id="qEmail" type="email" autoComplete="email" placeholder="jane@company.com" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></div>
            <div className={"fld" + (err.phone ? " err" : "")}><label htmlFor="qPhone">Phone</label><input id="qPhone" type="tel" autoComplete="tel" placeholder="(212) 555-0123" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} /></div>
            <input tabIndex={-1} autoComplete="off" aria-hidden="true" value={f.hp} onChange={(e) => setF({ ...f, hp: e.target.value })} style={{ position: "absolute", left: "-9999px", width: 1, height: 1, opacity: 0 }} />
            <div className="fld full"><label htmlFor="qNotes">Site address or notes (optional)</label><textarea id="qNotes" rows={3} placeholder="e.g. 3 storefronts in Midtown, loading bay at the back" value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} /></div>
          </div>
        )}
      </div>
      <div className="f-nav">
        <button type="button" className={"f-back" + (i > 0 ? " show" : "")} onClick={() => setI(Math.max(0, i - 1))}>← Back</button>
        <button type="button" className="btn btn-ice" onClick={next} disabled={state === "sending"}>
          {state === "sending" ? "Sending…" : state === "failed" ? <>Try again <Arrow /></> : i === 4 ? <>Get my snow plan <Arrow /></> : <>Continue <Arrow /></>}
        </button>
      </div>
    </div>
  );
}

/* ---------------- Sidewalk deadline calculator ---------------- */
function fmt(m) {
  m = ((m % 1440) + 1440) % 1440;
  const h = Math.floor(m / 60), mi = m % 60;
  return { t: (h % 12 || 12) + ":" + (mi < 10 ? "0" : "") + mi, ap: h >= 12 ? "PM" : "AM" };
}
export function DeadlineCard() {
  const [t, setT] = useState(840);
  const r = useMemo(() => {
    let due;
    if (t >= 420 && t < 1020) due = t + 240;
    else if (t >= 1020 && t < 1260) due = t + 840;
    else due = t >= 1260 ? 1440 + 660 : 660;
    const win = due - t, hrs = Math.round((win / 60) * 10) / 10;
    return { a: fmt(t), b: fmt(due), day: due >= 1440 ? "tomorrow" : "today", hrs: hrs % 1 === 0 ? hrs : hrs.toFixed(1), w: Math.max(8, Math.min(100, (win / 840) * 100)) };
  }, [t]);
  return (
    <div className="clock-card rv d2">
      <div className="cc-top"><span>Sidewalk deadline calculator</span><span className="cc-tag">NYC Admin Code §16-123</span></div>
      <div className="cc-q">When did the snow stop?</div>
      <div className="cc-time"><b>{r.a.t}</b> {r.a.ap}</div>
      <input type="range" min="0" max="1425" step="15" value={t} onChange={(e) => setT(+e.target.value)} aria-label="Time the snow stopped" />
      <div className="cc-scale"><span>12 AM</span><span>6 AM</span><span>12 PM</span><span>6 PM</span><span>12 AM</span></div>
      <div className="cc-out">
        <div><div className="k">Your sidewalk must be clear by</div><div className="v"><b>{r.b.t} {r.b.ap}</b> {r.day}</div></div>
        <div className="cc-win"><div className="k">Window</div><div className="v"><b>{r.hrs}</b> hrs</div></div>
        <div className="cc-bar"><i style={{ width: r.w + "%" }} /></div>
      </div>
      <p className="cc-note">Based on current DSNY guidance. Novus crews treat before and work during the storm, so you're not racing the clock after it.</p>
    </div>
  );
}

/* ---------------- Interactive checklist ---------------- */
export function Checklist({ groups }) {
  const all = groups.flatMap((g) => g.items);
  const [on, setOn] = useState({});
  const done = all.filter((x) => on[x]).length;
  const pct = Math.round((done / all.length) * 100);
  return (
    <div className="chk">
      <div className="chk-side">
        <div className="chk-meter rv">
          <div className="chk-n"><b>{done}</b>/{all.length}</div>
          <div className="chk-bar"><i style={{ width: pct + "%" }} /></div>
          <p>{done === all.length ? "Your site is ready. Want us to make it official?" : done > all.length / 2 ? "Getting there. The gaps are usually in the contract." : "Most sites have gaps here. That's what the plan is for."}</p>
          <a className="btn btn-ice" href="/quote">Get a site plan <Arrow /></a>
        </div>
      </div>
      <div className="chk-list">
        {groups.map((g) => (
          <div className="chk-g rv" key={g.g || "all"}>
            {g.g && <h3>{g.g}</h3>}
            {g.items.map((it) => (
              <button type="button" key={it} className={"chk-i" + (on[it] ? " on" : "")} onClick={() => setOn({ ...on, [it]: !on[it] })} aria-pressed={!!on[it]}>
                <span className="b"><Tick /></span>{it}
              </button>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
