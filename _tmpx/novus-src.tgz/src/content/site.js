/* Novus Maintenance: all page content for the multi-page site.
   Copy rules: prevention first (Novus treats before the storm), specific over clever,
   reason-why on every claim, buyer's own words for the pain, no invented numbers. */

const M = "https://media.base44.com/images/public/6b002b0a52f746ee078dd98f/";

export const SITE = {
  url: "https://www.novusmaintenance.com",
  name: "Novus Maintenance",
  legal: "Novus Maintenance Corp",
  phone: "(917) 970-2960",
  tel: "+19179702960",
  email: "sales@novusmaintenance.com",
};

export const IMG = {
  hero: M + "14aaee91a_novus-hero.png",
  plow: M + "78d19799b_svc-plowing.jpeg",
  avenue: M + "032ea3244_svc-deicing.jpeg",
  walkers: M + "72acc718c_svc-sidewalks.jpeg",
  steam: M + "aa9a7f76b_svc-shoveling.jpeg",
  spreader: M + "2dda683dd_svc-hauling.jpeg",
  bridge: M + "86d5460df_coverage.jpeg",
  night: M + "c287c1b70_cta.jpeg",
  bkStreet: M + "9a7d90f30_brooklyn-street-snow.jpg",
  stoop: M + "bf9aecd48_brownstone-steps-snow.jpg",
  bkShovel: M + "e60ce6c87_sidewalk-shoveling-brooklyn.jpg",
  crossing: M + "bc4dd34c5_nyc-street-crossing-snow.jpg",
  mnNight: M + "9f3f3c288_manhattan-night-snow.jpg",
  construction: M + "8e2685d40_construction-site-snow.jpg",
  lot: M + "ef4b4196e_parking-lot-snow-aerial.jpg",
  yard: M + "b53572653_truck-yard-snow-aerial.jpg",
  handCrew: M + "a7a961687_hand-crew-shoveling.jpg",
  queens: M + "339864b84_queens-street-snow.jpg",
  blower: M + "a08d328a4_snow-blower-sidewalk.jpg",
};

export const LOGOS = [
  { n: "Target", src: M + "5afcd59f5_logo-target.png", w: 36, h: 50 },
  { n: "Verizon", src: M + "a61fd5309_logo-verizon.png", w: 120, h: 27 },
  { n: "Charles Schwab", src: M + "275fc890b_logo-schwab.png", w: 90, h: 40 },
  { n: "Patagonia", src: M + "1280b5a52_logo-patagonia.png", w: 120, h: 24 },
  { n: "Puma", src: M + "b7756ef5b_logo-puma.png", w: 80, h: 40 },
  { n: "TD Ameritrade", src: M + "ec889f328_logo-tdameritrade.png", w: 132, h: 26 },
  { n: "The Frick Collection", src: M + "f9441abd5_logo-frick.png", w: 72, h: 46 },
  { n: "Triton Construction", src: M + "20d41fe47_logo-triton.png", w: 96, h: 31 },
  { n: "NakeFit", src: M + "25a8ec7fd_logo-nakefit.webp", w: 56, h: 48 },
];

export const OFFICES = {
  hq: { k: "Headquarters", nm: "Midtown West", ad: "434 West 33rd Street, PH Floor, New York, NY 10001", q: "434+West+33rd+Street+New+York+NY+10001" },
  chrysler: { k: "Office", nm: "Chrysler Building", ad: "405 Lexington Ave, 9th Floor, New York, NY 10174", q: "405+Lexington+Ave+New+York+NY+10174" },
  downtown: { k: "Office", nm: "Downtown", ad: "222 Broadway, New York, NY 10038", q: "222+Broadway+New+York+NY+10038" },
  brooklyn: { k: "Office", nm: "Brooklyn", ad: "869 St. Marks Ave, Brooklyn, NY 11213", q: "869+St+Marks+Ave+Brooklyn+NY+11213" },
  lic: { k: "Warehouse", nm: "Long Island City", ad: "52-10 35th Street, Long Island City, NY 11101", q: "52-10+35th+Street+Long+Island+City+NY+11101" },
  nj: { k: "Warehouse", nm: "Sayreville, NJ", ad: "708 Hartle Street, Sayreville, NJ 08872", q: "708+Hartle+Street+Sayreville+NJ+08872" },
};

export const QUOTES = {
  nakefit: { q: "Professional servicing of *all our locations nationwide.* Very reliable.", who: "NakeFit USA", role: "Multi-location client" },
  cristina: { q: "Always on time and *available during every snow storm.*", who: "Cristina M.", role: "Client" },
  yasin: { q: "We've used them *for years.* Always on time and always correct.", who: "Yasin W.", role: "Client for years" },
  kevin: { q: "Never any issues. *Responsive, prompt* and easy to work with.", who: "Kevin K.", role: "Client" },
};

/* ---------------------------------------------------------------- SERVICES */
export const SERVICES = [
  {
    slug: "pre-storm-anti-icing",
    name: "Pre-storm anti-icing",
    short: "Surfaces treated before the first flake, so snow and ice can't bond.",
    img: IMG.spreader,
    need: "Pre-storm anti-icing",
    seo: {
      title: "Pre-Storm Anti-Icing & Pre-Treatment NYC | Novus Maintenance",
      description: "Commercial anti-icing across NYC. Novus pre-treats lots, sidewalks and entrances before the storm so snow and ice can't bond to the pavement. 24/7, all five boroughs.",
    },
    blocks: [
      { t: "hero", v: "full", img: "spreader", eyebrow: "Pre-storm anti-icing", kw: "Commercial anti-icing & pre-treatment in NYC", title: "The time to beat ice is *before it forms.*", sub: "We treat your lots, sidewalks and entrances ahead of the storm. Snow lands on a surface it can't grip, crews lift it clean, and your doors open on time.", chips: ["Applied before the first flake", "Less corrosive materials", "All five boroughs"] },
      { t: "statement", text: "Ice is a bond. Once snow freezes to the pavement, every hour after is spent breaking it. *So we stop it forming.*" },
      { t: "timeline", eyebrow: "How it works", title: "What happens at your site *before anyone else is out.*", lead: "Pre-treatment is a timing game. This is the order we run it in.", steps: [
        { when: "24 to 48 hours out", title: "Forecast flagged, *site queued.*", text: "When snow or freezing rain is on the models, your site moves up its borough's list. Material and crews are staged before the first city advisory goes out." },
        { when: "Hours before the first flake", title: "Surfaces *treated.*", text: "Entrances, walkways, ramps, loading bays and lot lanes get a treatment layer. It sits between the pavement and the snow, so the two never bond." },
        { when: "While it falls", title: "Snow *stays loose.*", text: "Snow lands on treated ground and stays workable. Plows and shovels lift it clean instead of scraping at packed ice, so each pass does more." },
        { when: "After the storm", title: "Re-treated *against refreeze.*", text: "Overnight temperature drops are where black ice and slip claims start. High-traffic surfaces get re-treated so melt doesn't freeze by morning." },
      ] },
      { t: "compare", eyebrow: "Why it matters", title: "Same storm. *Two very different mornings.*", left: "Wait and react", right: "Treat before the storm", rows: [
        ["When crews arrive", "After snow has packed down", "Before the first flake"],
        ["The ice bond", "Already formed, has to be broken", "Never gets the chance to form"],
        ["Material used", "More, spread onto ice", "Far less, applied to bare pavement*"],
        ["The first pass", "Scraping and chipping", "Snow lifts clean"],
        ["The sidewalk deadline", "Racing the 4-hour clock", "Mostly met by the time the snow stops"],
        ["The morning after", "Refreeze and black ice", "Re-treated overnight"],
      ], note: "*Public works research (APWA) found pre-storm anti-icing delivers the same level of service with one quarter to one fifth of the salt that de-icing uses." },
      { t: "included", eyebrow: "Where we treat", title: "The surfaces where *people actually slip.*", items: [
        { t: "Entrances & vestibules", d: "The first and last 20 feet of every visit." },
        { t: "Sidewalks & frontages", d: "The 4-foot path the city holds you to." },
        { t: "Ramps & curb cuts", d: "Accessible routes stay usable for everyone." },
        { t: "Stairs & fire exits", d: "Treated by hand, step by step." },
        { t: "Loading docks", d: "Deliveries land even mid-storm." },
        { t: "Lot lanes & drive aisles", d: "So the plow lifts snow off clean." },
      ] },
      { t: "facts", items: [
        { n: "*1/4*", t: "the salt of reactive de-icing for the same result, per APWA research" },
        { n: "up to *24* hrs", t: "ahead of a storm a pre-treatment can go down" },
        { n: "*24/7*", t: "storm watch and dispatch through the season" },
      ] },
      { t: "faq", title: "Anti-icing, *answered.*", items: [
        ["What is anti-icing?", "Treating pavement before snow or ice arrives so it can't bond to the surface. De-icing melts ice that has already formed. Anti-icing stops it forming in the first place."],
        ["When do you apply it?", "Ahead of forecast snow or freezing rain, usually in the hours before it starts. The exact timing depends on the storm and your site, and your plan sets it out."],
        ["Does it replace plowing and shoveling?", "No. It makes them faster and cleaner. When snow can't bond, plows and hand crews clear it in fewer passes and leave less behind to refreeze."],
        ["Is it safe for my paving and entrances?", "We use premium, less corrosive materials chosen to protect concrete, pavers and entrance flooring, and we apply measured amounts rather than buckets of rock salt."],
        ["Is it worth it for a light dusting?", "Light snow and freezing drizzle cause a lot of slips because they look harmless. On those days, pre-treatment is often the whole job."],
      ] },
      { t: "related", slugs: ["de-icing-salting", "sidewalk-snow-removal", "commercial-snow-plowing"] },
      { t: "form", title: "Get treated *before the next storm.*", lead: "Tell us about your site. A Novus manager comes back with a plan and a price for the season." },
      { t: "cta", title: "Ready *before it snows.*", text: "The cheapest ice to clear is the ice that never forms." },
    ],
  },
  {
    slug: "commercial-snow-plowing",
    name: "Commercial snow plowing",
    short: "Lots, loading bays and access roads pushed clear on a plan set before the season.",
    img: IMG.plow,
    need: "Snow plowing",
    seo: {
      title: "Commercial Snow Plowing NYC | Parking Lots, Loading Docks & Access Roads | Novus",
      description: "Commercial snow plowing in NYC for parking lots, loading docks and access roads. Pre-treated lanes, a stacking plan set before the season, crews on standby 24/7.",
    },
    blocks: [
      { t: "hero", v: "split", img: "lot", eyebrow: "Commercial snow plowing", kw: "Commercial snow plowing in New York City", title: "Plowed before your *first shift arrives.*", sub: "Parking lots, loading bays and access roads pushed clear on a plan we set before the season, so deliveries land and staff park on time.", badge: { n: "24/7", t: "plow crews on standby all season" } },
      { t: "pains", eyebrow: "What goes wrong on most lots", title: "Three ways a lot *loses a morning.*", items: [
        { t: "Snow pushed to the wrong place", d: "Piles on parking spaces, hydrants or exit sightlines cost you capacity and safety for weeks." },
        { t: "One pass, too late", d: "A single push after the storm leaves packed snow that freezes into ruts by the next morning." },
        { t: "The dock gets forgotten", d: "A buried loading bay means trucks turned away and stock that doesn't arrive." },
      ] },
      { t: "split", img: "plow", eyebrow: "The plan", title: "We plan the push *before it snows.*", text: "Every lot gets a written plan: where snow goes, which lanes clear first and which spaces stay open. Crews arrive knowing your site instead of guessing it at 3 AM.", bullets: ["Fire lanes and priority routes cleared first", "Stacking areas mapped away from drains and sightlines", "Docks and delivery routes kept open through the storm", "Lanes pre-treated so snow lifts clean"] },
      { t: "row", eyebrow: "Storm day", title: "How a plowing storm *runs.*", steps: [
        { t: "Pre-treat", d: "Lanes and aisles treated before the first flake." },
        { t: "Push during", d: "Plows work the storm at depths set in your plan." },
        { t: "Clean-up pass", d: "Edges, corners and stacks finished when it stops." },
        { t: "Re-treat & haul", d: "Refreeze handled, piles hauled if space runs out." },
      ] },
      { t: "included", eyebrow: "What we plow", title: "Built for *commercial ground.*", items: [
        { t: "Parking lots", d: "Surface lots, retail and office parking." },
        { t: "Loading docks & bays", d: "Aprons and truck routes kept open." },
        { t: "Access roads", d: "Private roads and driveways into the site." },
        { t: "Fire lanes", d: "Cleared first, every storm." },
        { t: "Garage ramps", d: "Entries and exits treated and cleared." },
        { t: "Construction yards", d: "Haul roads and laydown areas." },
      ] },
      { t: "quote", q: "cristina" },
      { t: "faq", title: "Plowing *questions.*", items: [
        ["Do you plow during the storm or after it?", "During. Crews work the storm at the depths set in your plan, then finish with a clean-up pass once it stops. Waiting until the end lets snow pack down and freeze."],
        ["Where does the snow go?", "Into stacking areas agreed in your plan, away from drains, hydrants and sightlines. If your site has no room, we haul it off site."],
        ["Can you plow several lots under one contract?", "Yes. Multi-site portfolios get one plan, one point of contact and crews staged in each borough."],
        ["How do you avoid damaging curbs and islands?", "We walk your site before the season and note curbs, islands, drains and anything buried under snow, so crews know the ground in the dark."],
      ] },
      { t: "related", slugs: ["pre-storm-anti-icing", "snow-hauling", "seasonal-snow-contracts"] },
      { t: "form", title: "Get your lot *planned before the first storm.*", lead: "Two minutes now saves a buried lot later." },
      { t: "cta", title: "Your lot, *open on time.*", text: "Plowed during the storm, cleaned up after it, planned long before it." },
    ],
  },
  {
    slug: "sidewalk-snow-removal",
    name: "Sidewalk snow removal",
    short: "Frontages, corners and curb cuts cleared inside the city's deadline.",
    img: IMG.walkers,
    need: "Sidewalk clearing",
    seo: {
      title: "Commercial Sidewalk Snow Removal NYC | Beat the DSNY Deadline | Novus",
      description: "Commercial sidewalk snow removal in NYC. Frontages, corners and curb cuts pre-treated and cleared to a 4-foot path inside the DSNY deadline. 24/7, all five boroughs.",
    },
    blocks: [
      { t: "hero", v: "full", img: "bkShovel", eyebrow: "Sidewalk snow removal", kw: "Commercial sidewalk snow removal in NYC", title: "Your sidewalk, clear *inside the city's window.*", sub: "Frontages, corners and curb cuts cleared to a safe path, and pre-treated before the storm so the clock is never against you.", chips: ["4-foot clear path", "Corners & curb cuts", "Hydrants cleared"] },
      { t: "deadline", eyebrow: "The NYC rule", title: "The clock starts *when the snow stops.*", lead: "If your building has a sidewalk, the city holds you to a deadline. Drag the slider to see yours." },
      { t: "split", img: "blower", rev: true, eyebrow: "What the law asks for", title: "What *clear* actually means.", text: "DSNY rules go further than most owners think. A shoveled strip by the door isn't enough.", bullets: ["A path at least 4 feet wide along the whole frontage", "Corner properties clear through to the crosswalk and the pedestrian ramp", "Snow and ice cleared from around fire hydrants", "Bus stops without a shelter are yours to clear", "Snow can't be pushed or blown into the street"] },
      { t: "facts", items: [
        { n: "*4* hrs", t: "to clear if the snow stops between 7 AM and 4:59 PM" },
        { n: "*14* hrs", t: "if it stops between 5 PM and 8:59 PM" },
        { n: "by *11* AM", t: "if it stops between 9 PM and 6:59 AM" },
      ] },
      { t: "statement", text: "Fines run from $100 to $250 a violation. *The slip at your door costs a lot more.* That's why our crews treat and clear during the storm, not after it." },
      { t: "included", eyebrow: "What we clear", title: "Every foot of *frontage.*", items: [
        { t: "Storefront frontages", d: "Full width, full length, door to curb." },
        { t: "Corners & curb cuts", d: "Through to the crosswalk and ramp." },
        { t: "Building entrances", d: "Doorways, vestibules and steps." },
        { t: "Hydrant clearance", d: "Dug out and kept clear." },
        { t: "Bus stops", d: "Where there's no shelter to cover it." },
        { t: "Plazas & walkways", d: "Private paths across your site." },
      ] },
      { t: "faq", title: "Sidewalk rules, *explained.*", items: [
        ["Who is responsible for the sidewalk in NYC?", "The person in charge of the building or lot: owners, lessees, tenants and occupants. For a commercial site, that usually means you or your property manager."],
        ["What if it snows overnight?", "If the snow stops between 9 PM and 6:59 AM, the sidewalk has to be clear by 11 AM. Our crews work through the night so it's done before you open."],
        ["Can we push snow into the street?", "No. DSNY can issue a summons for shoveling, blowing or pushing snow into the roadway. We stack it on site or haul it away."],
        ["How much are the fines?", "Per DSNY, $100 for a first offense, $150 for a second and $250 for a third. Repeat storms add up quickly across several frontages."],
      ] },
      { t: "related", slugs: ["pre-storm-anti-icing", "snow-shoveling", "de-icing-salting"] },
      { t: "form", title: "Never race the *sidewalk clock* again.", lead: "Tell us about your frontages and we'll come back with a plan and a price." },
      { t: "cta", title: "Clear before *the clock runs.*", text: "Treated before the storm, cleared during it, checked before you open." },
    ],
  },
  {
    slug: "de-icing-salting",
    name: "De-icing & salting",
    short: "Less corrosive ice control before, during and after the storm.",
    img: IMG.avenue,
    need: "De-icing",
    seo: {
      title: "Commercial De-Icing & Salting NYC | Less-Corrosive Ice Control | Novus",
      description: "Commercial de-icing and salting in NYC. Premium, less corrosive ice control for walkways, entrances and lots, applied before, during and after every storm.",
    },
    blocks: [
      { t: "hero", v: "split", img: "avenue", eyebrow: "De-icing & salting", kw: "Commercial de-icing & salting in NYC", title: "Ice control that *protects the ground* it's on.", sub: "Premium, less corrosive de-icing for walkways, entrances and lots. Applied before, during and after the storm, so ice can't build and melt can't refreeze.", badge: { n: "3", t: "treatment windows: before, during and after" } },
      { t: "pains", eyebrow: "The bucket-of-rock-salt problem", title: "More salt *isn't more safety.*", items: [
        { t: "Spread too late", d: "Salt thrown onto packed ice works slowly, so the surface stays slick through the morning rush." },
        { t: "Spread too heavy", d: "Excess material gets tracked into lobbies and eats at concrete, pavers and stone." },
        { t: "Spread once", d: "One pass after the storm leaves melt sitting on the pavement, ready to refreeze overnight." },
      ] },
      { t: "phases", eyebrow: "Three windows", title: "Treated at the *three moments that matter.*", items: [
        { k: "Before", t: "Anti-icing on bare pavement", d: "A treatment layer goes down ahead of the storm so snow and ice can't bond." },
        { k: "During", t: "Kept workable between passes", d: "Snow stays loose instead of packing down under foot traffic and tires." },
        { k: "After", t: "Re-treated against refreeze", d: "Melt is treated before overnight temperatures turn it into black ice." },
      ] },
      { t: "split", img: "spreader", eyebrow: "Our materials", title: "Measured, *less corrosive* and on time.", text: "We use premium de-icing materials that limit ice build-up and stop refreezing while being kinder to your paving, entrances and flooring. Applied in measured amounts, at the right time, rather than by the bucket.", bullets: ["Less residue tracked into lobbies", "Kinder to concrete, pavers and stone", "Applied before ice forms, not just after", "Re-treated when overnight temperatures drop"] },
      { t: "faq", title: "De-icing *questions.*", items: [
        ["What's the difference between de-icing and anti-icing?", "Anti-icing goes down before the storm to stop ice bonding. De-icing melts ice that has already formed. We use both, and lean on anti-icing because it does more with less."],
        ["Will it damage my entrance or flooring?", "We use premium, less corrosive materials and apply measured amounts, which means less residue tracked inside and less wear on paving."],
        ["How often do you re-treat?", "As conditions need it: through the storm and again before overnight temperatures drop, which is when refreeze catches people out."],
        ["Do you de-ice without snow, for freezing rain or frost?", "Yes. Freezing rain and frost are some of the most dangerous conditions because surfaces look wet, not icy. Your plan covers them."],
      ] },
      { t: "related", slugs: ["pre-storm-anti-icing", "sidewalk-snow-removal", "snow-shoveling"] },
      { t: "form", title: "Ice control, *planned before winter.*", lead: "Tell us about your site and what needs treating." },
      { t: "cta", title: "No ice. *No refreeze.*", text: "Treated before, during and after every storm." },
    ],
  },
  {
    slug: "snow-shoveling",
    name: "Hand shoveling crews",
    short: "Trained hand crews for stairs, ramps, doorways and fire exits.",
    img: IMG.handCrew,
    need: "Shoveling",
    seo: {
      title: "Commercial Snow Shoveling NYC | Hand Crews for Stairs, Ramps & Exits | Novus",
      description: "Commercial snow shoveling in NYC. Fully trained hand crews clear and treat stairs, ramps, doorways and fire exits, the tight spots machines can't reach.",
    },
    blocks: [
      { t: "hero", v: "full", img: "handCrew", eyebrow: "Hand shoveling crews", kw: "Commercial snow shoveling in New York City", title: "The tight spots *machines can't reach.*", sub: "Fully trained hand crews for stairs, ramps, doorways and fire exits. The small places where people actually slip.", chips: ["Stairs & stoops", "Ramps & rails", "Fire exits"] },
      { t: "statement", text: "A plow can clear an acre in minutes. *It can't clear a single step.* Most slips happen in the places only a shovel can reach." },
      { t: "checklist", eyebrow: "Your hand-crew list", title: "Tick off what your site has. *We'll cover every one.*", items: ["Front entrance and vestibule", "Stairs, stoops and landings", "Accessible ramps and handrails", "Fire exits and egress doors", "Service and staff entrances", "Walkways between buildings", "Areas around benches, planters and bollards", "Spots machines can't fit"] },
      { t: "split", img: "handCrew", rev: true, eyebrow: "The crews", title: "Trained *off-season.* Sharp on night one.", text: "Snow is all we do, so our hand crews train with their equipment and on strict safety procedures before the season starts. They know which surfaces to treat, how to clear a step without leaving a glaze, and where snow can and can't go.", bullets: ["Equipment and safety training before the season", "Clear and treat in the same visit", "Work alongside plow crews on the same storm", "Commercial sites only"] },
      { t: "faq", title: "Shoveling *questions.*", items: [
        ["Do hand crews come with plowing?", "They can work on their own or alongside plows on the same storm. Most sites need both: machines for open ground and hand crews for the edges."],
        ["Do you treat steps after clearing them?", "Yes. A cleared step with melt left on it is a refreeze risk, so crews treat as they go."],
        ["Can you keep fire exits clear through a long storm?", "Yes. Egress routes are written into your plan as a priority and get repeat visits through the storm."],
      ] },
      { t: "related", slugs: ["sidewalk-snow-removal", "pre-storm-anti-icing", "commercial-snow-plowing"] },
      { t: "form", title: "Every step, *covered.*", lead: "Tell us about your site and its tight spots." },
      { t: "cta", title: "Safe from the *curb to the door.*", text: "Machines for the open ground. Trained hands for the rest." },
    ],
  },
  {
    slug: "snow-hauling",
    name: "Snow hauling & relocation",
    short: "Piles loaded and hauled off site when space runs out.",
    img: IMG.yard,
    need: "Snow hauling",
    seo: {
      title: "Commercial Snow Hauling & Removal NYC | Off-Site Snow Relocation | Novus",
      description: "Commercial snow hauling in NYC. When piles take your parking, block sightlines or refreeze across walkways, Novus loads and hauls snow off site and manages every step.",
    },
    blocks: [
      { t: "hero", v: "split", img: "yard", eyebrow: "Snow hauling & relocation", kw: "Commercial snow hauling in New York City", title: "No room to stack it? *We take it away.*", sub: "When piles eat your parking, block sightlines or start to melt and refreeze, we load it, haul it off site and manage every step.", badge: { n: "24/7", t: "loading and hauling scheduled around your hours" } },
      { t: "signs", eyebrow: "When you need hauling", title: "Five signs your snow *needs to leave.*", items: [
        { t: "You're losing parking", d: "Every pile on a space is a customer or tenant who parks somewhere else." },
        { t: "Piles block sightlines", d: "Stacks at exits and corners hide cars and pedestrians from drivers." },
        { t: "Melt runs across walkways", d: "Piles melt by day and refreeze across paths by night." },
        { t: "There's nowhere to put it", d: "Most Manhattan sites have no stacking room at all." },
        { t: "Storms are back to back", d: "The next storm needs the space the last one is using." },
      ] },
      { t: "row", eyebrow: "How it runs", title: "Hauled *start to finish.*", steps: [
        { t: "Assess", d: "We size the piles and plan access around your hours." },
        { t: "Load", d: "Loaders and trucks scheduled for minimum disruption." },
        { t: "Haul", d: "Snow taken off site, not dumped in the street." },
        { t: "Re-treat", d: "The cleared ground treated so it doesn't refreeze." },
      ] },
      { t: "faq", title: "Hauling *questions.*", items: [
        ["Can you haul overnight?", "Yes. We schedule loading around your opening hours, and overnight is often the quietest window for city sites."],
        ["Do I need hauling every storm?", "Usually not. Your plan sets stacking areas first and brings in hauling when space runs out or piles become a hazard."],
        ["Can you haul from multiple sites?", "Yes. Hauling can be added to any site in a multi-location plan."],
      ] },
      { t: "related", slugs: ["commercial-snow-plowing", "seasonal-snow-contracts", "de-icing-salting"] },
      { t: "form", title: "Get your space *back.*", lead: "Tell us about the site and the size of the problem." },
      { t: "cta", title: "Every space, *back in use.*", text: "Loaded, hauled and re-treated." },
    ],
  },
  {
    slug: "seasonal-snow-contracts",
    name: "Seasonal & multi-site contracts",
    short: "One plan, one contact, every site covered for the whole season.",
    img: IMG.bridge,
    need: "Full season cover",
    seo: {
      title: "Seasonal Snow Removal Contracts NYC | Multi-Site Snow Management | Novus",
      description: "Seasonal commercial snow removal contracts in NYC. A site plan, crews staged in your borough and one point of contact for every location you manage. Sign before the first storm.",
    },
    blocks: [
      { t: "hero", v: "center", img: "bridge", eyebrow: "Seasonal & multi-site contracts", kw: "Seasonal commercial snow removal contracts in NYC", title: "One plan. One contact. *Every site covered.*", sub: "Lock in your winter before the first storm: a written plan for each site, crews staged in your borough and one person to call for every location." },
      { t: "logos" },
      { t: "included", eyebrow: "What's in a season plan", title: "Everything decided *before it snows.*", items: [
        { t: "Pre-season site walk", d: "Entrances, lots, stacking areas and hazards mapped." },
        { t: "Written priorities", d: "What gets cleared first, second and third." },
        { t: "Pre-storm treatment", d: "Surfaces treated before every storm." },
        { t: "Plowing, sidewalks & hand crews", d: "One team for the whole storm." },
        { t: "Stacking & hauling plan", d: "Where snow goes, and when it leaves." },
        { t: "One point of contact", d: "For every site you manage." },
      ] },
      { t: "quote", q: "nakefit" },
      { t: "row", eyebrow: "Getting set up", title: "From first call to *winter handled.*", steps: [
        { t: "Tell us your sites", d: "Two minutes on the form, or one call." },
        { t: "Site walk", d: "We map each property before the season." },
        { t: "Plan & price", d: "A written plan and a price for the season." },
        { t: "Crews assigned", d: "Your borough crew knows your site before it snows." },
      ] },
      { t: "faq", title: "Contract *questions.*", items: [
        ["When should we sign?", "Before the first storm. Site walks and written plans take time to set up, and crews are assigned to sites ahead of the season."],
        ["Can one contract cover sites in several boroughs?", "Yes. That's what the plan is built for: every site, every borough, one point of contact."],
        ["Do you cover sites outside New York City?", "We cover all five boroughs, with a warehouse in Sayreville, NJ. If you have sites further out, tell us and we'll talk it through."],
        ["Do you take residential work?", "No. Novus is commercial only, so business sites never wait behind someone's driveway."],
      ] },
      { t: "related", slugs: ["pre-storm-anti-icing", "commercial-snow-plowing", "sidewalk-snow-removal"] },
      { t: "form", title: "Get your season *planned now.*", lead: "Tell us about your sites. We come back with a plan and a price." },
      { t: "cta", title: "Spend this winter *not thinking about it.*", text: "One plan, one contact, every site." },
    ],
  },
];

/* ---------------------------------------------------------------- BOROUGHS */
export const BOROUGHS = [
  {
    slug: "manhattan", name: "Manhattan", img: IMG.mnNight,
    seo: { title: "Commercial Snow Removal Manhattan | Pre-Storm Treatment & Sidewalks | Novus", description: "Commercial snow removal in Manhattan from the Financial District to Harlem. Storefronts, office entrances and corner properties pre-treated and cleared. Crews based in Midtown, 24/7." },
    hero: { title: "Manhattan sidewalks, *clear before the doors open.*", sub: "Storefronts, office lobbies and corner properties from the Financial District to Harlem, pre-treated before the storm by crews based in Midtown." },
    intro: "In Manhattan, there's *nowhere to put the snow* and thousands of people walking on it. That changes how a site has to be handled.",
    challenges: [
      { t: "No room to stack", d: "Every foot of curb is spoken for, so snow often has to leave the site entirely." },
      { t: "Corner exposure", d: "Corner buildings must clear through to the crosswalk and the pedestrian ramp, not just the frontage." },
      { t: "Foot traffic all day", d: "Untreated snow gets packed into ice within hours. Pre-treatment keeps it loose." },
    ],
    hoods: ["Financial District", "Tribeca", "SoHo", "Lower East Side", "Chelsea", "Hudson Yards", "Midtown", "Murray Hill", "Upper East Side", "Upper West Side", "Harlem", "Washington Heights"],
    offices: ["hq", "chrysler", "downtown"],
    services: ["sidewalk-snow-removal", "pre-storm-anti-icing", "snow-hauling"],
    faq: [
      ["Do you haul snow in Manhattan?", "Yes. Most Manhattan sites have no stacking room, so hauling is built into plans where it's needed and scheduled around your hours."],
      ["Can you clear before my store or office opens?", "Yes. Crews work during the storm, and your plan sets the time your entrance has to be ready by."],
      ["Where are your Manhattan crews based?", "Our headquarters is at 434 West 33rd Street, with offices in the Chrysler Building and at 222 Broadway."],
    ],
  },
  {
    slug: "brooklyn", name: "Brooklyn", img: IMG.bkStreet,
    seo: { title: "Commercial Snow Removal Brooklyn | Retail, Warehouses & Offices | Novus", description: "Commercial snow removal in Brooklyn. Retail corridors, warehouses and mixed-use sites pre-treated and cleared before the storm, served from our St. Marks Ave office. 24/7." },
    hero: { title: "Brooklyn sites treated *before the storm rolls in.*", sub: "Retail corridors, warehouses and commercial buildings across the borough, served from our office on St. Marks Avenue." },
    intro: "Brooklyn mixes *avenue retail, waterfront industry and brownstone steps* on the same blocks. One standard has to cover all of it.",
    challenges: [
      { t: "Long retail corridors", d: "Avenue frontages with many tenants need one consistent standard, not a patchwork of shovels." },
      { t: "Industrial lots and docks", d: "Waterfront and industrial sites need lanes and loading bays kept moving through the storm." },
      { t: "Steps and stoops", d: "Stairs at commercial and mixed-use buildings are where people slip, and they need hands, not plows." },
    ],
    hoods: ["Downtown Brooklyn", "DUMBO", "Williamsburg", "Greenpoint", "Bushwick", "Crown Heights", "Park Slope", "Sunset Park", "Red Hook", "Bay Ridge", "Flatbush", "East New York"],
    offices: ["brooklyn", "lic"],
    services: ["pre-storm-anti-icing", "commercial-snow-plowing", "snow-shoveling"],
    faq: [
      ["Where is your Brooklyn office?", "869 St. Marks Ave, Brooklyn, NY 11213, with our Long Island City warehouse close by for equipment and material."],
      ["Do you clear warehouses and industrial sites?", "Yes. Lots, docks and access roads are plowed and treated so trucks keep moving through the storm."],
      ["Can you cover several Brooklyn storefronts?", "Yes. Multi-site plans give every location the same standard with one point of contact."],
    ],
  },
  {
    slug: "queens", name: "Queens", img: IMG.queens,
    seo: { title: "Commercial Snow Removal Queens | Lots, Warehouses & Retail | Novus", description: "Commercial snow removal in Queens from Long Island City to Jamaica. Parking lots, warehouses and retail sites pre-treated and plowed, served from our LIC warehouse. 24/7." },
    hero: { title: "Queens lots and frontages, *ready before the first flake.*", sub: "From Long Island City warehouses to Jamaica retail, served from our warehouse on 35th Street in LIC." },
    intro: "Queens is the *largest borough in the city.* Response time comes down to where your crew starts, and ours start in Long Island City.",
    challenges: [
      { t: "Big lots, early mornings", d: "Shopping centers and office parks need lanes plowed before the first car arrives." },
      { t: "Logistics that can't stop", d: "Warehouses and distribution sites need docks and truck routes open through the storm." },
      { t: "Ground to cover", d: "Local staging keeps travel short when every site needs a crew at once." },
    ],
    hoods: ["Long Island City", "Astoria", "Sunnyside", "Woodside", "Maspeth", "Ridgewood", "Jackson Heights", "Flushing", "College Point", "Forest Hills", "Jamaica", "Bayside"],
    offices: ["lic"],
    services: ["commercial-snow-plowing", "pre-storm-anti-icing", "snow-hauling"],
    faq: [
      ["Where are your Queens crews based?", "Our warehouse is at 52-10 35th Street, Long Island City, NY 11101."],
      ["Do you plow large retail parking lots?", "Yes. Lots get a plan for lanes, stacking areas and priority routes, with pre-treatment before the storm."],
      ["Can you keep loading docks open during a storm?", "Yes. Docks and truck routes are written into your plan as priorities and visited repeatedly through the storm."],
    ],
  },
  {
    slug: "bronx", name: "The Bronx", img: IMG.avenue,
    seo: { title: "Commercial Snow Removal Bronx | Retail, Distribution & Institutions | Novus", description: "Commercial snow removal in the Bronx. Retail, distribution and institutional sites pre-treated, plowed and cleared before and during the storm. Crews staged ahead of every forecast." },
    hero: { title: "Bronx sites kept open *through the whole storm.*", sub: "Retail, distribution and institutional sites across the borough, with crews staged ahead of every forecast." },
    intro: "Bronx sites deal with *hills, long frontages and distribution traffic* that doesn't stop for weather. Each needs treating before the snow starts.",
    challenges: [
      { t: "Grades and slopes", d: "Sloped entrances, ramps and driveways need treating before snow, because clearing them after is slow and risky." },
      { t: "Distribution hubs", d: "Hunts Point and the industrial waterfront run on open docks and truck routes." },
      { t: "Long frontages", d: "Larger sites mean long sidewalk runs, all inside the same city deadline." },
    ],
    hoods: ["Mott Haven", "Port Morris", "Hunts Point", "Concourse", "Fordham", "Kingsbridge", "Riverdale", "Parkchester", "Morris Park", "Pelham Bay", "Throgs Neck", "Co-op City"],
    offices: ["hq", "lic"],
    services: ["pre-storm-anti-icing", "commercial-snow-plowing", "sidewalk-snow-removal"],
    faq: [
      ["Which base covers the Bronx?", "Bronx sites are covered from our Manhattan headquarters and our Long Island City warehouse, with crews staged ahead of each forecast."],
      ["Do you treat sloped entrances and ramps?", "Yes. Slopes are pre-treated before the storm and given priority, because clearing them after snow has packed down is slow and risky."],
      ["Do you work with distribution and industrial sites?", "Yes. Docks, lanes and truck routes are kept open through the storm."],
    ],
  },
  {
    slug: "staten-island", name: "Staten Island", img: IMG.plow,
    seo: { title: "Commercial Snow Removal Staten Island | Parking Lots & Shopping Centers | Novus", description: "Commercial snow removal on Staten Island. Shopping centers, office parks and industrial yards planned, pre-treated and plowed before opening. Crews staged before every storm." },
    hero: { title: "Staten Island lots *plowed and treated before opening.*", sub: "Shopping centers, office parks and industrial yards with more pavement than most of the city, planned and pre-treated before every storm." },
    intro: "Staten Island has *more open pavement* than any other borough's commercial sites. That makes the plan matter more than the plow.",
    challenges: [
      { t: "More pavement", d: "Larger lots mean the plowing and stacking plan decides how many spaces you keep." },
      { t: "Wind and drifting", d: "Open lots drift back after the first push, so passes have to be timed through the storm." },
      { t: "Distance", d: "Island sites need crews staged before the storm, not dispatched in the middle of it." },
    ],
    hoods: ["St. George", "Stapleton", "Port Richmond", "Mariners Harbor", "Bulls Head", "New Springville", "Travis", "New Dorp", "Great Kills", "Charleston", "Richmond Valley", "Tottenville"],
    offices: ["nj", "hq"],
    services: ["commercial-snow-plowing", "pre-storm-anti-icing", "snow-hauling"],
    faq: [
      ["Which base covers Staten Island?", "Staten Island sites are covered from our Sayreville, NJ warehouse and our Manhattan headquarters, with crews staged before the storm."],
      ["Do you plow shopping center lots?", "Yes. Large lots get a written plan for lanes, stacking areas and priority routes, plus pre-treatment."],
      ["How do you handle drifting on open lots?", "Passes are timed through the storm rather than one push at the end, so drifts don't set into ice."],
    ],
  },
];

/* ---------------------------------------------------------------- INDUSTRIES */
export const INDUSTRIES = [
  {
    slug: "retail-storefronts", name: "Retail & storefronts", img: IMG.bkStreet, logos: ["Target", "Puma", "Patagonia"],
    seo: { title: "Snow Removal for Retail Stores NYC | Storefront Snow & Ice Management | Novus", description: "Snow and ice management for NYC retail stores and chains. Entrances and frontages pre-treated and cleared before opening, so customers walk in and nobody slips." },
    hero: { title: "Customers walk in. *Nobody slips on the way.*", sub: "Storefronts and retail chains pre-treated and cleared before opening, so the first customer of the day finds a safe, clear entrance." },
    stakes: [
      { t: "Lost sales on storm days", d: "A slushy, half-cleared entrance tells customers you're not really open." },
      { t: "Claims at the door", d: "The doorway and the first few feet of sidewalk are where most falls happen." },
      { t: "Fines on the frontage", d: "Every storefront is on the DSNY clock the moment the snow stops." },
    ],
    plan: ["Entrance and vestibule treated before opening", "Full frontage cleared to a 4-foot path", "Corners, curb cuts and crosswalk ramps", "Parking and loading areas, where you have them", "Re-treated before close and before overnight refreeze"],
    services: ["sidewalk-snow-removal", "pre-storm-anti-icing", "seasonal-snow-contracts"],
    quote: "cristina",
    faq: [
      ["Can you cover every store in our chain?", "Yes. Multi-site plans give every location the same standard and one point of contact."],
      ["Will you be done before we open?", "Your plan sets the time each entrance has to be ready. Crews work during the storm so it's met."],
      ["Do you clear inside the vestibule?", "We treat and clear entrances and vestibule approaches. Tell us what's inside your lease line and we'll write it into the plan."],
    ],
  },
  {
    slug: "corporate-offices", name: "Corporate offices & banks", img: IMG.steam, logos: ["Charles Schwab", "TD Ameritrade", "Verizon"],
    seo: { title: "Office Building Snow Removal NYC | Corporate Offices & Banks | Novus", description: "Snow and ice management for NYC office buildings, corporate campuses and bank branches. Entrances, plazas and garages pre-treated and clear before the workday starts." },
    hero: { title: "Your team gets in *on time, on dry ground.*", sub: "Office entrances, plazas, garages and bank branches pre-treated and cleared before the workday starts." },
    stakes: [
      { t: "Late starts", d: "If the entrance and garage aren't clear by 8, the whole day starts late." },
      { t: "Front-door liability", d: "Lobbies, plazas and revolving doors see the heaviest foot traffic in the building." },
      { t: "Tenant complaints", d: "Tenants call the property team, and the property team calls you." },
    ],
    plan: ["Main entrances and revolving doors", "Plazas and building walkways", "Garage ramps and parking", "Accessible entrances and ramps", "Bank branch frontages and ATM approaches"],
    services: ["pre-storm-anti-icing", "sidewalk-snow-removal", "snow-shoveling"],
    quote: "kevin",
    faq: [
      ["Can you be done before 8 AM?", "Yes. Your plan sets the ready-by time for each entrance and crews work through the night to meet it."],
      ["Do you cover bank branches across the city?", "Yes. Branch networks get one plan covering every location, with crews staged by borough."],
      ["Do you clear garages and ramps?", "Yes. Garage entries, exits and ramps are pre-treated and kept clear through the storm."],
    ],
  },
  {
    slug: "property-managers", name: "Property & facilities managers", img: IMG.crossing, logos: ["Target", "Verizon", "The Frick Collection"],
    seo: { title: "Snow Removal for Property Managers NYC | Facilities Snow Management | Novus", description: "Snow and ice management for NYC property and facilities managers. One written plan per building, one point of contact and crews on site before the storm, not after it." },
    hero: { title: "Stop chasing your snow contractor *at 3 AM.*", sub: "One written plan for every building, one point of contact, and crews on site before the storm instead of after it." },
    stakes: [
      { t: "\"I never heard from them until it started snowing\"", d: "Silence before a storm usually means nobody planned your site." },
      { t: "\"They were stretched too thin\"", d: "Contractors who take every job run out of crews on the big nights." },
      { t: "The liability lands on you", d: "When a tenant or visitor slips, the first question is what the plan was." },
    ],
    plan: ["A pre-season walk of every building you manage", "Written priorities for each site: what's cleared first", "Pre-treatment before every forecast storm", "Clear ready-by times for entrances and sidewalks", "One Novus contact for your whole portfolio"],
    services: ["seasonal-snow-contracts", "pre-storm-anti-icing", "sidewalk-snow-removal"],
    quote: "yasin",
    faq: [
      ["Can you cover a whole portfolio?", "Yes. Every building gets its own plan, and you get one point of contact for all of them."],
      ["What happens if a tenant reports a problem?", "Call or text us 24/7 on (917) 970-2960 and the borough crew is sent back to the site."],
      ["Why commercial only?", "Because business sites shouldn't wait behind residential driveways. Every crew and truck is dedicated to commercial properties."],
    ],
  },
  {
    slug: "construction-sites", name: "Construction sites", img: IMG.construction, logos: ["Triton Construction"],
    seo: { title: "Construction Site Snow Removal NYC | Keep Sites Working Through Winter | Novus", description: "Snow and ice management for NYC construction sites. Gates, haul roads, laydown areas and pedestrian paths pre-treated and cleared so the site keeps working through winter." },
    hero: { title: "Keep the site *working through winter.*", sub: "Gates, haul roads, laydown areas and pedestrian paths pre-treated and cleared, so deliveries land and crews work instead of digging out." },
    stakes: [
      { t: "Lost working days", d: "A site that spends the morning digging out has already lost the day." },
      { t: "Blocked deliveries", d: "Buried gates and haul roads mean concrete and steel sit on trucks." },
      { t: "Slippery access", d: "Stair towers, walkways and the public path past the site all need clearing." },
    ],
    plan: ["Site gates and haul roads", "Laydown and staging areas", "Walkways, stair towers and access routes", "Public sidewalks and paths past the site", "Snow stacked or hauled away from work areas"],
    services: ["commercial-snow-plowing", "snow-hauling", "pre-storm-anti-icing"],
    quote: "yasin",
    faq: [
      ["Can you work around an active site?", "Yes. Your plan sets access routes, gate times and where equipment can and can't go."],
      ["Do you clear the public sidewalk next to the site?", "Yes. Public paths past the site are on the same DSNY clock as any frontage."],
      ["Can you haul snow out of a tight site?", "Yes. Hauling is scheduled around deliveries and work hours."],
    ],
  },
  {
    slug: "cultural-venues", name: "Museums & cultural venues", img: IMG.stoop, logos: ["The Frick Collection"],
    seo: { title: "Snow Removal for Museums & Cultural Venues NYC | Novus Maintenance", description: "Snow and ice management for NYC museums, galleries and cultural venues. Steps, plazas and accessible entrances treated with less corrosive materials and safe for every visitor." },
    hero: { title: "Steps, plazas and entrances *safe for every visitor.*", sub: "Museums, galleries and cultural venues cleared and treated with less corrosive materials that are kinder to stone, steps and historic entrances." },
    stakes: [
      { t: "Grand steps and plazas", d: "Wide stone steps and open plazas are beautiful, and slippery when they freeze." },
      { t: "Surfaces worth protecting", d: "Stone, granite and historic entrances don't need buckets of harsh rock salt." },
      { t: "Visitors on a schedule", d: "Openings, tours and events run whether it snows or not." },
    ],
    plan: ["Front steps and landings, by hand", "Accessible entrances and ramps", "Plazas and forecourts", "Staff, service and loading entrances", "Less corrosive treatment near stone"],
    services: ["snow-shoveling", "de-icing-salting", "pre-storm-anti-icing"],
    quote: "kevin",
    faq: [
      ["Do you use materials that are safe near stone?", "We use premium, less corrosive materials applied in measured amounts, which is kinder to stone, granite and historic surfaces."],
      ["Can you clear before an evening event?", "Yes. Event times can be written into your plan as ready-by times."],
      ["Do you keep accessible entrances clear?", "Yes. Accessible routes and ramps are priorities in every plan."],
    ],
  },
  {
    slug: "gyms-fitness", name: "Gyms & fitness studios", img: IMG.mnNight, logos: ["NakeFit"],
    seo: { title: "Snow Removal for Gyms & Fitness Studios NYC | Early-Morning Clearing | Novus", description: "Snow and ice management for NYC gyms and fitness studios. Entrances and sidewalks pre-treated and cleared before the first early-morning class, at every location." },
    hero: { title: "Members show up. *Your entrance is ready.*", sub: "Entrances and sidewalks pre-treated and cleared before the first early class, at every location you run." },
    stakes: [
      { t: "Early opening hours", d: "Your first members arrive before most contractors have left the yard." },
      { t: "Cancelled classes", d: "A blocked entrance turns a snow day into a refund day." },
      { t: "Several locations", d: "Every studio needs the same standard on the same morning." },
    ],
    plan: ["Entrance cleared and treated before first class", "Frontage cleared to a 4-foot path", "Re-treated between morning and evening peaks", "Every location on one plan", "One contact for the whole brand"],
    services: ["sidewalk-snow-removal", "pre-storm-anti-icing", "seasonal-snow-contracts"],
    quote: "nakefit",
    faq: [
      ["Can you clear before a 6 AM class?", "Yes. Your plan sets a ready-by time for every location and crews work through the night to meet it."],
      ["Do you cover multiple studios?", "Yes. NakeFit USA uses Novus across its locations. One plan, one contact, every site."],
      ["What about the evening peak?", "Entrances are re-treated between peaks so melt doesn't refreeze before the evening rush."],
    ],
  },
];

/* ---------------------------------------------------------------- GUIDES */
export const GUIDES = [
  {
    slug: "nyc-sidewalk-snow-removal-law",
    name: "NYC sidewalk snow law",
    short: "Deadlines, fines and what 'clear' means under DSNY rules.",
    img: IMG.walkers,
    seo: { title: "NYC Sidewalk Snow Removal Law 2026: Deadlines, Fines & Rules | Novus", description: "The NYC sidewalk snow removal rules explained: the 4-hour, 14-hour and 11 AM deadlines, the 4-foot path, corners, hydrants, bus stops and DSNY fines from $100 to $250." },
    hero: { eyebrow: "Guide", title: "NYC sidewalk snow law, *in plain English.*", sub: "The deadlines, the fines and what 'clear' actually means, from current DSNY guidance. Updated for the 2026 to 2027 season." },
    calculator: true,
    sections: [
      { h: "Who has to clear the sidewalk?", p: ["The person in charge of a building or lot with a paved sidewalk must clear it. For commercial property, that means owners, lessees, tenants, occupants or whoever manages the building. A contract with a snow company doesn't move the deadline, so it pays to know your contractor will hit it."] },
      { h: "How long do you have?", p: ["The deadline depends on when the snow stops falling, not when it starts."], table: { head: ["Snow stops between", "Sidewalk must be clear"], rows: [["7:00 AM and 4:59 PM", "Within 4 hours"], ["5:00 PM and 8:59 PM", "Within 14 hours"], ["9:00 PM and 6:59 AM", "By 11:00 AM"]] } },
      { h: "What counts as 'clear'?", list: ["A path at least 4 feet wide along the sidewalk", "Corner properties: clear through to the crosswalk and the pedestrian ramp (curb cut)", "Snow and ice removed from around fire hydrants", "Bus stops without a shelter are the property owner's to clear", "Ice has to be removed too, or treated with salt, sand or similar if it can't be"] },
      { h: "Where can the snow go?", p: ["Not into the street. Shoveling, blowing or pushing snow into the roadway can earn a separate summons. Stack it on your own property or have it hauled away."] },
      { h: "What are the fines?", p: ["DSNY sets the fine at $100 for a first offense, $150 for a second and $250 for a third. For a business with several frontages, a run of storms adds up quickly, and a fine is the smallest cost of an icy sidewalk."] },
      { h: "How to stay ahead of the clock", p: ["The easiest deadline to meet is the one you start before the snow does. Pre-treating sidewalks ahead of the storm stops snow bonding to the pavement, so crews working during the storm can keep the path open instead of racing the clock after it stops."], link: { href: "/services/pre-storm-anti-icing", label: "How pre-storm anti-icing works" } },
    ],
    sources: [["NYC DSNY: Snow and Ice Removal from Sidewalks", "https://www.nyc.gov/site/dsny/what-we-do/snow-response/snow-laws.page"], ["NYC 311: Snow or Ice on Sidewalk", "https://portal.311.nyc.gov/article/?kanumber=KA-01397"]],
    faq: [
      ["What happens if snow stops at 4 PM?", "You have 4 hours, so the sidewalk must be clear by 8 PM."],
      ["Does hiring a contractor protect me from fines?", "No. The deadline applies to the person in charge of the property. That's why it matters that your contractor works during the storm."],
      ["Do I have to clear ice as well as snow?", "Yes. Ice that can't be removed has to be covered with salt, sand or a similar material."],
    ],
  },
  {
    slug: "anti-icing-vs-de-icing",
    name: "Anti-icing vs de-icing",
    short: "Why treating before the storm beats salting after it.",
    img: IMG.spreader,
    seo: { title: "Anti-Icing vs De-Icing: What's the Difference? | Commercial Guide | Novus", description: "Anti-icing vs de-icing explained for property and facility managers: how pre-storm treatment stops ice bonding, why it uses far less salt, and what to ask your snow contractor." },
    hero: { eyebrow: "Guide", title: "Anti-icing vs de-icing: *why timing beats tonnage.*", sub: "Two ways to fight ice. One of them works before the problem exists. Here's the difference, and what it means for your site." },
    sections: [
      { h: "The short version", p: ["Anti-icing is treating pavement before snow or ice arrives, so it can't bond to the surface. De-icing is melting ice that has already formed. Researchers often compare anti-icing to greasing a pan before you crack an egg: the egg lifts straight off."] },
      { h: "Side by side", table: { head: ["", "Anti-icing", "De-icing"], rows: [["When", "Before the storm", "During or after"], ["Goal", "Stop the ice bond forming", "Break a bond that has formed"], ["Typical form", "Liquid or pre-wetted treatment", "Granular salt or blends"], ["Material", "Roughly 1/4 to 1/5 as much*", "More"], ["Result", "Snow lifts clean when plowed", "Slower, more scraping"]] }, note: "*APWA research: anti-icing delivers the same level of service with one quarter to one fifth of the salt de-icing uses." },
      { h: "Why the bond matters", p: ["When snow or freezing rain hits bare cold pavement, it freezes to the surface. Once that bond forms, every pass afterwards is spent breaking it, which takes more material, more time and more passes. A treatment layer laid down first keeps a thin barrier between the pavement and the snow, so plows and shovels can lift it off."] },
      { h: "When should anti-icing go down?", p: ["As close to the storm as practical. State best-practice guides suggest it's most effective applied an hour or two before precipitation starts, and it can be applied up to 24 hours ahead. That's why a contractor's forecast watching and staging matter as much as their trucks."] },
      { h: "Do you still need de-icing?", p: ["Yes. Anti-icing makes the storm easier, but heavy snow still needs plowing and treating during the storm, and melt still needs re-treating before it refreezes overnight. The best plans use both and lead with prevention."] },
      { h: "Questions to ask your snow contractor", list: ["Do you pre-treat before the storm, or only salt after it?", "How far ahead of a forecast do you stage crews and material?", "Which surfaces on my site get treated first?", "What materials do you use near entrances, pavers and stone?", "Do you re-treat before overnight refreeze?"] },
    ],
    sources: [["UConn T2 / APWA: Salt brine fact sheet", "https://www.cti.uconn.edu/images/cti/documents/T2Center/winter/BrineFactSheet.pdf"], ["MnLTAP Smart Winter Salt: deicing vs anti-icing", "https://mnltap.umn.edu/guides/smartwintersalt/property-managers/rates/deicing"]],
    faq: [
      ["Is anti-icing only for roads?", "No. City agencies use it on roads, and commercial contractors use it on lots, sidewalks, entrances and ramps."],
      ["Does anti-icing work in heavy snow?", "It makes heavy snow easier to clear because it stops the bottom layer bonding, but heavy storms still need plowing and treatment during the storm."],
      ["Is anti-icing more expensive?", "It generally uses far less material for the same result, and it cuts down the passes needed after the storm."],
    ],
  },
  {
    slug: "commercial-winter-readiness-checklist",
    name: "Winter readiness checklist",
    short: "What every facility manager should have in place before the first storm.",
    img: IMG.bridge,
    seo: { title: "Commercial Winter Readiness Checklist for NYC Facility Managers | Novus", description: "An interactive winter readiness checklist for NYC property and facility managers: site maps, priorities, contracts, de-icing language, contacts and refreeze risks, before the first storm." },
    hero: { eyebrow: "Checklist", title: "Is your site *ready for the first storm?*", sub: "Tick through what most facility managers wish they'd sorted before the first snow. It takes five minutes." },
    checklist: [
      { g: "Your site", items: ["A site map with entrances, lots, ramps and stairs marked", "Priorities written down: what has to be clear first", "Stacking areas chosen away from drains, hydrants and sightlines", "Downspouts and drains checked so melt doesn't run across walkways", "Entrance mats and wet-floor signs ready"] },
      { g: "Your contract", items: ["Snow and ice both named in the scope, including de-icing", "Pre-storm treatment included, not just salting after", "Ready-by times written for entrances and sidewalks", "What happens with back-to-back storms", "Proof of insurance on file"] },
      { g: "Your people", items: ["One contact at your snow company who answers 24/7", "Tenants and staff told who to call", "An internal owner for winter on your team", "The DSNY sidewalk deadlines understood by whoever is on call"] },
    ],
    sections: [
      { h: "Why do this before the first storm?", p: ["Contractors assign crews and routes ahead of the season. A site that signs up mid-winter joins the end of a list. A plan agreed in the fall means your site is mapped, prioritized and pre-treated before the first forecast."] },
    ],
    faq: [
      ["When should we start winter planning?", "In the fall, before the first forecast storm. Site walks and contracts take time to set up."],
      ["What's the most common gap?", "Contracts that cover snow but not ice. Make sure de-icing and pre-treatment are named in the scope."],
    ],
  },
];

/* ---------------------------------------------------------------- HOW IT WORKS */
export const HOW = {
  seo: { title: "How Novus Works | Prevention-First Commercial Snow Management NYC", description: "How Novus runs a storm: pre-season site walk, forecast watch, pre-treatment before the first flake, clearing during the storm and re-treating against refreeze." },
  phases: [
    { when: "October and November", title: "We walk your site and *write the plan.*", text: "Entrances, lots, docks, stacking areas and hazards mapped before the season, with priorities and ready-by times agreed in writing." },
    { when: "48 to 24 hours out", title: "The forecast puts your site *on watch.*", text: "Our team watches the forecasts through the season. When snow or freezing rain is coming, your borough crew and material are staged." },
    { when: "Hours before the first flake", title: "Surfaces get *pre-treated.*", text: "Entrances, sidewalks, ramps and lot lanes are treated so snow can't bond to the pavement." },
    { when: "During the storm", title: "Crews clear *as it falls.*", text: "Plows work lots at the depths set in your plan while hand crews keep entrances, steps and exits open." },
    { when: "When the snow stops", title: "Sidewalks done *inside the window.*", text: "Final passes on frontages, corners and curb cuts, working to the DSNY deadline, not after it." },
    { when: "The morning after", title: "Re-treated, hauled if needed, *open on time.*", text: "Surfaces re-treated against refreeze, piles hauled if space is tight, and the site ready before your doors open." },
  ],
  never: ["Chase a contractor at 3 AM", "Wonder whether anyone is coming", "Race the sidewalk clock yourself", "Explain to a tenant why the entrance is icy", "Shovel the front steps yourself"],
};
