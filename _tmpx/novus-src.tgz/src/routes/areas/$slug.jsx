import { createFileRoute, notFound } from "@tanstack/react-router";
import { BOROUGHS } from "@/content/site";
import { Page } from "@/components/novus/site/Shell";
import { PageBlocks, boroughBlocks } from "@/components/novus/site/Blocks";
import { pageHead, crumbLd, faqLd, serviceLd } from "@/lib/seo";

const find = (slug) => BOROUGHS.find((b) => b.slug === slug);

export const Route = createFileRoute("/areas/$slug")({
  loader: ({ params }) => {
    if (!find(params.slug)) throw notFound();
    return { slug: params.slug };
  },
  head: ({ params }) => {
    const b = find(params.slug);
    if (!b) return {};
    const path = "/areas/" + b.slug;
    return pageHead({
      title: b.seo.title, description: b.seo.description, path, image: b.img,
      ld: [serviceLd({ name: "Commercial snow removal in " + b.name, description: b.seo.description, path, area: b.name }), crumbLd([{ name: "Areas", path: "/areas" }, { name: b.name, path }]), faqLd(b.faq)],
    });
  },
  component: AreaPage,
});

function AreaPage() {
  const { slug } = Route.useLoaderData();
  const b = find(slug);
  return (
    <Page path={slug}>
      <PageBlocks blocks={boroughBlocks(b)} crumbs={[{ label: "Areas", href: "/areas" }, { label: b.name }]} preset={{ where: [b.name] }} />
    </Page>
  );
}
