import { createFileRoute } from "@tanstack/react-router";
import { BOROUGHS } from "@/content/site";
import { Page } from "@/components/novus/site/Shell";
import { Hero, LinkCards, FormSec, Cta } from "@/components/novus/site/Blocks";
import { pageHead, crumbLd } from "@/lib/seo";

const items = BOROUGHS.map((b) => ({ ...b, short: b.hero.sub }));

export const Route = createFileRoute("/areas/")({
  head: () => pageHead({
    title: "Commercial Snow Removal Across NYC | All Five Boroughs | Novus Maintenance",
    description: "Commercial snow removal in Manhattan, Brooklyn, Queens, the Bronx and Staten Island. Crews based across the city and staged before every storm, 24/7.",
    path: "/areas",
    ld: [crumbLd([{ name: "Areas", path: "/areas" }])],
  }),
  component: () => (
    <Page path="areas">
      <Hero b={{ v: "center", img: "bridge", eyebrow: "Areas we cover", kw: "Commercial snow removal in all five boroughs", title: "Crews in *every borough,* staged before every storm.", sub: "Six offices and yards across New York City and New Jersey mean shorter routes and crews close to your site before the forecast turns." }} crumbs={[{ label: "Areas" }]} />
      <LinkCards eyebrow="Five boroughs" title="Find *your borough.*" items={items} base="/areas/" />
      <FormSec b={{}} />
      <Cta b={{ title: "Already *nearby.*", text: "Wherever your sites are, a Novus crew is close." }} />
    </Page>
  ),
});
