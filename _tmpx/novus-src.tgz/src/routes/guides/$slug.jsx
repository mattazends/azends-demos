import { createFileRoute, notFound } from "@tanstack/react-router";
import { GUIDES } from "@/content/site";
import { Page } from "@/components/novus/site/Shell";
import { GuideBody } from "@/components/novus/site/Guide";
import { pageHead, crumbLd, faqLd, articleLd } from "@/lib/seo";

const find = (slug) => GUIDES.find((g) => g.slug === slug);

export const Route = createFileRoute("/guides/$slug")({
  loader: ({ params }) => {
    if (!find(params.slug)) throw notFound();
    return { slug: params.slug };
  },
  head: ({ params }) => {
    const g = find(params.slug);
    if (!g) return {};
    const path = "/guides/" + g.slug;
    return pageHead({
      title: g.seo.title, description: g.seo.description, path, image: g.img,
      ld: [articleLd({ title: g.seo.title, description: g.seo.description, path }), crumbLd([{ name: "Guides", path: "/guides" }, { name: g.name, path }]), faqLd(g.faq)],
    });
  },
  component: GuidePage,
});

function GuidePage() {
  const { slug } = Route.useLoaderData();
  const g = find(slug);
  return (
    <Page path={slug}>
      <GuideBody g={g} />
    </Page>
  );
}
