import { createFileRoute } from "@tanstack/react-router";
import { GUIDES } from "@/content/site";
import { Page } from "@/components/novus/site/Shell";
import { Hero, LinkCards, FormSec } from "@/components/novus/site/Blocks";
import { pageHead, crumbLd } from "@/lib/seo";

export const Route = createFileRoute("/guides/")({
  head: () => pageHead({
    title: "Commercial Snow & Ice Guides for NYC Property Managers | Novus Maintenance",
    description: "Plain-English guides for NYC facility and property managers: the sidewalk snow law, anti-icing vs de-icing and a winter readiness checklist.",
    path: "/guides",
    ld: [crumbLd([{ name: "Guides", path: "/guides" }])],
  }),
  component: () => (
    <Page path="guides">
      <Hero b={{ v: "center", img: "walkers", eyebrow: "Guides", kw: "Guides for NYC facility & property managers", title: "Know the rules. *Beat the storm.*", sub: "Plain-English guides to the NYC sidewalk law, pre-storm treatment and getting your site ready for winter." }} crumbs={[{ label: "Guides" }]} />
      <LinkCards eyebrow="Read" title="Start *here.*" items={GUIDES} base="/guides/" />
      <FormSec b={{}} />
    </Page>
  ),
});
