import { createFileRoute } from "@tanstack/react-router";
import { HOW, SERVICES } from "@/content/site";
import { Page, Eyebrow, Words, SnowCanvas, Tick } from "@/components/novus/site/Shell";
import { Hero, LinkCards, FormSec, Cta, Faq, Logos } from "@/components/novus/site/Blocks";
import { pageHead, crumbLd, faqLd } from "@/lib/seo";

const FAQ = [
  ["When does Novus first come to my site?", "Before the season. We walk the site, map entrances, lots, stacking areas and hazards, and agree priorities and ready-by times in writing."],
  ["How do you know when to pre-treat?", "Our team watches the forecasts through the season. When snow or freezing rain is coming, crews and material are staged 24 to 48 hours out and surfaces are treated before it starts."],
  ["Do I have to call you when it snows?", "No. Your site is on the plan, so crews come automatically. You can still reach us 24/7 on (917) 970-2960."],
  ["What happens after the storm?", "Surfaces are re-treated against refreeze, piles are hauled if space is tight, and the site is checked before your doors open."],
];

export const Route = createFileRoute("/how-it-works")({
  head: () => pageHead({
    title: HOW.seo.title, description: HOW.seo.description, path: "/how-it-works",
    ld: [crumbLd([{ name: "How it works", path: "/how-it-works" }]), faqLd(FAQ)],
  }),
  component: HowPage,
});

function HowPage() {
  return (
    <Page path="how">
      <Hero b={{ v: "center", img: "hero", eyebrow: "How it works", kw: "How Novus runs a storm", title: "We start *before the snow does.*", sub: "Most contractors are called when it starts snowing. Novus crews have already treated your site by then. Here's the whole storm, step by step." }} crumbs={[{ label: "How it works" }]} />
      <section className="sec storm tl">
        <SnowCanvas density={22} />
        <div className="wrap">
          <div className="sec-head"><div><Eyebrow light>The Novus storm protocol</Eyebrow><Words text="Six stages. *Three happen before it snows.*" /></div><p className="lead rv d1">Prevention does most of the work. By the time the first flake lands, your site has a plan, a crew and a treatment layer.</p></div>
          <ol className="tl-list six">
            {HOW.phases.map((s, i) => (
              <li className={"tl-i rv" + (i < 3 ? " pre" : "")} key={i}>
                <span className="tl-n">{String(i + 1).padStart(2, "0")}</span>
                <div className="when">{s.when}{i < 3 && <em>Before the snow</em>}</div>
                <h3>{s.title.split("*").map((p, j) => (j % 2 ? <b key={j}>{p}</b> : p))}</h3>
                <p>{s.text}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>
      <section className="sec never-sec">
        <div className="wrap never">
          <div>
            <Eyebrow>What you stop doing</Eyebrow>
            <Words text="With a Novus plan, *you never have to:*" style={{ marginTop: 18 }} />
          </div>
          <ul className="never-list">{HOW.never.map((x, i) => <li className={"rv d" + Math.min(4, i)} key={x}><span className="b"><Tick /></span>{x}</li>)}</ul>
        </div>
      </section>
      <Logos />
      <LinkCards eyebrow="The services" title="What goes *into the plan.*" items={SERVICES} base="/services/" />
      <Faq b={{ title: "How it works, *answered.*", items: FAQ }} />
      <FormSec b={{ title: "Start your plan *before the first storm.*" }} />
      <Cta b={{ title: "Ready *before it snows.*", text: "Spend this winter not thinking about it." }} />
    </Page>
  );
}
