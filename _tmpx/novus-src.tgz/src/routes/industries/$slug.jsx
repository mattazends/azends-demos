import { createFileRoute, notFound } from "@tanstack/react-router";
import { INDUSTRIES } from "@/content/site";
import { Page } from "@/components/novus/site/Shell";
import { PageBlocks, industryBlocks } from "@/components/novus/site/Blocks";
import { pageHead, crumbLd, faqLd, serviceLd } from "@/lib/seo";

const find = (slug) => INDUSTRIES.find((i) => i.slug === slug);

export const Route = createFileRoute("/industries/$slug")({
  loader: ({ params }) => {
    if (!find(params.slug)) throw notFound();
    return { slug: params.slug };
  },
  head: ({ params }) => {
    const ind = find(params.slug);
    if (!ind) return {};
    const path = "/industries/" + ind.slug;
    return pageHead({
      title: ind.seo.title, description: ind.seo.description, path, image: ind.img,
      ld: [serviceLd({ name: "Snow and ice management for " + ind.name.toLowerCase(), description: ind.seo.description, path }), crumbLd([{ name: "Industries", path: "/industries" }, { name: ind.name, path }]), faqLd(ind.faq)],
    });
  },
  component: IndustryPage,
});

function IndustryPage() {
  const { slug } = Route.useLoaderData();
  const ind = find(slug);
  return (
    <Page path={slug}>
      <PageBlocks blocks={industryBlocks(ind)} crumbs={[{ label: "Industries", href: "/industries" }, { label: ind.name }]} />
    </Page>
  );
}
