import { createFileRoute } from "@tanstack/react-router";
import { INDUSTRIES } from "@/content/site";
import { Page } from "@/components/novus/site/Shell";
import { Hero, LinkCards, FormSec, Cta, Logos } from "@/components/novus/site/Blocks";
import { pageHead, crumbLd } from "@/lib/seo";

const items = INDUSTRIES.map((i) => ({ ...i, short: i.hero.sub }));

export const Route = createFileRoute("/industries/")({
  head: () => pageHead({
    title: "Commercial Snow Removal by Industry NYC | Retail, Offices, Construction | Novus",
    description: "Snow and ice management planned around how your business runs: retail, offices and banks, property managers, construction sites, cultural venues and gyms across NYC.",
    path: "/industries",
    ld: [crumbLd([{ name: "Industries", path: "/industries" }])],
  }),
  component: () => (
    <Page path="industries">
      <Hero b={{ v: "center", img: "crossing", eyebrow: "Industries", kw: "Commercial snow & ice management by industry", title: "Planned around *how your business runs.*", sub: "A gym opening at 6 AM and a museum with granite steps need different plans. Every Novus plan starts with how your site is used." }} crumbs={[{ label: "Industries" }]} />
      <Logos />
      <LinkCards eyebrow="Who we clear for" title="Find *your industry.*" items={items} base="/industries/" />
      <FormSec b={{}} />
      <Cta b={{ title: "Ready *before it snows.*", text: "Commercial only. Snow only. 24/7." }} />
    </Page>
  ),
});
