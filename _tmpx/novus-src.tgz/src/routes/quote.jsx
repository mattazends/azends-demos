import { createFileRoute } from "@tanstack/react-router";
import { Page, Crumbs, Words, SnowCanvas } from "@/components/novus/site/Shell";
import { FormSec, Logos } from "@/components/novus/site/Blocks";
import { pageHead, crumbLd } from "@/lib/seo";

export const Route = createFileRoute("/quote")({
  head: () => pageHead({
    title: "Get a Commercial Snow Removal Quote NYC | Novus Maintenance",
    description: "Get a seasonal snow and ice plan and price for your NYC commercial site in under a minute. Commercial properties only. Call 24/7 on (917) 970-2960.",
    path: "/quote",
    ld: [crumbLd([{ name: "Get a quote", path: "/quote" }])],
  }),
  component: () => (
    <Page path="quote">
      <section className="ph ph-mini">
        <SnowCanvas density={16} />
        <div className="wrap ph-in">
          <Crumbs items={[{ label: "Get a quote" }]} />
          <h1><span className="kw rv">Commercial snow removal quote · NYC</span><Words as="span" className="big" text="Your snow plan, *priced in a minute.*" /></h1>
        </div>
      </section>
      <FormSec b={{ title: "Tell us about *your site.*", lead: "Five quick taps. A Novus manager comes back with a written plan and a price for the season. Commercial properties only." }} />
      <Logos />
    </Page>
  ),
});
