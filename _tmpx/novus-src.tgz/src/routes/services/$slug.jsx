import { createFileRoute, notFound } from "@tanstack/react-router";
import { SERVICES } from "@/content/site";
import { Page } from "@/components/novus/site/Shell";
import { PageBlocks } from "@/components/novus/site/Blocks";
import { pageHead, crumbLd, faqLd, serviceLd } from "@/lib/seo";

const find = (slug) => SERVICES.find((s) => s.slug === slug);

export const Route = createFileRoute("/services/$slug")({
  loader: ({ params }) => {
    if (!find(params.slug)) throw notFound();
    return { slug: params.slug };
  },
  head: ({ params }) => {
    const s = find(params.slug);
    if (!s) return {};
    const path = "/services/" + s.slug;
    const faq = s.blocks.find((b) => b.t === "faq");
    return pageHead({
      title: s.seo.title, description: s.seo.description, path, image: s.img,
      ld: [serviceLd({ name: s.name, description: s.seo.description, path }), crumbLd([{ name: "Services", path: "/services" }, { name: s.name, path }]), faqLd(faq && faq.items)],
    });
  },
  component: ServicePage,
});

function ServicePage() {
  const { slug } = Route.useLoaderData();
  const s = find(slug);
  return (
    <Page path={slug}>
      <PageBlocks blocks={s.blocks} crumbs={[{ label: "Services", href: "/services" }, { label: s.name }]} preset={{ needs: [s.need] }} />
    </Page>
  );
}
