import { createFileRoute } from "@tanstack/react-router";
import { SERVICES } from "@/content/site";
import { Page } from "@/components/novus/site/Shell";
import { Hero, LinkCards, FormSec, Cta, Logos } from "@/components/novus/site/Blocks";
import { pageHead, crumbLd } from "@/lib/seo";

export const Route = createFileRoute("/services/")({
  head: () => pageHead({
    title: "Commercial Snow & Ice Services NYC | Anti-Icing, Plowing, Sidewalks | Novus",
    description: "Every commercial snow and ice service in one plan: pre-storm anti-icing, plowing, sidewalk clearing, de-icing, hand crews, hauling and seasonal contracts across NYC.",
    path: "/services",
    ld: [crumbLd([{ name: "Services", path: "/services" }])],
  }),
  component: () => (
    <Page path="services">
      <Hero b={{ v: "center", img: "spreader", eyebrow: "Services", kw: "Commercial snow & ice services in NYC", title: "Everything your site needs, *starting before it snows.*", sub: "Most contractors start when the snow does. Our plans start with treatment before the storm, then clearing during it and re-treating after." }} crumbs={[{ label: "Services" }]} />
      <Logos />
      <LinkCards eyebrow="Seven services, one plan" title="Pick what you need. *Or let us plan all of it.*" items={SERVICES} base="/services/" />
      <FormSec b={{}} />
      <Cta b={{ title: "Ready *before it snows.*", text: "One team for the whole storm, from the first treatment to the last pile hauled away." }} />
    </Page>
  ),
});
