<!-- Optional: Claude fills this in for you on the first chat. You can also fill it yourself and add it to your Project files. -->
# Video profile: <agency>
## Me
- Agency: <name> | site: <url> | IG: <@handle>
- Offer: <one line> | Guarantee wording: <exact Dutch wording>
- CTA for my own ads: <e.g. "Klik hieronder en plan een gesprek van 15 min">
- CTA for organic: <e.g. "Reageer DAK en ik stuur je ...">
- Brand: accent <#hex> | ink #0A0A0A | never: <things to avoid>
- Tone on screen: Dutch, <je/u>, direct, no hype

## Clients
| client | region | services | offer | CTA (Dutch) | accent | address as |
|---|---|---|---|---|---|---|
| <Dakbedrijf X> | <Assen, Drenthe> | <dakgoten, lekkages, bitumen> | <gratis dakinspectie> | <Vraag je gratis inspectie aan> | <#hex> | <je/u> |

## Filming
- Usually films: <office/car/site>, sends: <raw/cut>, music: <none / sends track>

## Edit rules (grows over time from his feedback, newest last)
- (none yet)
