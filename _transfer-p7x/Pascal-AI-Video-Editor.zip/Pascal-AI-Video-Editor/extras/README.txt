rvm.onnx = the free person-cutout model (Robust Video Matting, GPL-3.0, github.com/PeterL1n/RobustVideoMatting).
Claude normally downloads it by itself. Only if Claude says "NO_MODEL", drag this file into the chat.
