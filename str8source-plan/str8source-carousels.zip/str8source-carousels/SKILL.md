---
name: str8source-carousels
description: Make clean Instagram carousels for STR8 SOURCE and The Source from Vin's own photos, darkened behind simple white text. Use whenever Vin asks for a carousel, swipe post, slides, an IG post, "turn this into a post", or any feed creative for @str8s0urce.
---

# STR8 SOURCE carousels

You make finished, ready-to-post Instagram carousels for Vin (@str8s0urce). The look is simple on purpose: his own photo, darkened, with clean white text. No templates, no badges, no gold boxes, no arrows, no emojis on the slides. It should look like a premium brand posted it, not a design tool.

## Two styles
- **editorial** (default): text centred over the photo, small wordmark at the bottom. Quiet and premium. Best for hooks, lifestyle and one-liners.
- **post**: reads like a post from Vin, with his avatar, name and @str8s0urce at the top, then left-aligned text over a blurred, darker photo. Best for advice, opinions and stories.

You can mix them in one carousel (e.g. an editorial hook, then post-style slides).

## Workflow
1. **Get his photos.** Ask Vin to drag in 3 to 10 of his own photos or posts if he hasn't. Only ever use his photos. If he wants his face in the post-style avatar, ask for a square photo of him and pass it as `avatar`.
2. **Get the words.** If he gives you a script, keep his words and tighten them. If he gives a topic, pick a format from `references/formats.md`.
3. **Write the slides.** Rules:
   - Slide 1 stops the scroll. 12 words max.
   - Slide 2 has to make them keep swiping. No intros.
   - One idea per slide, under 30 words.
   - `*word*` makes a word bold. Use it on 1 to 3 words a slide at most.
   - Last slide is the ask: "Comment PLUG", "Reply SOURCE", or "Link in bio".
   - UK spelling, plain words, how Vin talks. No em dashes, no hashtags on slides, no "game-changer", "unlock", "level up".
4. **Match photos.** Strongest photo on slide 1. Look at each photo: if it's busy, set `dim` lower (0.28 to 0.34) or add `blur`. Use `focus` to keep the subject in frame. Don't repeat a photo on back-to-back slides. `"bg": "dark"` is fine for one text-only slide.
5. **Render.** Put the photos next to `spec.json` and run:
   ```
   python3 <skill-dir>/scripts/render.py spec.json out/
   ```
   (Install Pillow first if it's missing: `pip install pillow`.) It writes the PNGs (1080 x 1350) and `_contact-sheet.jpg`.
6. **Check.** Look at the contact sheet and slide 1 full size. Re-render if any text is hard to read, a line ends on one lonely word, or the slides don't read as one story.
7. **Deliver.** The PNGs (zipped if more than 4) and a caption he can copy: hook line, 2 to 4 short lines, the ask, then 3 to 5 hashtags.

## spec.json
```json
{
  "name": "supplier-post",
  "style": "editorial",
  "author": "Vin",
  "handle": "@str8s0urce",
  "avatar": "me.jpg",
  "slides": [
    {"bg": "haul.jpg", "text": "I made £500k reselling while at college full time."},
    {"bg": "stock.jpg", "style": "post", "text": "Stop buying from the same places as everyone else.\n\nIf 10,000 people can buy it at that price, there's no margin left for you."},
    {"bg": "dark", "text": "Know your profit before you buy. Every single time.", "sub": "Save this for your next buy."},
    {"bg": "paris.jpg", "style": "post", "text": "Want my supplier list?\n\nComment *PLUG* and I'll send it to you."}
  ]
}
```
Slide fields: `text` (required), `bg`, `style`, `sub` (editorial only, a small line under the text), `dim`, `blur`, `focus` [x, y], `size` (text size), `cover` (true for big hook text on a slide that isn't first). `\n` = new line, `\n\n` = gap between paragraphs. Top-level `size` can be `4:5` (default), `1:1` or `9:16` for stories.

## If there's no code execution
Write the full spec.json and caption anyway, and tell Vin to turn on code execution in his Claude settings so you can make the images.

## Hard rules
- Only Vin's photos. Never stock photos, never AI images that pretend to be his life or results.
- Never invent numbers, results, screenshots or students. Use `references/facts.md` or what Vin tells you.
- Keep it plain. Don't add colours, shapes, stickers, emojis, borders or badges. The photo and the words do the work.
