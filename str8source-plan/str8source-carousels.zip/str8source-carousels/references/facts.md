# Facts you can use

Vin's own figures. Use them as written. Anything else, ask Vin first.

- £500k in sales since February 2024
- 784 orders shipped
- Did it while at college full time, alongside half marathon and Hyrox training
- 35 suppliers and 100+ trade groups
- 100+ resellers in the order community
- £6k net profit in August
- Student Finn sold a Rolex "Batgirl"
- Students Henry and Ben flip regularly (get their numbers from Vin first)
- Rated Excellent on Trustpilot

## The offers (The Source, by STR8 SOURCE)
- **Starter guide**: email sign-up, never called "free" on posts.
- **The Plug**: £200 one-off. Suppliers, trade groups, the order community, 3 modules, ready-made content, text support.
- **The Source**: £999 or 3 × £333, by application. 1-on-1 with Vin for 3 months, direct WhatsApp, everything in The Plug, a website built for you, winning products synced to your store with no stock in hand, AI Creative Kit, Drops channel, profit calculator. Guarantee: haven't made your money back in 3 months, Vin keeps working with you for free until you do.
- Line: Source. Store. Sell.

When a post shows results, add "Results vary" to the caption. If Vin changes a name, price or number, use his latest version.
