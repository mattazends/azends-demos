# Carousel formats

6 to 9 slides each. Last slide is always the ask.

1. **Flip breakdown** (trust). Hook "Bought for £X. Sold for £Y." Then where he found it, why he knew it'd sell, the numbers, the lesson. Real flips only.
2. **Guess the profit** (comments). Slide 1 "Bought for £90. What did it sell for? Guess before you swipe." Then the item, a clue, the answer, the lesson.
3. **Mistakes** (saves). "3 mistakes that kill your profit when you start reselling." One mistake per slide, then the one rule to remember.
4. **If I started again with £200** (sells The Plug). Step by step what he'd do, ending "Comment PLUG for my supplier list."
5. **Where I actually buy** (sells The Plug). Why most people buy from the wrong places, what a good supplier looks like, how to check one. Never name real suppliers.
6. **Student win** (sells The Source). The result in the student's words, where they started, what changed. Real students, with permission.
7. **What's inside The Source**. One slide each: suppliers, your store built for you, winning products synced with no stock, 1-on-1 with Vin for 3 months, the guarantee. Ends "Apply, link in bio."
8. **Myth vs truth** (shares). "Reselling myths that keep people broke." One myth and the truth per slide.
9. **Before you buy checklist** (saves). "Save this before your next buy." One check per slide.
10. **Lifestyle** (reach). Paris, hauls, the stock room. "Here's my £25,000 haul for my clients." Mostly photos, very few words.

## Hooks in his voice
- I made £500k reselling while at college full time.
- Here's what nobody tells you when you start reselling.
- Stop buying from where everyone else buys.
- The one rule I follow before every single buy.
- You've seen the hauls. You haven't seen the hard nights.
