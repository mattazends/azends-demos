#!/usr/bin/env python3
"""
STR8 SOURCE carousel renderer.

Turns spec.json into finished Instagram carousel PNGs: Vin's own photo,
darkened, with clean white type on top. Two styles:
  editorial  centred text over the photo, small wordmark at the bottom
  post       reads like a post from Vin: avatar, name, handle, then text

Usage:  python3 render.py spec.json out_dir/
Needs only Pillow. No browser, no internet.
"""
import json, math, os, sys
from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageEnhance, ImageOps

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FONTS = os.path.join(ROOT, "assets", "fonts")
S = 2
SIZES = {"4:5": (1080, 1350), "1:1": (1080, 1080), "9:16": (1080, 1920)}
WHITE = (255, 255, 255)
SOFT = (255, 255, 255, 170)

_fc = {}
def font(w, size):
    k = (w, size)
    if k not in _fc:
        _fc[k] = ImageFont.truetype(os.path.join(FONTS, f"Geist-{w}.ttf"), int(size * S))
    return _fc[k]

def words(text):
    """'*bold*' words use the bold weight. Returns paragraphs of [(word, bold)]."""
    paras = []
    for para in text.split("\n"):
        out, bold = [], False
        for i, part in enumerate(para.split("*")):
            if i: bold = not bold
            out += [(w, bold) for w in part.split(" ") if w]
        paras.append(out)
    return paras

def wrap(text, reg, bold, maxw):
    lines = []
    for para in words(text):
        if not para:
            lines.append([]); continue
        cur, cw = [], 0
        for w, b in para:
            f = bold if b else reg
            ww = f.getlength(w); sp = reg.getlength(" ") if cur else 0
            if cur and cw + sp + ww > maxw:
                lines.append(cur); cur, cw = [], 0; sp = 0
            cur.append((w, f, ww)); cw += sp + ww
        lines.append(cur)
    return lines

def draw_lines(img, lines, reg, x, y, width, lh, align, color=WHITE):
    d = ImageDraw.Draw(img); sp = reg.getlength(" ")
    for i, line in enumerate(lines):
        lw = sum(ww for _, _, ww in line) + sp * max(0, len(line) - 1)
        cx = x + ((width - lw) / 2 if align == "center" else 0)
        for w, f, ww in line:
            d.text((cx, y + i * lh), w, font=f, fill=color); cx += ww + sp
    return y + len(lines) * lh

def background(sl, W, H, base):
    bg = sl.get("bg")
    if bg and bg != "dark":
        p = bg if os.path.isabs(bg) else os.path.join(base, bg)
        im = ImageOps.exif_transpose(Image.open(p)).convert("RGB")
        sc = max(W / im.width, H / im.height)
        im = im.resize((math.ceil(im.width * sc), math.ceil(im.height * sc)), Image.LANCZOS)
        fx, fy = sl.get("focus", [0.5, 0.5])
        l, t = int((im.width - W) * fx), int((im.height - H) * fy)
        im = im.crop((l, t, l + W, t + H))
        im = ImageEnhance.Color(im).enhance(0.85)
        im = ImageEnhance.Brightness(im).enhance(sl.get("dim", 0.38 if sl["_style"] == "editorial" else 0.3))
        blur = sl.get("blur", 0 if sl["_style"] == "editorial" else 10)
        if blur: im = im.filter(ImageFilter.GaussianBlur(blur * S))
        img = im.convert("RGBA")
    else:
        img = Image.new("RGBA", (W, H), (12, 12, 12, 255))
    return img

def wordmark(img, W, H, h=34, opacity=0.8):
    wm = Image.open(os.path.join(ROOT, "assets", "wordmark-white.png")).convert("RGBA")
    wm = wm.resize((int(wm.width * h * S / wm.height), h * S), Image.LANCZOS)
    a = wm.split()[3].point(lambda v: int(v * opacity)); wm.putalpha(a)
    img.alpha_composite(wm, ((W - wm.width) // 2, H - 80 * S - wm.height))

def avatar(spec, base, d):
    av = spec.get("avatar")
    if av:
        im = ImageOps.fit(ImageOps.exif_transpose(Image.open(os.path.join(base, av))).convert("RGBA"), (d, d), Image.LANCZOS)
    else:
        im = Image.new("RGBA", (d, d), (255, 255, 255, 255))
        wm = Image.open(os.path.join(ROOT, "assets", "wordmark-black.png")).convert("RGBA")
        wm = wm.resize((int(d * 0.78), int(d * 0.78 * wm.height / wm.width)), Image.LANCZOS)
        im.alpha_composite(wm, ((d - wm.width) // 2, (d - wm.height) // 2))
    m = Image.new("L", (d, d), 0); ImageDraw.Draw(m).ellipse([0, 0, d - 1, d - 1], fill=255)
    im.putalpha(m); return im

def editorial(img, sl, i, W, H):
    cover = i == 0 or sl.get("cover")
    size = sl.get("size", 74 if cover else 54)
    reg, bold = font("Medium" if cover else "Regular", size), font("SemiBold", size)
    maxw = (sl.get("width", 840 if cover else 820)) * S
    lines = wrap(sl["text"], reg, bold, maxw); lh = size * S * (1.16 if cover else 1.3)
    sub = sl.get("sub"); sreg = font("Light", 34); slines = wrap(sub, sreg, font("Medium", 34), 760 * S) if sub else []
    th = len(lines) * lh + (len(slines) * 34 * S * 1.4 + 34 * S if slines else 0)
    y = (H - th) / 2 - 20 * S
    y = draw_lines(img, lines, reg, (W - maxw) / 2, y, maxw, lh, "center")
    if slines:
        draw_lines(img, slines, sreg, (W - 760 * S) / 2, y + 34 * S, 760 * S, 34 * S * 1.4, "center", (225, 225, 225))
    wordmark(img, W, H)

def post(img, sl, spec, base, W, H):
    size = sl.get("size", 46)
    reg, bold = font("Regular", size), font("SemiBold", size)
    x, maxw = 110 * S, W - 220 * S
    lines = wrap(sl["text"], reg, bold, maxw); lh = size * S * 1.38
    d = 104 * S; head = d + 44 * S
    th = head + len(lines) * lh
    y = (H - th) / 2
    img.alpha_composite(avatar(spec, base, d), (x, int(y)))
    dr = ImageDraw.Draw(img)
    dr.text((x + d + 26 * S, y + 14 * S), spec.get("author", "Vin"), font=font("SemiBold", 38), fill=WHITE)
    dr.text((x + d + 26 * S, y + 58 * S), spec.get("handle", "@str8s0urce"), font=font("Regular", 31), fill=(165, 165, 165))
    draw_lines(img, lines, reg, x, y + head, maxw, lh, "left")

def render(sl, i, spec, base):
    w, h = SIZES[spec.get("size", "4:5")]; W, H = w * S, h * S
    sl["_style"] = sl.get("style", spec.get("style", "editorial"))
    img = background(sl, W, H, base)
    if sl["_style"] == "post": post(img, sl, spec, base, W, H)
    else: editorial(img, sl, i, W, H)
    return img.convert("RGB").resize((w, h), Image.LANCZOS)

def main():
    if len(sys.argv) < 3: print(__doc__); sys.exit(1)
    sp, out = sys.argv[1], sys.argv[2]
    spec = json.load(open(sp)); base = os.path.dirname(os.path.abspath(sp)); os.makedirs(out, exist_ok=True)
    files = []
    for i, sl in enumerate(spec["slides"]):
        n = len(sl["text"].replace("*", "").split())
        if n > 35: print(f"  ! slide {i+1}: {n} words, cut it down", file=sys.stderr)
        p = os.path.join(out, f"{spec.get('name','slide')}-{i+1:02d}.png"); render(sl, i, spec, base).save(p, optimize=True); files.append(p); print("wrote", p)
    th = [Image.open(f) for f in files]; tw = 340; s = tw / th[0].width; cols = min(5, len(th)); g = 14
    rows = math.ceil(len(th) / cols); hh = int(th[0].height * s)
    sheet = Image.new("RGB", (cols * tw + (cols + 1) * g, rows * hh + (rows + 1) * g), (238, 236, 231))
    for k, t in enumerate(th): sheet.paste(t.resize((tw, hh), Image.LANCZOS), (g + (k % cols) * (tw + g), g + (k // cols) * (hh + g)))
    c = os.path.join(out, "_contact-sheet.jpg"); sheet.save(c, quality=88); print("wrote", c)

if __name__ == "__main__":
    main()
